# SlotSpot: Hyderabad Smart City Parking & Reservation Platform
> **Real-Time Metropolitan Parking Availability & Spot Reservation System**  
> Tailored for **Hyderabad, Telangana** (Greater Hyderabad Municipal Corporation & HUMTA Smart Mobility)

---

## 🎯 Executive Summary & Problem Context
In dense metropolitan centers like Hyderabad, motorists frequently spend 15 to 25 minutes circling congested commercial hubs—such as Ameerpet, Charminar, and HITEC City—in search of open parking bays. Conventional garages operate with disconnected systems and static physical gate boards that provide zero pre-arrival visibility, causing severe traffic bottlenecks and fuel wastage.

**SlotSpot** unifies Hyderabad's city-wide parking infrastructure into an interactive, real-time web platform. It visualizes live multi-level occupancy grids, guarantees spot holds with atomic 15-minute countdown timers, calculates dynamic tariffs based on vehicle type and occupancy surge thresholds, and issues verifiable digital gate entry passes with simulated QR verification.

---

## 📍 Hyderabad Parking Facilities & Zones
SlotSpot connects 4 major metropolitan transit and commercial hubs across Hyderabad:

1. **Metro Plaza Garage (Central Metro Interchange)**
   - *Address*: Opposite Pillar A-1042, Ameerpet Central Metro Interchange, Hyderabad, Telangana 500016
   - *Landmark*: Ameerpet Central Metro Interchange (Red & Blue Line Corridor)
   - *Capacity*: 30 bays across Ground Floor, Mezzanine (Floor 1), and Rooftop (Floor 2)
   - *EV Infrastructure*: Level-2 (22 kW) AC & DC Fast (60 kW) chargers
   - *Base Tariff*: ₹30/hour

2. **Charminar Heritage Civic Hub**
   - *Address*: Pathergatti Road, Near Charminar & High Court, Hyderabad, Telangana 500002
   - *Landmark*: Charminar Monument, High Court of Telangana & Laad Bazaar
   - *Category*: Municipal Multi-Level Garage
   - *Base Tariff*: ₹25/hour

3. **Cyber Towers Tech Deck**
   - *Address*: HITEC City Main Road, Opposite Cyber Gateway, Madhapur, Hyderabad, Telangana 500081
   - *Landmark*: Cyber Towers & Mindspace IT Park (Cyberabad Tech Corridor)
   - *Category*: Corporate Multi-Tier Tech Deck
   - *Base Tariff*: ₹40/hour

4. **Inorbit Mall & Durgam Cheruvu Deck**
   - *Address*: Mindspace Road, Beside Durgam Cheruvu Lake & Inorbit Mall, Madhapur, Hyderabad, Telangana 500081
   - *Landmark*: Inorbit Mall & Durgam Cheruvu Cable-Stayed Bridge
   - *Category*: Mall & Leisure Commercial Deck
   - *Base Tariff*: ₹35/hour

---

## 🚀 Live Demo Walkthrough
1. **Search for Parking**: Motorist enters `"Central Metro"` or `"Ameerpet"` into the search explorer.
2. **Facility Discovery**: System highlights **Metro Plaza Garage** displaying **14 spots remaining** and active Level-2 & DC Fast EV charging plugs.
3. **Multi-Level Floorplan Inspection**: Motorist clicks into the garage and selects **Floor 1 (Mezzanine)** to inspect the 2D parking stall schematic.
4. **Bay Selection**: Motorist selects vacant **EV Charging Bay #12**.
5. **Dynamic Tariff Calculation**: The system automatically calculates a **2-hour fee of ₹80** (₹60 base parking space + ₹20 Level-2 EV charging plug add-on).
6. **15-Minute Atomic Hold**: Motorist locks the bay; the server transitions the slot from `Vacant` ➔ `Locked` with an active 15-minute countdown timer (`15:00` ticking down).
7. **Digital Parking Pass Generation**: Booking is confirmed, generating a digital pass with an SVG/Canvas QR gate code token (`SLOTSPOT:RES-XXX`), entry barcode (`*HYD-PKP-METRO-012*`), and printable receipt.
8. **In-Lot Navigation & Gate Entry**: Driver scans the QR code at the virtual barrier (slot transitions to `Occupied`), opening animated step-by-step navigation directly to Bay #12.

---

## 🛠️ Problems Fixed & Enhancements
- **Hyderabad Geographic Alignment**:
  - Replaced all obsolete coordinates, addresses, and landmarks with authentic Hyderabad, Telangana locations.
  - Replaced vector map labels (Marina Bayfront ➔ Musi River & Durgam Cheruvu Basin, Central Park ➔ KBR National Park, Cyber Highway ➔ HITEC City Main Road, Ameerpet Metro Interchange).
  - Updated vehicle license plates to Telangana State format (`TS 09 AB 7720`).
- **Data Synchronization**:
  - Resolved desynchronization between backend `data/lots.json` and client-side fallback `public/js/data.js` so both serve identical, accurate Hyderabad data.
- **Dynamic Tariff Calculation Fix**:
  - Fixed an issue where non-EV charging bays charged an EV plug fee if vehicle type "EV" was selected. Now plug add-ons are strictly billed only for bays equipped with Level-2 or DC Fast chargers.
- **Race Condition & Telemetry Fix**:
  - Prevented telemetry simulation pulses from overwriting confirmed bookings (`reserved` status).
- **Navigation & Floor Switching**:
  - Fixed in-lot navigation routing so it dynamically switches to the floorplan view, selects the correct floor tab, and highlights the exact reserved bay.
- **Interactive Metro Zone Selector**:
  - Connected the navbar zone selector so choosing a zone instantly filters and navigates to the corresponding Hyderabad facility.
- **Dynamic Overstay Warning**:
  - Updated overstay fee warning modal to dynamically read active reservation details.
- **Dual-Mode Execution (Node.js & Live Server)**:
  - Both direct Node HTTP server (`node server.js`) and client-side static servers (VS Code Live Server on port 5500) operate seamlessly with local simulation fallbacks.

## 🛡️ Production Upgrades: Areas for Improvement Resolved

All 4 critical architectural and security improvements have been fully designed, implemented, and verified with 52 automated tests:

### 1. Automated Unit & Integration Tests (52 Tests, 100% Pass Rate)
- **Zero-Dependency Native Test Runner**: Uses Node.js native `node:test` and `node:assert` modules.
- **Unit Test Coverage** (`tests/unit/`):
  - `validation.test.js` (17 tests): Exhaustive testing for parking duration limits (1–24 hours, rejection of floats, negatives, zero, strings), vehicle types, SUV-vs-Compact size incompatibility, Indian/Telangana license plate standards, driver name/email sanitization, and EV plug integrity.
  - `tariff.test.js` (7 tests): Unit verification of occupancy percentages, dynamic surge pricing tiers (Normal 1.0x, High Demand 1.15x, Peak Surge 1.30x), vehicle multipliers, EV Level-2 vs DC Fast add-ons, and total fee mathematical invariants.
  - `auth.test.js` (13 tests): Cryptographic password hashing (`scrypt`), unique 16-byte salts, timing-safe equality comparison, session token generation/expiration, duplicate email rejection (409 Conflict), and reservation ownership enforcement (403 Forbidden).
- **Integration Test Coverage** (`tests/integration/`):
  - `api.test.js` (14 tests): Full lifecycle HTTP testing of `/api/hubs`, `/api/tariff/calculate`, `/api/auth/register`, `/api/auth/login`, `/api/auth/me`, `/api/slots/lock`, 409 double-booking prevention, `/api/slots/confirm`, `/api/slots/checkin`, and `/api/slots/cancel`.
  - `persistence.test.js` (1 test): Simulates real-world server crash and restart across multiple database instances to guarantee slot locks, QR codes, and reservation data survive server shutdowns.

### 2. Persistent Database (Node.js Built-in SQLite)
- **Eliminated Ephemeral In-Memory State**: Integrated Node.js v22+ native `node:sqlite` (`DatabaseSync`), writing atomically to `data/slotspot.db`.
- **Relational Relational Schema**: Normalized tables for `users`, `sessions`, `hubs`, `floors`, `slots`, and `reservations` with foreign key constraints and indexed status queries.
- **Server Restart Resilience**: When the server restarts or crashes, all confirmed bookings, active 15-minute locks, occupancy counts, and user accounts are seamlessly restored from disk.
- **Initial Auto-Seeding**: Automatically seeds facilities from `data/lots.json` and provisions ready-to-test motorist and administrator accounts on first run.

### 3. User Authentication & Authorization (RBAC)
- **Security-First Architecture**:
  - Passwords hashed using industry-standard `crypto.scryptSync` with unique 16-byte cryptographic salts.
  - Cryptographically secure session tokens (`SST-...`) with 24-hour expiration stored in `sessions` table.
- **Role-Based Access Control (RBAC)**:
  - `motorist`: Can lock bays, view digital passes, and manage their own reservations.
  - `admin`: Authorized to oversee facility telemetry, manage any reservation, and trigger simulation state resets.
- **Reservation Ownership Enforcement**: Motorists can only modify or cancel reservations created under their account. Cross-user tampering attempts are rejected with `403 Forbidden`.
- **Motorist Portal & UI**: Seamless interactive modal in `index.html` offering Sign In, Registration, Quick Demo Login buttons ("Harry (Motorist)" & "Admin Dispatcher"), and a live list of the user's persistent bookings.

### 4. Strict Server-Side Validation of Pricing & Duration
- **Duration Boundary Enforcement**: Validates that requested durations are whole integers between `1` and `24` hours (inclusive). Floating points (`2.5`), negative numbers (`-5`), zero (`0`), and out-of-range requests are rejected with `400 Bad Request`.
- **Vehicle Size Compatibility Checks**: Automatically checks stall dimensions. Prevents oversized vehicles (e.g., SUVs) from reserving undersized Compact stalls.
- **EV Equipment Safeguard**: Prohibits charging plug add-on billing on non-EV standard stalls.
- **Authoritative Price Recalculation**: Server independently recalculates and verifies all base tariffs, surge multipliers, vehicle multipliers, and EV plug fees. Client-supplied price totals are never trusted.
- **License Plate Validation**: Enforces standard Telangana and All-India registration formats (e.g. `TS 09 AB 7720`, `AP 28 BC 1234`).

---

## 🚦 How to Run

### 1. Execute Automated Tests (52 Tests)
Run all unit and integration tests:
```bash
npm test
```
*(Or directly via Node.js):*
```bash
node --test tests/unit/*.test.js tests/integration/*.test.js
```

### 2. Start the Server
```bash
node server.js
```

### 3. Open in Browser
Navigate to:
```
http://localhost:3000
```
- Click **"👤 Sign In"** in the top navigation to test authentication or use the quick demo profiles.
- Book any bay to experience server-side validation and persistent SQLite storage.
