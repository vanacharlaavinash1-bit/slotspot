// Unit Tests: Server-Side Authoritative Tariff & Surge Calculation Engine
const { test, describe } = require('node:test');
const assert = require('node:assert');
const {
  calculateHubOccupancy,
  getVehicleMultiplier,
  calculateAuthoritativeTariff
} = require('../../src/tariff');

describe('Authoritative Tariff & Pricing Unit Tests', () => {

  const mockHub = {
    id: 'metro-plaza',
    name: 'Metro Plaza Garage',
    baseTariffPerHour: 30,
    evCharging: {
      ratePerHour: 10,
      fastRatePerHour: 25,
      types: ['Level-2 AC (22 kW)', 'DC Fast (60 kW)']
    },
    floors: [
      {
        floorId: 'fl-1',
        slots: [
          { id: 'S1', status: 'vacant', type: 'Standard' },
          { id: 'S2', status: 'vacant', type: 'Standard' },
          { id: 'S3', status: 'occupied', type: 'Standard' },
          { id: 'S4', status: 'locked', type: 'Standard' },
          { id: 'S5', status: 'reserved', type: 'Standard' }
        ]
      }
    ]
  };

  test('correctly calculates hub occupancy rates and counts', () => {
    const stats = calculateHubOccupancy(mockHub);
    assert.strictEqual(stats.totalSpots, 5);
    assert.strictEqual(stats.vacantSpots, 2);
    assert.strictEqual(stats.occupiedSpots, 1);
    assert.strictEqual(stats.lockedSpots, 2);
    // (5 - 2) / 5 = 60%
    assert.strictEqual(stats.occupancyRate, 60);
  });

  test('applies correct surge multipliers across occupancy brackets', () => {
    // Normal: <60%
    const lowOccHub = { baseTariffPerHour: 30, floors: [{ slots: [{ status: 'vacant' }, { status: 'occupied' }] }] }; // 50%
    assert.strictEqual(calculateHubOccupancy(lowOccHub).surgeMultiplier, 1.0);
    assert.strictEqual(calculateHubOccupancy(lowOccHub).surgeLabel, 'Normal Tariff');

    // High Demand: 60% - 85%
    const midOccHub = { baseTariffPerHour: 30, floors: [{ slots: [{ status: 'occupied' }, { status: 'occupied' }, { status: 'occupied' }, { status: 'vacant' }, { status: 'vacant' }] }] }; // 60%
    assert.strictEqual(calculateHubOccupancy(midOccHub).surgeMultiplier, 1.15);
    assert.strictEqual(calculateHubOccupancy(midOccHub).surgeLabel, 'High Demand Surge (+15%)');

    // Peak Surge: >85%
    const highOccHub = { baseTariffPerHour: 30, floors: [{ slots: [{ status: 'occupied' }, { status: 'occupied' }, { status: 'occupied' }, { status: 'occupied' }, { status: 'occupied' }, { status: 'occupied' }, { status: 'occupied' }, { status: 'occupied' }, { status: 'occupied' }, { status: 'vacant' }] }] }; // 90%
    assert.strictEqual(calculateHubOccupancy(highOccHub).surgeMultiplier, 1.30);
    assert.strictEqual(calculateHubOccupancy(highOccHub).surgeLabel, 'Peak Surge (+30%)');
  });

  test('returns standard vehicle type multipliers', () => {
    assert.strictEqual(getVehicleMultiplier('2-Wheeler'), 0.5);
    assert.strictEqual(getVehicleMultiplier('Compact'), 0.8);
    assert.strictEqual(getVehicleMultiplier('Sedan'), 1.0);
    assert.strictEqual(getVehicleMultiplier('SUV'), 1.3);
    assert.strictEqual(getVehicleMultiplier('EV'), 1.0);
  });

  test('calculates correct authoritative tariff for Sedan at Metro Plaza (2 hours)', () => {
    // Base 30, Occupancy 60% -> surge 1.15 -> rate = round(30 * 1.0 * 1.15) = 35/hr
    // 2 hours -> baseTotal = 70, chargerTotal = 0, totalFee = 70
    const calc = calculateAuthoritativeTariff({
      hub: mockHub,
      vehicleType: 'Sedan',
      durationHours: 2,
      useCharger: false
    });

    assert.strictEqual(calc.vehicleType, 'Sedan');
    assert.strictEqual(calc.durationHours, 2);
    assert.strictEqual(calc.surgeMultiplier, 1.15);
    assert.strictEqual(calc.effectiveHourlyRate, 35);
    assert.strictEqual(calc.baseTotal, 70);
    assert.strictEqual(calc.chargerTotal, 0);
    assert.strictEqual(calc.totalFee, 70);
  });

  test('calculates correct EV bay tariff with Level-2 charging add-on fee', () => {
    const evSlot = { id: 'EV-1', bayNumber: 12, type: 'EV Charging', charger: 'Level-2 AC (22 kW)' };
    // Base 30 * 1.0 * 1.15 = 35/hr * 2 = 70
    // Charger = 10/hr * 2 = 20
    // Total = 90
    const calc = calculateAuthoritativeTariff({
      hub: mockHub,
      slot: evSlot,
      vehicleType: 'EV',
      durationHours: 2,
      useCharger: true,
      chargerType: 'Level-2 AC (22 kW)'
    });

    assert.strictEqual(calc.effectiveHourlyRate, 35);
    assert.strictEqual(calc.baseTotal, 70);
    assert.strictEqual(calc.chargerFeePerHour, 10);
    assert.strictEqual(calc.chargerTotal, 20);
    assert.strictEqual(calc.totalFee, 90);
    assert.strictEqual(calc.totalFee, calc.baseTotal + calc.chargerTotal);
  });

  test('calculates correct EV bay tariff with DC Fast charging add-on fee', () => {
    const evSlot = { id: 'EV-2', bayNumber: 14, type: 'EV Charging', charger: 'DC Fast (60 kW)' };
    // Fast Charger = 25/hr * 3 hrs = 75
    // Base = 35 * 3 = 105
    // Total = 180
    const calc = calculateAuthoritativeTariff({
      hub: mockHub,
      slot: evSlot,
      vehicleType: 'EV',
      durationHours: 3,
      useCharger: true,
      chargerType: 'DC Fast (60 kW)'
    });

    assert.strictEqual(calc.chargerFeePerHour, 25);
    assert.strictEqual(calc.chargerTotal, 75);
    assert.strictEqual(calc.baseTotal, 105);
    assert.strictEqual(calc.totalFee, 180);
  });

  test('verifies pricing invariant: totalFee is strictly sum of baseTotal and chargerTotal', () => {
    const calc = calculateAuthoritativeTariff({
      hub: mockHub,
      vehicleType: 'SUV',
      durationHours: 5
    });

    assert.strictEqual(calc.totalFee, calc.baseTotal + calc.chargerTotal);
    assert.ok(calc.totalFee > 0);
  });
});
