// Unit Tests: Server-Side Defensive Validation Module
const { test, describe } = require('node:test');
const assert = require('node:assert');
const {
  ValidationError,
  validateDuration,
  validateVehicleType,
  validateSlotCompatibility,
  validateLicensePlate,
  validateDriverName,
  validateEmail,
  validatePassword,
  validateEVChargingRequest
} = require('../../src/validation');

describe('Defensive Validation Unit Tests', () => {

  describe('Duration Validation', () => {
    test('accepts valid integer durations between 1 and 24 hours', () => {
      assert.strictEqual(validateDuration(1), 1);
      assert.strictEqual(validateDuration(2), 2);
      assert.strictEqual(validateDuration(8), 8);
      assert.strictEqual(validateDuration(24), 24);
      assert.strictEqual(validateDuration('3'), 3);
    });

    test('rejects duration of 0 hours', () => {
      assert.throws(() => validateDuration(0), {
        name: 'ValidationError',
        message: /cannot be less than 1 hour/
      });
    });

    test('rejects negative durations', () => {
      assert.throws(() => validateDuration(-4), {
        name: 'ValidationError',
        message: /cannot be less than 1 hour/
      });
    });

    test('rejects durations exceeding 24 hours limit', () => {
      assert.throws(() => validateDuration(25), {
        name: 'ValidationError',
        message: /Maximum allowable reservation duration is 24 hours/
      });
      assert.throws(() => validateDuration(100), {
        name: 'ValidationError',
        message: /Maximum allowable reservation duration is 24 hours/
      });
    });

    test('rejects non-integer float durations', () => {
      assert.throws(() => validateDuration(2.5), {
        name: 'ValidationError',
        message: /whole integer number of hours/
      });
    });

    test('rejects invalid non-numeric strings and null', () => {
      assert.throws(() => validateDuration('two'), {
        name: 'ValidationError'
      });
      assert.throws(() => validateDuration(null), {
        name: 'ValidationError'
      });
      assert.throws(() => validateDuration(undefined), {
        name: 'ValidationError'
      });
    });
  });

  describe('Vehicle Type Validation', () => {
    test('accepts and normalizes valid vehicle types', () => {
      assert.strictEqual(validateVehicleType('2-Wheeler'), '2-Wheeler');
      assert.strictEqual(validateVehicleType('2-wheeler'), '2-Wheeler');
      assert.strictEqual(validateVehicleType('Sedan'), 'Sedan');
      assert.strictEqual(validateVehicleType('sedan'), 'Sedan');
      assert.strictEqual(validateVehicleType('SUV'), 'SUV');
      assert.strictEqual(validateVehicleType('suv'), 'SUV');
      assert.strictEqual(validateVehicleType('EV'), 'EV');
      assert.strictEqual(validateVehicleType('Compact'), 'Compact');
    });

    test('rejects unrecognized vehicle types', () => {
      assert.throws(() => validateVehicleType('Tank'), {
        name: 'ValidationError',
        message: /Invalid vehicle type 'Tank'/
      });
      assert.throws(() => validateVehicleType('Airplane'), {
        name: 'ValidationError'
      });
      assert.throws(() => validateVehicleType(''), {
        name: 'ValidationError'
      });
    });
  });

  describe('Slot Compatibility Validation', () => {
    test('rejects SUV booking in Compact parking bay', () => {
      const compactSlot = { bayNumber: 5, type: 'Compact' };
      assert.throws(() => validateSlotCompatibility('SUV', compactSlot), {
        name: 'ValidationError',
        message: /Vehicle size mismatch: SUV cannot fit into Compact Bay #5/
      });
    });

    test('allows Sedan or 2-Wheeler in Compact parking bay', () => {
      const compactSlot = { bayNumber: 5, type: 'Compact' };
      assert.strictEqual(validateSlotCompatibility('Sedan', compactSlot), true);
      assert.strictEqual(validateSlotCompatibility('2-Wheeler', compactSlot), true);
    });

    test('allows SUV in Standard or EV parking bays', () => {
      const standardSlot = { bayNumber: 10, type: 'Standard' };
      const evSlot = { bayNumber: 12, type: 'EV Charging' };
      assert.strictEqual(validateSlotCompatibility('SUV', standardSlot), true);
      assert.strictEqual(validateSlotCompatibility('SUV', evSlot), true);
    });
  });

  describe('License Plate Validation', () => {
    test('accepts valid Telangana and Indian license plates', () => {
      assert.strictEqual(validateLicensePlate('TS 09 AB 7720'), 'TS 09 AB 7720');
      assert.strictEqual(validateLicensePlate('ts 09 ab 7720'), 'TS 09 AB 7720');
      assert.strictEqual(validateLicensePlate('TS09AB7720'), 'TS09AB7720');
      assert.strictEqual(validateLicensePlate('AP 28 BC 1234'), 'AP 28 BC 1234');
      assert.strictEqual(validateLicensePlate('DL 01 A 9999'), 'DL 01 A 9999');
    });

    test('rejects malformed license plate formats', () => {
      assert.throws(() => validateLicensePlate('1234'), {
        name: 'ValidationError'
      });
      assert.throws(() => validateLicensePlate('TS!@#'), {
        name: 'ValidationError'
      });
      assert.throws(() => validateLicensePlate(''), {
        name: 'ValidationError'
      });
    });
  });

  describe('Driver Name and Email Validation', () => {
    test('sanitizes driver name and removes hazardous HTML/script tags', () => {
      const sanitized = validateDriverName('  Harry <script>alert(1)</script>  ');
      assert.strictEqual(sanitized, 'Harry scriptalert(1)script');
    });

    test('rejects names with less than 2 characters', () => {
      assert.throws(() => validateDriverName('A'), {
        name: 'ValidationError',
        message: /at least 2 characters/
      });
    });

    test('accepts valid email addresses', () => {
      assert.strictEqual(validateEmail('motorist@slotspot.in'), 'motorist@slotspot.in');
      assert.strictEqual(validateEmail('  USER@HYD.GOV.IN  '), 'user@hyd.gov.in');
    });

    test('rejects invalid email formats', () => {
      assert.throws(() => validateEmail('invalid-email'), {
        name: 'ValidationError'
      });
      assert.throws(() => validateEmail('user@'), {
        name: 'ValidationError'
      });
    });

    test('validates password requirements', () => {
      assert.strictEqual(validatePassword('Pass123'), 'Pass123');
      assert.throws(() => validatePassword('12345'), {
        name: 'ValidationError',
        message: /at least 6 characters/
      });
      assert.throws(() => validatePassword('abcdef'), {
        name: 'ValidationError',
        message: /at least one letter and one number/
      });
    });
  });

  describe('EV Charging Request Integrity', () => {
    test('rejects charging add-on fee on standard non-EV bays', () => {
      const standardSlot = { bayNumber: 3, type: 'Standard' };
      assert.throws(() => validateEVChargingRequest(standardSlot, true, 'DC Fast', {}), {
        name: 'ValidationError',
        message: /Bay #3 is a standard Standard bay without an EV charging plug/
      });
    });

    test('approves charging add-on on legitimate EV Charging bays', () => {
      const evSlot = { bayNumber: 12, type: 'EV Charging', charger: 'Level-2 AC (22 kW)' };
      const result = validateEVChargingRequest(evSlot, true, 'Level-2 AC (22 kW)', { evCharging: { ratePerHour: 10 } });
      assert.strictEqual(result.isEVBay, true);
      assert.strictEqual(result.useCharger, true);
    });
  });
});
