// Unit Tests: User Authentication & Role-Based Authorization Module
const { test, describe, beforeEach } = require('node:test');
const assert = require('node:assert');
const { DatabaseEngine } = require('../../src/db');
const {
  hashPassword,
  verifyPassword,
  generateSessionToken,
  registerUser,
  loginUser,
  authenticateToken,
  logoutUser,
  authorizeReservationAction
} = require('../../src/auth');

describe('Authentication & Authorization Unit Tests', () => {
  let dbEngine;

  beforeEach(() => {
    // In-Memory SQLite instance for isolated, fast unit tests
    dbEngine = new DatabaseEngine(':memory:');
  });

  describe('Password Hashing & Token Generation', () => {
    test('hashes password using scrypt with unique salts', () => {
      const pass = 'Secret123';
      const res1 = hashPassword(pass);
      const res2 = hashPassword(pass);

      assert.ok(res1.hash);
      assert.ok(res1.salt);
      assert.ok(res2.hash);
      assert.ok(res2.salt);
      // Different salts produce different hashes
      assert.notStrictEqual(res1.salt, res2.salt);
      assert.notStrictEqual(res1.hash, res2.hash);

      assert.strictEqual(verifyPassword(pass, res1.hash, res1.salt), true);
      assert.strictEqual(verifyPassword('WrongPass', res1.hash, res1.salt), false);
    });

    test('generates cryptographically secure session token', () => {
      const token = generateSessionToken();
      assert.ok(token.startsWith('SST-'));
      assert.strictEqual(token.length, 68); // 'SST-' + 64 hex chars
    });
  });

  describe('User Registration & Login Lifecycle', () => {
    test('successfully registers a new motorist account and returns session token', () => {
      const result = registerUser(dbEngine.db, {
        name: 'Amina Rao',
        email: 'amina@hyderabad.gov.in',
        password: 'SecurePassword1',
        vehiclePlate: 'TS 09 AB 1010'
      });

      assert.ok(result.user);
      assert.strictEqual(result.user.name, 'Amina Rao');
      assert.strictEqual(result.user.email, 'amina@hyderabad.gov.in');
      assert.strictEqual(result.user.vehiclePlate, 'TS 09 AB 1010');
      assert.strictEqual(result.user.role, 'motorist');
      assert.ok(result.token);
      assert.ok(!result.user.password_hash); // Password hash must never be leaked
    });

    test('rejects duplicate email registration with 409 conflict', () => {
      registerUser(dbEngine.db, {
        name: 'User One',
        email: 'duplicate@slotspot.in',
        password: 'Password123'
      });

      assert.throws(() => {
        registerUser(dbEngine.db, {
          name: 'User Two',
          email: 'duplicate@slotspot.in',
          password: 'Password456'
        });
      }, {
        name: 'ValidationError',
        statusCode: 409,
        message: /already exists/
      });
    });

    test('authenticates registered user with correct credentials', () => {
      registerUser(dbEngine.db, {
        name: 'Kiran Kumar',
        email: 'kiran@slotspot.in',
        password: 'ValidPassword1'
      });

      const loginResult = loginUser(dbEngine.db, {
        email: 'kiran@slotspot.in',
        password: 'ValidPassword1'
      });

      assert.ok(loginResult.user);
      assert.strictEqual(loginResult.user.name, 'Kiran Kumar');
      assert.ok(loginResult.token);
    });

    test('rejects login with incorrect password', () => {
      registerUser(dbEngine.db, {
        name: 'Kiran Kumar',
        email: 'kiran2@slotspot.in',
        password: 'CorrectPassword1'
      });

      assert.throws(() => {
        loginUser(dbEngine.db, {
          email: 'kiran2@slotspot.in',
          password: 'WrongPassword'
        });
      }, {
        name: 'ValidationError',
        statusCode: 401,
        message: /Invalid email or password/
      });
    });

    test('authenticates valid token and invalidates on logout', () => {
      const reg = registerUser(dbEngine.db, {
        name: 'Rohan Sen',
        email: 'rohan@slotspot.in',
        password: 'RohanPassword1'
      });

      const user = authenticateToken(dbEngine.db, `Bearer ${reg.token}`);
      assert.ok(user);
      assert.strictEqual(user.id, reg.user.id);

      logoutUser(dbEngine.db, reg.token);
      const afterLogout = authenticateToken(dbEngine.db, `Bearer ${reg.token}`);
      assert.strictEqual(afterLogout, null);
    });
  });

  describe('Reservation Ownership Authorization', () => {
    test('authorizes owner to modify their own reservation', () => {
      const user = { id: 'USR-101', role: 'motorist' };
      const reservation = { id: 'RES-001', userId: 'USR-101' };
      assert.strictEqual(authorizeReservationAction(user, reservation), true);
    });

    test('rejects non-owner motorist from modifying another user reservation (403 Forbidden)', () => {
      const user = { id: 'USR-202', role: 'motorist' };
      const reservation = { id: 'RES-001', userId: 'USR-101' };
      assert.throws(() => authorizeReservationAction(user, reservation), {
        name: 'ValidationError',
        statusCode: 403,
        message: /You are not authorized to modify another motorist’s reservation/
      });
    });

    test('authorizes admin user to manage any reservation', () => {
      const adminUser = { id: 'USR-ADMIN', role: 'admin' };
      const reservation = { id: 'RES-001', userId: 'USR-101' };
      assert.strictEqual(authorizeReservationAction(adminUser, reservation), true);
    });
  });
});
