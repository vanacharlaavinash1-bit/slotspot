// Integration Tests: Persistent SQLite Database Resilience across Server Restarts
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { DatabaseEngine } = require('../../src/db');

describe('Database Persistence & Server Restart Resilience Tests', () => {
  let tempDbPath = '';

  before(() => {
    tempDbPath = path.join(os.tmpdir(), `slotspot_test_${Date.now()}.db`);
  });

  after(() => {
    if (fs.existsSync(tempDbPath)) {
      try {
        fs.unlinkSync(tempDbPath);
      } catch (e) {}
    }
  });

  test('slot locks and reservations persist across simulated server crash and restart', () => {
    // -------------------------------------------------------------
    // INSTANCE 1: Server Session 1
    // -------------------------------------------------------------
    const db1 = new DatabaseEngine(tempDbPath);

    // Verify initial seed loaded
    const hubs = db1.getAllHubs();
    assert.strictEqual(hubs.length, 4);

    // Lock Bay MP-1-12 in Session 1
    const testReservation = {
      id: 'RES-PERSIST-999',
      userId: 'USR-MOTO-01',
      driverName: 'Harry (Motorist)',
      plateNumber: 'TS 09 AB 7720',
      hubId: 'metro-plaza',
      hubName: 'Metro Plaza Garage',
      address: 'Ameerpet Metro Interchange',
      floorId: 'fl-1',
      floorName: 'Floor 1 (Mezzanine)',
      slotId: 'MP-1-12',
      bayNumber: 12,
      slotType: 'EV Charging',
      charger: 'Level-2 AC (22 kW)',
      vehicleType: 'EV',
      durationHours: 2,
      baseRatePerHour: 30,
      surgeMultiplier: 1.0,
      surgeLabel: 'Normal Tariff',
      effectiveHourlyRate: 30,
      baseTotal: 60,
      chargerFeePerHour: 10,
      chargerTotal: 20,
      totalFee: 80,
      status: 'locked',
      createdAt: Date.now(),
      expiresAt: Date.now() + 900000
    };

    db1.createReservation(testReservation);

    // Verify Session 1 reflects locked state
    const slotSession1 = db1.getSlot('metro-plaza', 'MP-1-12');
    assert.strictEqual(slotSession1.status, 'locked');
    assert.strictEqual(slotSession1.reservationId, 'RES-PERSIST-999');

    // Simulate Server Shutdown / Crash
    db1.close();

    // -------------------------------------------------------------
    // INSTANCE 2: Server Session 2 (Relaunched from same SQLite DB)
    // -------------------------------------------------------------
    const db2 = new DatabaseEngine(tempDbPath);

    // Verify that Bay MP-1-12 is STILL locked after restart!
    const slotSession2 = db2.getSlot('metro-plaza', 'MP-1-12');
    assert.ok(slotSession2, 'Slot must exist after restart');
    assert.strictEqual(slotSession2.status, 'locked', 'Slot must retain locked state across server restarts');
    assert.strictEqual(slotSession2.reservationId, 'RES-PERSIST-999');

    // Verify reservation record is completely restored
    const restoredRes = db2.getReservationById('RES-PERSIST-999');
    assert.ok(restoredRes, 'Reservation record must persist across restarts');
    assert.strictEqual(restoredRes.driverName, 'Harry (Motorist)');
    assert.strictEqual(restoredRes.totalFee, 80);
    assert.strictEqual(restoredRes.status, 'locked');

    // Update to confirmed in Session 2
    db2.updateReservationStatus('RES-PERSIST-999', 'reserved', {
      confirmedAt: Date.now(),
      qrToken: 'SLOTSPOT:RES-PERSIST-999'
    });
    db2.updateSlotStatus('MP-1-12', 'reserved', 'RES-PERSIST-999', 'EV');

    db2.close();

    // -------------------------------------------------------------
    // INSTANCE 3: Server Session 3 (Second Restart)
    // -------------------------------------------------------------
    const db3 = new DatabaseEngine(tempDbPath);
    const slotSession3 = db3.getSlot('metro-plaza', 'MP-1-12');
    assert.strictEqual(slotSession3.status, 'reserved');

    const confirmedRes = db3.getReservationById('RES-PERSIST-999');
    assert.strictEqual(confirmedRes.status, 'reserved');
    assert.strictEqual(confirmedRes.qrToken, 'SLOTSPOT:RES-PERSIST-999');
    assert.ok(confirmedRes.confirmedAt > 0);

    db3.close();
  });
});
