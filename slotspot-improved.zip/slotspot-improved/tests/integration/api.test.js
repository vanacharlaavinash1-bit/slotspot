// Integration Tests: End-to-End REST API Endpoints & Reservation Lifecycle
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert');
const http = require('http');
const { server, dbEngine } = require('../../server');

let baseUrl = '';
let serverInstance = null;

function apiRequest(path, options = {}) {
  return new Promise((resolve, reject) => {
    const url = `${baseUrl}${path}`;
    const headers = options.headers || {};
    if (options.body) {
      headers['Content-Type'] = 'application/json';
    }

    const req = http.request(url, {
      method: options.method || 'GET',
      headers
    }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        let json = null;
        try {
          json = data ? JSON.parse(data) : null;
        } catch (e) {
          json = data;
        }
        resolve({
          status: res.statusCode,
          headers: res.headers,
          data: json
        });
      });
    });

    req.on('error', reject);
    if (options.body) {
      req.write(JSON.stringify(options.body));
    }
    req.end();
  });
}

describe('SlotSpot REST API Integration Tests', () => {

  before(async () => {
    await new Promise((resolve, reject) => {
      serverInstance = server.listen(0, '127.0.0.1', () => {
        const port = serverInstance.address().port;
        baseUrl = `http://127.0.0.1:${port}`;
        resolve();
      });
      serverInstance.on('error', reject);
    });
  });

  after(async () => {
    if (serverInstance) {
      await new Promise(resolve => serverInstance.close(resolve));
    }
  });

  describe('Hubs & Telemetry Endpoints', () => {
    test('GET /api/hubs returns 200 and list of Hyderabad parking hubs', async () => {
      const res = await apiRequest('/api/hubs');
      assert.strictEqual(res.status, 200);
      assert.strictEqual(res.data.success, true);
      assert.ok(Array.isArray(res.data.hubs));
      assert.strictEqual(res.data.hubs.length, 4);

      const metroHub = res.data.hubs.find(h => h.id === 'metro-plaza');
      assert.ok(metroHub);
      assert.strictEqual(metroHub.name, 'Metro Plaza Garage');
      assert.ok(metroHub.totalSpots > 0);
      assert.ok(metroHub.vacantSpots >= 0);
    });

    test('GET /api/hubs/metro-plaza returns 200 with multi-level floorplan schema', async () => {
      const res = await apiRequest('/api/hubs/metro-plaza');
      assert.strictEqual(res.status, 200);
      assert.strictEqual(res.data.success, true);
      assert.ok(res.data.hub.floors);
      assert.strictEqual(res.data.hub.floors.length, 3);
    });

    test('GET /api/hubs/non-existent-id returns 404', async () => {
      const res = await apiRequest('/api/hubs/unknown-hub');
      assert.strictEqual(res.status, 404);
      assert.strictEqual(res.data.success, false);
    });
  });

  describe('Tariff Calculation & Validation Endpoints', () => {
    test('POST /api/tariff/calculate calculates dynamic pricing correctly', async () => {
      const res = await apiRequest('/api/tariff/calculate', {
        method: 'POST',
        body: {
          hubId: 'metro-plaza',
          vehicleType: 'Sedan',
          durationHours: 3
        }
      });
      assert.strictEqual(res.status, 200);
      assert.strictEqual(res.data.success, true);
      assert.strictEqual(res.data.calculation.durationHours, 3);
      assert.strictEqual(res.data.calculation.vehicleType, 'Sedan');
      assert.ok(res.data.calculation.totalFee > 0);
    });

    test('POST /api/tariff/calculate rejects negative or out-of-range duration with 400', async () => {
      const res = await apiRequest('/api/tariff/calculate', {
        method: 'POST',
        body: {
          hubId: 'metro-plaza',
          vehicleType: 'Sedan',
          durationHours: -3
        }
      });
      assert.strictEqual(res.status, 400);
      assert.strictEqual(res.data.success, false);
      assert.ok(res.data.error.includes('cannot be less than 1 hour'));
    });
  });

  describe('User Authentication & RBAC Flow', () => {
    let testToken = '';
    let testUserId = '';

    test('POST /api/auth/register registers motorist account', async () => {
      const res = await apiRequest('/api/auth/register', {
        method: 'POST',
        body: {
          name: 'Priya Sharma',
          email: `priya_${Date.now()}@slotspot.in`,
          password: 'Password123',
          vehiclePlate: 'TS 09 AB 8899'
        }
      });
      assert.strictEqual(res.status, 201);
      assert.strictEqual(res.data.success, true);
      assert.ok(res.data.token);
      assert.strictEqual(res.data.user.name, 'Priya Sharma');
      testToken = res.data.token;
      testUserId = res.data.user.id;
    });

    test('GET /api/auth/me returns user profile with Bearer token', async () => {
      const res = await apiRequest('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${testToken}` }
      });
      assert.strictEqual(res.status, 200);
      assert.strictEqual(res.data.success, true);
      assert.strictEqual(res.data.user.id, testUserId);
    });

    test('GET /api/auth/me returns 401 without Bearer token', async () => {
      const res = await apiRequest('/api/auth/me');
      assert.strictEqual(res.status, 401);
      assert.strictEqual(res.data.success, false);
    });
  });

  describe('Full Slot Reservation Lifecycle & Authorization Checks', () => {
    let reservationId = '';
    let userAToken = '';
    let userBToken = '';

    before(async () => {
      // Register User A
      const resA = await apiRequest('/api/auth/register', {
        method: 'POST',
        body: {
          name: 'Motorist A',
          email: `userA_${Date.now()}@slotspot.in`,
          password: 'Password123',
          vehiclePlate: 'TS 09 AB 1111'
        }
      });
      userAToken = resA.data.token;

      // Register User B
      const resB = await apiRequest('/api/auth/register', {
        method: 'POST',
        body: {
          name: 'Motorist B',
          email: `userB_${Date.now()}@slotspot.in`,
          password: 'Password123',
          vehiclePlate: 'TS 09 AB 2222'
        }
      });
      userBToken = resB.data.token;
    });

    test('1. Lock Bay #12 at Metro Plaza as User A -> 200 OK with 15-min hold', async () => {
      // Ensure MP-1-12 is vacant first
      dbEngine.updateSlotStatus('MP-1-12', 'vacant', null, null);

      const res = await apiRequest('/api/slots/lock', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userAToken}` },
        body: {
          hubId: 'metro-plaza',
          slotId: 'MP-1-12',
          vehicleType: 'EV',
          durationHours: 2,
          chargerType: 'Level-2 AC (22 kW)'
        }
      });

      assert.strictEqual(res.status, 200);
      assert.strictEqual(res.data.success, true);
      assert.ok(res.data.reservation);
      assert.strictEqual(res.data.reservation.slotId, 'MP-1-12');
      assert.strictEqual(res.data.reservation.status, 'locked');
      reservationId = res.data.reservation.id;

      // Verify slot status in DB
      const slot = dbEngine.getSlot('metro-plaza', 'MP-1-12');
      assert.strictEqual(slot.status, 'locked');
    });

    test('2. Attempt double-locking already locked Bay #12 -> returns 409 Conflict', async () => {
      const res = await apiRequest('/api/slots/lock', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userBToken}` },
        body: {
          hubId: 'metro-plaza',
          slotId: 'MP-1-12',
          vehicleType: 'EV',
          durationHours: 2
        }
      });
      assert.strictEqual(res.status, 409);
      assert.strictEqual(res.data.success, false);
      assert.ok(res.data.error.includes('is no longer vacant'));
    });

    test('3. User B unauthorized attempt to confirm User A reservation -> returns 403 Forbidden', async () => {
      const res = await apiRequest('/api/slots/confirm', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userBToken}` },
        body: { reservationId }
      });
      assert.strictEqual(res.status, 403);
      assert.strictEqual(res.data.success, false);
      assert.ok(res.data.error.includes('Access denied'));
    });

    test('4. User A confirms booking -> 200 OK, transitions to reserved & generates digital pass', async () => {
      const res = await apiRequest('/api/slots/confirm', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userAToken}` },
        body: { reservationId }
      });
      assert.strictEqual(res.status, 200);
      assert.strictEqual(res.data.success, true);
      assert.strictEqual(res.data.reservation.status, 'reserved');
      assert.ok(res.data.reservation.qrToken);

      const slot = dbEngine.getSlot('metro-plaza', 'MP-1-12');
      assert.strictEqual(slot.status, 'reserved');
    });

    test('5. Check-in at virtual gate barrier -> 200 OK, transitions slot to occupied', async () => {
      const res = await apiRequest('/api/slots/checkin', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userAToken}` },
        body: { reservationId }
      });
      assert.strictEqual(res.status, 200);
      assert.strictEqual(res.data.success, true);
      assert.strictEqual(res.data.reservation.status, 'checked_in');

      const slot = dbEngine.getSlot('metro-plaza', 'MP-1-12');
      assert.strictEqual(slot.status, 'occupied');
    });

    test('6. Cancel reservation -> 200 OK, releases slot back to vacant', async () => {
      const res = await apiRequest('/api/slots/cancel', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userAToken}` },
        body: { reservationId }
      });
      assert.strictEqual(res.status, 200);
      assert.strictEqual(res.data.success, true);

      const slot = dbEngine.getSlot('metro-plaza', 'MP-1-12');
      assert.strictEqual(slot.status, 'vacant');
    });
  });
});
