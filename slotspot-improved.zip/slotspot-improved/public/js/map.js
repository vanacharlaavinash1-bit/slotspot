// SlotSpot: Real street map (OpenStreetMap via Leaflet) with live GPS location

const CityMap = (function () {
  const LEAFLET_JS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js';
  const LEAFLET_CSS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css';
  const TILES = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
  const HYD = [17.4, 78.43];

  let containerEl = null, map = null, ready = false;
  let hubsList = [], activeHubId = 'metro-plaza', onSelectCallback = null;
  let hubMarkers = {};
  let me = null;                 // { lat, lng, accuracy, heading, demo }
  let meMarker = null, meCircle = null, routeLine = null;
  let lotsLayer = null, lotsShown = true, lotsCount = -1;
  let watchId = null, demoTimer = null, following = true, mode = 'off';

  function loadLeaflet() {
    return new Promise((resolve, reject) => {
      if (window.L) return resolve();
      const css = document.createElement('link');
      css.rel = 'stylesheet'; css.href = LEAFLET_CSS;
      document.head.appendChild(css);
      const js = document.createElement('script');
      js.src = LEAFLET_JS; js.onload = resolve; js.onerror = reject;
      document.head.appendChild(js);
    });
  }

  function injectStyles() {
    if (document.getElementById('cityMapStyles')) return;
    const st = document.createElement('style');
    st.id = 'cityMapStyles';
    st.textContent = `
      .ss-map-wrap{position:relative;flex:1;min-height:440px;height:100%}
      #ssLeafletMap{position:absolute;inset:0;border-radius:12px;z-index:0}
      .ss-pin{display:flex;flex-direction:column;align-items:center;transform:translate(-50%,-100%)}
      .ss-pin-body{min-width:44px;padding:4px 8px;border-radius:14px;color:#fff;font:800 13px/1 sans-serif;
        border:2px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.45);white-space:nowrap;text-align:center}
      .ss-pin-tip{width:0;height:0;border:6px solid transparent;border-top-color:#fff;margin-top:-1px}
      .ss-pin.active .ss-pin-body{transform:scale(1.2);outline:3px solid rgba(37,99,235,.55)}
      .ss-me{width:22px;height:22px;border-radius:50%;background:#2563eb;border:4px solid #fff;box-shadow:0 0 0 0 rgba(37,99,235,.6);animation:ssMe 2s infinite}
      @keyframes ssMe{70%{box-shadow:0 0 0 18px rgba(37,99,235,0)}100%{box-shadow:0 0 0 0 rgba(37,99,235,0)}}
      @media (prefers-reduced-motion:reduce){.ss-me{animation:none}}
      .ss-btns{position:absolute;right:12px;bottom:90px;z-index:600;display:flex;flex-direction:column;gap:8px}
      .ss-btns button{width:44px;height:44px;border-radius:50%;border:none;background:#fff;color:#1e293b;font-size:20px;
        box-shadow:0 2px 8px rgba(0,0,0,.4);cursor:pointer}
      .ss-btns button.on{background:#2563eb;color:#fff}
      .ss-card{position:absolute;left:12px;right:12px;bottom:12px;z-index:600;background:#fff;color:#0f172a;border-radius:14px;
        padding:10px 14px;box-shadow:0 4px 16px rgba(0,0,0,.4);font:13px/1.4 sans-serif;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
      .ss-card .ss-info{flex:1;min-width:180px}
      .ss-card b{font-size:14px}
      .ss-card button{border:none;border-radius:8px;padding:8px 12px;font-weight:700;cursor:pointer;font-size:12px}
      .ss-go{background:#2563eb;color:#fff}.ss-alt{background:#e2e8f0;color:#0f172a}
      .ss-card.hidden{display:none}
      .ss-status{position:absolute;left:12px;top:12px;z-index:600;background:#fff;color:#0f172a;border-radius:10px;padding:6px 10px;font:12px/1.3 sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.35)}
      .ss-status.hidden{display:none}
      .ss-btns button.txt{font-size:11px;font-weight:800}
      .ss-err{position:absolute;inset:0;display:grid;place-items:center;text-align:center;padding:20px;color:#e2e8f0;font:14px sans-serif}
    `;
    document.head.appendChild(st);
  }

  function init(containerId, hubs, onSelect) {
    containerEl = document.getElementById(containerId);
    hubsList = hubs; onSelectCallback = onSelect;
    injectStyles();
    containerEl.innerHTML = `
      <div class="city-map-wrapper">
        <div class="map-controls-bar">
          <div class="map-legend">
            <span class="legend-city-tag">📍 Hyderabad · dot = parking lot, P = selected / partner hub</span>
            <span class="legend-item"><span class="dot dot-vacant"></span> Plenty (&gt;8)</span>
            <span class="legend-item"><span class="dot dot-warn"></span> Filling (4–8)</span>
            <span class="legend-item"><span class="dot" style="background:#ef4444"></span> Almost full (≤3)</span>
          </div>
          <div class="map-actions"><button class="btn btn-sm btn-ghost" id="mapResetViewBtn">Show all parking</button></div>
        </div>
        <div class="ss-map-wrap">
          <div id="ssLeafletMap"></div>
          <div class="ss-status hidden" id="ssStatus"></div>
          <div class="ss-btns">
            <button id="ssAllToggle" class="txt on" title="Show or hide all parking in Hyderabad" aria-label="Toggle all parking">P</button>
            <button id="ssLocate" title="My live location" aria-label="My live location">◎</button>
          </div>
          <div class="ss-card hidden" id="ssCard"></div>
        </div>
      </div>`;

    loadLeaflet().then(buildMap).catch(() => {
      document.getElementById('ssLeafletMap').innerHTML =
        '<div class="ss-err">Map could not load. Check your internet connection and refresh.</div>';
    });
  }

  function buildMap() {
    map = L.map('ssLeafletMap', { zoomControl: true, preferCanvas: true }).setView(HYD, 12);
    L.tileLayer(TILES, { maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
    new ResizeObserver(() => map.invalidateSize()).observe(document.getElementById('ssLeafletMap'));
    map.on('dragstart', () => { following = false; syncBtn(); });

    document.getElementById('mapResetViewBtn').onclick = fitHubs;
    document.getElementById('ssLocate').onclick = () => {
      if (mode === 'off') startTracking();
      else if (!following && me) { following = true; syncBtn(); map.setView([me.lat, me.lng], Math.max(map.getZoom(), 16)); }
      else stopTracking();
    };
    document.getElementById('ssAllToggle').onclick = () => {
      lotsShown = !lotsShown;
      document.getElementById('ssAllToggle').classList.toggle('on', lotsShown);
      if (lotsLayer) { lotsShown ? lotsLayer.addTo(map) : map.removeLayer(lotsLayer); }
    };
    ready = true;
    renderPins();
    fitHubs();
    renderLots();
    startTracking();   // ask for live location right away
  }

  function fitHubs() {
    if (!ready || !hubsList.length) return;
    const pts = hubsList.filter(h => h.lat && h.lng).map(h => [h.lat, h.lng]);
    if (me && nearMe(me)) pts.push([me.lat, me.lng]);
    if (pts.length) map.fitBounds(pts, { padding: [50, 50], maxZoom: 14 });
  }
  const nearMe = p => dist(p.lat, p.lng, HYD[0], HYD[1]) < 60000;

  function updateHubs(hubs) { hubsList = hubs; renderLots(); renderPins(); renderCard(); }
  function setActiveHub(id) { activeHubId = id; renderPins(); renderCard(); drawRoute(); }

  function pinIcon(h, active) {
    const v = h.vacantSpots ?? 0;
    const color = v > 8 ? '#16a34a' : (v > 3 ? '#d97706' : '#dc2626');
    return L.divIcon({
      className: '', iconSize: [0, 0],
      html: `<div class="ss-pin ${active ? 'active' : ''}">
               <div class="ss-pin-body" style="background:${color}">P · ${v}</div>
               <div class="ss-pin-tip"></div></div>`
    });
  }

  function renderPins() {
    if (!ready) return;
    Object.values(hubMarkers).forEach(m => map.removeLayer(m));
    hubMarkers = {};
    hubsList.forEach(h => {
      if (!h.lat || !h.lng) return;
      const active = h.id === activeHubId;
      if (h.isLot && !active) return;   // other lots are drawn as dots
      const m = L.marker([h.lat, h.lng], { icon: pinIcon(h, active), zIndexOffset: active ? 1000 : 0, title: h.name }).addTo(map);
      m.bindTooltip(h.name, { direction: 'top', offset: [0, -38] });
      m.on('click', () => { activeHubId = h.id; renderPins(); renderCard(); drawRoute(); if (onSelectCallback) onSelectCallback(h.id); });
      hubMarkers[h.id] = m;
    });
  }


  // ---------- every other parking lot: small clickable dots ----------
  function setStatus(t) {
    const el = document.getElementById('ssStatus');
    if (!el) return;
    el.innerHTML = t || ''; el.classList.toggle('hidden', !t);
  }

  function renderLots() {
    if (!ready) return;
    const lots = hubsList.filter(h => h.isLot);
    if (lots.length === lotsCount) return;      // already drawn
    lotsCount = lots.length;
    if (lotsLayer) map.removeLayer(lotsLayer);
    lotsLayer = L.layerGroup();
    lots.forEach(h => {
      const v = h.vacantSpots ?? 0;
      const color = v > 8 ? '#16a34a' : (v > 3 ? '#d97706' : '#dc2626');
      const m = L.circleMarker([h.lat, h.lng], { radius: 6, color: '#fff', weight: 1.5, fillColor: color, fillOpacity: 0.95 });
      m.bindTooltip(`${h.name} · ${v} free`);
      m.on('click', () => { activeHubId = h.id; renderPins(); renderCard(); drawRoute(); if (onSelectCallback) onSelectCallback(h.id); });
      m.addTo(lotsLayer);
    });
    if (lotsShown) lotsLayer.addTo(map);
  }

  // ---------- live location ----------
  function dist(a, b, c, d) {
    const R = 6371000, rad = Math.PI / 180;
    const dLat = (c - a) * rad, dLng = (d - b) * rad;
    const x = Math.sin(dLat / 2) ** 2 + Math.cos(a * rad) * Math.cos(c * rad) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  const fmt = m => m >= 1000 ? (m / 1000).toFixed(m > 10000 ? 0 : 1) + ' km' : Math.round(m) + ' m';

  function onPosition(pos) {
    const c = pos.coords;
    me = { lat: c.latitude, lng: c.longitude, accuracy: c.accuracy, heading: c.heading, demo: mode === 'demo' };
    if (!meMarker) {
      meMarker = L.marker([me.lat, me.lng], {
        icon: L.divIcon({ className: '', html: '<div class="ss-me"></div>', iconSize: [22, 22], iconAnchor: [11, 11] }),
        zIndexOffset: 2000, interactive: false
      }).addTo(map);
      meCircle = L.circle([me.lat, me.lng], { radius: me.accuracy, color: '#2563eb', weight: 1, fillOpacity: 0.12 }).addTo(map);
      if (nearMe(me)) map.setView([me.lat, me.lng], 15);
      else { fitHubs(); }
    } else {
      meMarker.setLatLng([me.lat, me.lng]);
      meCircle.setLatLng([me.lat, me.lng]).setRadius(me.accuracy);
    }
    if (following && nearMe(me) && map.getZoom() >= 14) map.panTo([me.lat, me.lng]);
    drawRoute(); renderCard(); syncBtn();
    emitLocation();
  }

  let lastEmit = null;
  function emitLocation() {
    if (!me || !nearMe(me)) return;
    if (lastEmit && dist(lastEmit.lat, lastEmit.lng, me.lat, me.lng) < 150) return;
    lastEmit = { lat: me.lat, lng: me.lng };
    window.dispatchEvent(new CustomEvent('slotspot:location', { detail: lastEmit }));
  }

  function onError(err) {
    stopTracking(true);
    const why = err.code === 1 ? 'Location is blocked. Click the 🔒 icon in the address bar, set Location to Allow, then refresh.'
      : 'Could not find your location.';
    renderCard(why);
  }

  function startTracking() {
    if (!navigator.geolocation) return onError({ code: 2 });
    mode = 'live'; following = true;
    renderCard('Finding your location…');
    watchId = navigator.geolocation.watchPosition(onPosition, onError, { enableHighAccuracy: true, maximumAge: 2000, timeout: 20000 });
    syncBtn();
  }

  function startDemo() {
    stopTracking(true);
    mode = 'demo'; following = true;
    let t = 0;
    const tick = () => {
      t += 0.1;
      onPosition({ coords: { latitude: 17.4375 + Math.sin(t) * 0.004, longitude: 78.4482 + Math.cos(t) * 0.006, accuracy: 25, heading: null } });
    };
    tick(); map.setView([me.lat, me.lng], 15);
    demoTimer = setInterval(tick, 1000);
  }

  function stopTracking(keep) {
    if (watchId !== null) { navigator.geolocation.clearWatch(watchId); watchId = null; }
    if (demoTimer) { clearInterval(demoTimer); demoTimer = null; }
    mode = 'off';
    if (!keep) {
      [meMarker, meCircle, routeLine].forEach(l => l && map.removeLayer(l));
      meMarker = meCircle = routeLine = null; me = null; renderCard();
    }
    syncBtn();
  }

  function syncBtn() {
    const b = document.getElementById('ssLocate');
    if (b) b.classList.toggle('on', mode !== 'off' && following);
  }

  function drawRoute() {
    if (!ready) return;
    if (routeLine) { map.removeLayer(routeLine); routeLine = null; }
    const h = hubsList.find(x => x.id === activeHubId);
    if (me && h && h.lat && nearMe(me)) {
      routeLine = L.polyline([[me.lat, me.lng], [h.lat, h.lng]], { color: '#2563eb', weight: 4, dashArray: '8 10', opacity: 0.85 }).addTo(map);
    }
  }

  function renderCard(msg) {
    const card = document.getElementById('ssCard');
    if (!card) return;
    if (msg) {
      card.classList.remove('hidden');
      card.innerHTML = `<div class="ss-info">${msg}</div><button class="ss-alt" id="ssDemo">Try demo location</button>`;
      document.getElementById('ssDemo').onclick = startDemo;
      return;
    }
    const h = hubsList.find(x => x.id === activeHubId);
    if (!me || !h) { card.classList.add('hidden'); return; }
    card.classList.remove('hidden');
    const d = dist(me.lat, me.lng, h.lat, h.lng);
    const far = !nearMe(me);
    card.innerHTML = `
      <div class="ss-info">
        <b>${h.name}</b><br>
        ${far ? 'You are far from Hyderabad (' + fmt(d) + ' away).' : '🔵 You are <b>' + fmt(d) + '</b> away'} · ${h.vacantSpots ?? 0} spots free
        ${me.demo ? '<br><i>Demo location (simulated)</i>' : ''}
      </div>
      ${far && !me.demo ? '<button class="ss-alt" id="ssDemo">Try demo location</button>' : ''}
      <button class="ss-go" id="ssNav">Directions</button>
      <button class="ss-alt" id="ssBook">View bays</button>`;
    const demo = document.getElementById('ssDemo'); if (demo) demo.onclick = startDemo;
    document.getElementById('ssNav').onclick = () =>
      window.open(`https://www.google.com/maps/dir/?api=1&origin=${me.lat},${me.lng}&destination=${h.lat},${h.lng}&travelmode=driving`, '_blank');
    document.getElementById('ssBook').onclick = () => {
      if (window.SlotSpotApp) window.SlotSpotApp.selectHub(h.id, true);
    };
  }

  return { setStatus, init, updateHubs, setActiveHub, startTracking, stopTracking, startDemo };
})();
