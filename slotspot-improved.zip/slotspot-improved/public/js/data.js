// SlotSpot: Embedded Default Dataset for Offline & Live Server Fallback (Hyderabad Smart Mobility)
window.INITIAL_PARKING_HUBS = [
  {
    "id": "metro-plaza",
    "name": "Metro Plaza Garage",
    "city": "Hyderabad",
    "category": "Metro Transit Hub",
    "address": "Opposite Pillar A-1042, Ameerpet Central Metro Interchange, Hyderabad, Telangana 500016",
    "landmark": "Ameerpet Central Metro Interchange",
    "distance": "0.1 km from Central Metro Interchange",
    "lat": 17.4375,
    "lng": 78.4482,
    "mapX": 350,
    "mapY": 230,
    "baseTariffPerHour": 30,
    "evCharging": {
      "available": true,
      "types": [
        "Level-2 (22 kW)",
        "DC Fast (60 kW)"
      ],
      "ratePerHour": 10,
      "fastRatePerHour": 25
    },
    "totalSpots": 30,
    "floors": [
      {
        "floorId": "G",
        "floorName": "Ground Floor (Level G)",
        "slots": [
          {
            "id": "MP-G-01",
            "bayNumber": "01",
            "floor": "G",
            "type": "Disabled",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "MP-G-02",
            "bayNumber": "02",
            "floor": "G",
            "type": "Disabled",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MP-G-03",
            "bayNumber": "03",
            "floor": "G",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "MP-G-04",
            "bayNumber": "04",
            "floor": "G",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "MP-G-05",
            "bayNumber": "05",
            "floor": "G",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "MP-G-06",
            "bayNumber": "06",
            "floor": "G",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MP-G-07",
            "bayNumber": "07",
            "floor": "G",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "MP-G-08",
            "bayNumber": "08",
            "floor": "G",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "MP-G-09",
            "bayNumber": "09",
            "floor": "G",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "MP-G-10",
            "bayNumber": "10",
            "floor": "G",
            "type": "EV Charging",
            "status": "vacant",
            "vehicleType": null,
            "charger": "DC Fast (60 kW)"
          }
        ]
      },
      {
        "floorId": "1",
        "floorName": "Floor 1 (Mezzanine Level)",
        "slots": [
          {
            "id": "MP-1-11",
            "bayNumber": "11",
            "floor": "1",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "DC Fast (60 kW)"
          },
          {
            "id": "MP-1-12",
            "bayNumber": "12",
            "floor": "1",
            "type": "EV Charging",
            "status": "vacant",
            "vehicleType": null,
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "MP-1-13",
            "bayNumber": "13",
            "floor": "1",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MP-1-14",
            "bayNumber": "14",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "MP-1-15",
            "bayNumber": "15",
            "floor": "1",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MP-1-16",
            "bayNumber": "16",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "MP-1-17",
            "bayNumber": "17",
            "floor": "1",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MP-1-18",
            "bayNumber": "18",
            "floor": "1",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MP-1-19",
            "bayNumber": "19",
            "floor": "1",
            "type": "Disabled",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "MP-1-20",
            "bayNumber": "20",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          }
        ]
      },
      {
        "floorId": "2",
        "floorName": "Floor 2 (Rooftop Deck)",
        "slots": [
          {
            "id": "MP-2-21",
            "bayNumber": "21",
            "floor": "2",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MP-2-22",
            "bayNumber": "22",
            "floor": "2",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MP-2-23",
            "bayNumber": "23",
            "floor": "2",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MP-2-24",
            "bayNumber": "24",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "MP-2-25",
            "bayNumber": "25",
            "floor": "2",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MP-2-26",
            "bayNumber": "26",
            "floor": "2",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "MP-2-27",
            "bayNumber": "27",
            "floor": "2",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MP-2-28",
            "bayNumber": "28",
            "floor": "2",
            "type": "EV Charging",
            "status": "vacant",
            "vehicleType": null,
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "MP-2-29",
            "bayNumber": "29",
            "floor": "2",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "MP-2-30",
            "bayNumber": "30",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          }
        ]
      }
    ],
    "historicalOccupancy": [
      {
        "hour": "06:00",
        "occupancy": 15
      },
      {
        "hour": "07:00",
        "occupancy": 28
      },
      {
        "hour": "08:00",
        "occupancy": 65
      },
      {
        "hour": "09:00",
        "occupancy": 88
      },
      {
        "hour": "10:00",
        "occupancy": 92
      },
      {
        "hour": "11:00",
        "occupancy": 85
      },
      {
        "hour": "12:00",
        "occupancy": 75
      },
      {
        "hour": "13:00",
        "occupancy": 68
      },
      {
        "hour": "14:00",
        "occupancy": 60
      },
      {
        "hour": "15:00",
        "occupancy": 64
      },
      {
        "hour": "16:00",
        "occupancy": 72
      },
      {
        "hour": "17:00",
        "occupancy": 90
      },
      {
        "hour": "18:00",
        "occupancy": 95
      },
      {
        "hour": "19:00",
        "occupancy": 82
      },
      {
        "hour": "20:00",
        "occupancy": 65
      },
      {
        "hour": "21:00",
        "occupancy": 45
      },
      {
        "hour": "22:00",
        "occupancy": 30
      },
      {
        "hour": "23:00",
        "occupancy": 18
      }
    ]
  },
  {
    "id": "civic-center",
    "name": "Charminar Heritage Civic Hub",
    "city": "Hyderabad",
    "category": "Municipal Multi-Level Garage",
    "address": "Pathergatti Road, Near Charminar & High Court, Hyderabad, Telangana 500002",
    "landmark": "Charminar & High Court District",
    "distance": "4.2 km from Ameerpet Interchange",
    "lat": 17.3616,
    "lng": 78.4747,
    "mapX": 220,
    "mapY": 410,
    "baseTariffPerHour": 25,
    "evCharging": {
      "available": true,
      "types": [
        "Level-2 (22 kW)"
      ],
      "ratePerHour": 10,
      "fastRatePerHour": 0
    },
    "totalSpots": 30,
    "floors": [
      {
        "floorId": "G",
        "floorName": "Ground Floor (Level G)",
        "slots": [
          {
            "id": "CC-G-01",
            "bayNumber": "01",
            "floor": "G",
            "type": "Disabled",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "CC-G-02",
            "bayNumber": "02",
            "floor": "G",
            "type": "Disabled",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "CC-G-03",
            "bayNumber": "03",
            "floor": "G",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "CC-G-04",
            "bayNumber": "04",
            "floor": "G",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "CC-G-05",
            "bayNumber": "05",
            "floor": "G",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "CC-G-06",
            "bayNumber": "06",
            "floor": "G",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "CC-G-07",
            "bayNumber": "07",
            "floor": "G",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "CC-G-08",
            "bayNumber": "08",
            "floor": "G",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "CC-G-09",
            "bayNumber": "09",
            "floor": "G",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "CC-G-10",
            "bayNumber": "10",
            "floor": "G",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "Level-2 (22 kW)"
          }
        ]
      },
      {
        "floorId": "1",
        "floorName": "Floor 1 (Level 1)",
        "slots": [
          {
            "id": "CC-1-11",
            "bayNumber": "11",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "CC-1-12",
            "bayNumber": "12",
            "floor": "1",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "CC-1-13",
            "bayNumber": "13",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "CC-1-14",
            "bayNumber": "14",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "CC-1-15",
            "bayNumber": "15",
            "floor": "1",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "CC-1-16",
            "bayNumber": "16",
            "floor": "1",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "CC-1-17",
            "bayNumber": "17",
            "floor": "1",
            "type": "EV Charging",
            "status": "vacant",
            "vehicleType": null,
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "CC-1-18",
            "bayNumber": "18",
            "floor": "1",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "CC-1-19",
            "bayNumber": "19",
            "floor": "1",
            "type": "Disabled",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "CC-1-20",
            "bayNumber": "20",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          }
        ]
      },
      {
        "floorId": "2",
        "floorName": "Floor 2 (Level 2)",
        "slots": [
          {
            "id": "CC-2-21",
            "bayNumber": "21",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "CC-2-22",
            "bayNumber": "22",
            "floor": "2",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "CC-2-23",
            "bayNumber": "23",
            "floor": "2",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "CC-2-24",
            "bayNumber": "24",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "CC-2-25",
            "bayNumber": "25",
            "floor": "2",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "CC-2-26",
            "bayNumber": "26",
            "floor": "2",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "CC-2-27",
            "bayNumber": "27",
            "floor": "2",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "CC-2-28",
            "bayNumber": "28",
            "floor": "2",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "CC-2-29",
            "bayNumber": "29",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "CC-2-30",
            "bayNumber": "30",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          }
        ]
      }
    ],
    "historicalOccupancy": [
      {
        "hour": "06:00",
        "occupancy": 10
      },
      {
        "hour": "07:00",
        "occupancy": 20
      },
      {
        "hour": "08:00",
        "occupancy": 55
      },
      {
        "hour": "09:00",
        "occupancy": 85
      },
      {
        "hour": "10:00",
        "occupancy": 95
      },
      {
        "hour": "11:00",
        "occupancy": 90
      },
      {
        "hour": "12:00",
        "occupancy": 82
      },
      {
        "hour": "13:00",
        "occupancy": 74
      },
      {
        "hour": "14:00",
        "occupancy": 70
      },
      {
        "hour": "15:00",
        "occupancy": 76
      },
      {
        "hour": "16:00",
        "occupancy": 88
      },
      {
        "hour": "17:00",
        "occupancy": 92
      },
      {
        "hour": "18:00",
        "occupancy": 80
      },
      {
        "hour": "19:00",
        "occupancy": 60
      },
      {
        "hour": "20:00",
        "occupancy": 40
      },
      {
        "hour": "21:00",
        "occupancy": 25
      },
      {
        "hour": "22:00",
        "occupancy": 15
      },
      {
        "hour": "23:00",
        "occupancy": 10
      }
    ]
  },
  {
    "id": "tech-park",
    "name": "Cyber Towers Tech Deck",
    "city": "Hyderabad",
    "category": "Corporate Tech Corridor Deck",
    "address": "HITEC City Main Road, Opposite Cyber Gateway, Madhapur, Hyderabad, Telangana 500081",
    "landmark": "Cyber Towers & Mindspace IT Park",
    "distance": "6.5 km from Ameerpet Interchange",
    "lat": 17.4504,
    "lng": 78.3808,
    "mapX": 540,
    "mapY": 150,
    "baseTariffPerHour": 40,
    "evCharging": {
      "available": true,
      "types": [
        "Level-2 (22 kW)",
        "DC Fast (60 kW)"
      ],
      "ratePerHour": 15,
      "fastRatePerHour": 35
    },
    "totalSpots": 30,
    "floors": [
      {
        "floorId": "G",
        "floorName": "Ground Floor (Level G)",
        "slots": [
          {
            "id": "TP-G-01",
            "bayNumber": "01",
            "floor": "G",
            "type": "Disabled",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "TP-G-02",
            "bayNumber": "02",
            "floor": "G",
            "type": "Disabled",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "TP-G-03",
            "bayNumber": "03",
            "floor": "G",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "TP-G-04",
            "bayNumber": "04",
            "floor": "G",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "TP-G-05",
            "bayNumber": "05",
            "floor": "G",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "DC Fast (60 kW)"
          },
          {
            "id": "TP-G-06",
            "bayNumber": "06",
            "floor": "G",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "DC Fast (60 kW)"
          },
          {
            "id": "TP-G-07",
            "bayNumber": "07",
            "floor": "G",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "TP-G-08",
            "bayNumber": "08",
            "floor": "G",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "TP-G-09",
            "bayNumber": "09",
            "floor": "G",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "TP-G-10",
            "bayNumber": "10",
            "floor": "G",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          }
        ]
      },
      {
        "floorId": "1",
        "floorName": "Floor 1 (Level 1)",
        "slots": [
          {
            "id": "TP-1-11",
            "bayNumber": "11",
            "floor": "1",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "TP-1-12",
            "bayNumber": "12",
            "floor": "1",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "TP-1-13",
            "bayNumber": "13",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "TP-1-14",
            "bayNumber": "14",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "TP-1-15",
            "bayNumber": "15",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "TP-1-16",
            "bayNumber": "16",
            "floor": "1",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "TP-1-17",
            "bayNumber": "17",
            "floor": "1",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "TP-1-18",
            "bayNumber": "18",
            "floor": "1",
            "type": "Disabled",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "TP-1-19",
            "bayNumber": "19",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "TP-1-20",
            "bayNumber": "20",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          }
        ]
      },
      {
        "floorId": "2",
        "floorName": "Floor 2 (Level 2)",
        "slots": [
          {
            "id": "TP-2-21",
            "bayNumber": "21",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "TP-2-22",
            "bayNumber": "22",
            "floor": "2",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "TP-2-23",
            "bayNumber": "23",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "TP-2-24",
            "bayNumber": "24",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "TP-2-25",
            "bayNumber": "25",
            "floor": "2",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "TP-2-26",
            "bayNumber": "26",
            "floor": "2",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "TP-2-27",
            "bayNumber": "27",
            "floor": "2",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "TP-2-28",
            "bayNumber": "28",
            "floor": "2",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "TP-2-29",
            "bayNumber": "29",
            "floor": "2",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "TP-2-30",
            "bayNumber": "30",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          }
        ]
      }
    ],
    "historicalOccupancy": [
      {
        "hour": "06:00",
        "occupancy": 20
      },
      {
        "hour": "07:00",
        "occupancy": 35
      },
      {
        "hour": "08:00",
        "occupancy": 75
      },
      {
        "hour": "09:00",
        "occupancy": 95
      },
      {
        "hour": "10:00",
        "occupancy": 98
      },
      {
        "hour": "11:00",
        "occupancy": 96
      },
      {
        "hour": "12:00",
        "occupancy": 92
      },
      {
        "hour": "13:00",
        "occupancy": 88
      },
      {
        "hour": "14:00",
        "occupancy": 90
      },
      {
        "hour": "15:00",
        "occupancy": 92
      },
      {
        "hour": "16:00",
        "occupancy": 95
      },
      {
        "hour": "17:00",
        "occupancy": 98
      },
      {
        "hour": "18:00",
        "occupancy": 90
      },
      {
        "hour": "19:00",
        "occupancy": 70
      },
      {
        "hour": "20:00",
        "occupancy": 50
      },
      {
        "hour": "21:00",
        "occupancy": 30
      },
      {
        "hour": "22:00",
        "occupancy": 15
      },
      {
        "hour": "23:00",
        "occupancy": 5
      }
    ]
  },
  {
    "id": "marina-deck",
    "name": "Inorbit Mall & Durgam Cheruvu Deck",
    "city": "Hyderabad",
    "category": "Mall & Leisure Parking Complex",
    "address": "Mindspace Road, Beside Durgam Cheruvu Lake & Inorbit Mall, Madhapur, Hyderabad, Telangana 500081",
    "landmark": "Inorbit Mall & Durgam Cheruvu Cable Bridge",
    "distance": "7.2 km from Ameerpet Interchange",
    "lat": 17.4348,
    "lng": 78.3868,
    "mapX": 510,
    "mapY": 340,
    "baseTariffPerHour": 35,
    "evCharging": {
      "available": true,
      "types": [
        "Level-2 (22 kW)"
      ],
      "ratePerHour": 12,
      "fastRatePerHour": 0
    },
    "totalSpots": 30,
    "floors": [
      {
        "floorId": "G",
        "floorName": "Ground Floor (Level G)",
        "slots": [
          {
            "id": "MM-G-01",
            "bayNumber": "01",
            "floor": "G",
            "type": "Disabled",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-G-02",
            "bayNumber": "02",
            "floor": "G",
            "type": "Disabled",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-G-03",
            "bayNumber": "03",
            "floor": "G",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "MM-G-04",
            "bayNumber": "04",
            "floor": "G",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-G-05",
            "bayNumber": "05",
            "floor": "G",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-G-06",
            "bayNumber": "06",
            "floor": "G",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "MM-G-07",
            "bayNumber": "07",
            "floor": "G",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-G-08",
            "bayNumber": "08",
            "floor": "G",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "MM-G-09",
            "bayNumber": "09",
            "floor": "G",
            "type": "EV Charging",
            "status": "vacant",
            "vehicleType": null,
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "MM-G-10",
            "bayNumber": "10",
            "floor": "G",
            "type": "EV Charging",
            "status": "vacant",
            "vehicleType": null,
            "charger": "Level-2 (22 kW)"
          }
        ]
      },
      {
        "floorId": "1",
        "floorName": "Floor 1 (Level 1)",
        "slots": [
          {
            "id": "MM-1-11",
            "bayNumber": "11",
            "floor": "1",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-1-12",
            "bayNumber": "12",
            "floor": "1",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-1-13",
            "bayNumber": "13",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "MM-1-14",
            "bayNumber": "14",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "MM-1-15",
            "bayNumber": "15",
            "floor": "1",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-1-16",
            "bayNumber": "16",
            "floor": "1",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-1-17",
            "bayNumber": "17",
            "floor": "1",
            "type": "EV Charging",
            "status": "vacant",
            "vehicleType": null,
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "MM-1-18",
            "bayNumber": "18",
            "floor": "1",
            "type": "EV Charging",
            "status": "occupied",
            "vehicleType": "EV",
            "charger": "Level-2 (22 kW)"
          },
          {
            "id": "MM-1-19",
            "bayNumber": "19",
            "floor": "1",
            "type": "Disabled",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-1-20",
            "bayNumber": "20",
            "floor": "1",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          }
        ]
      },
      {
        "floorId": "2",
        "floorName": "Floor 2 (Level 2)",
        "slots": [
          {
            "id": "MM-2-21",
            "bayNumber": "21",
            "floor": "2",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-2-22",
            "bayNumber": "22",
            "floor": "2",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-2-23",
            "bayNumber": "23",
            "floor": "2",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-2-24",
            "bayNumber": "24",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          },
          {
            "id": "MM-2-25",
            "bayNumber": "25",
            "floor": "2",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-2-26",
            "bayNumber": "26",
            "floor": "2",
            "type": "Compact",
            "status": "occupied",
            "vehicleType": "2-Wheeler",
            "charger": null
          },
          {
            "id": "MM-2-27",
            "bayNumber": "27",
            "floor": "2",
            "type": "Compact",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-2-28",
            "bayNumber": "28",
            "floor": "2",
            "type": "Standard",
            "status": "vacant",
            "vehicleType": null,
            "charger": null
          },
          {
            "id": "MM-2-29",
            "bayNumber": "29",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "SUV",
            "charger": null
          },
          {
            "id": "MM-2-30",
            "bayNumber": "30",
            "floor": "2",
            "type": "Standard",
            "status": "occupied",
            "vehicleType": "Sedan",
            "charger": null
          }
        ]
      }
    ],
    "historicalOccupancy": [
      {
        "hour": "06:00",
        "occupancy": 5
      },
      {
        "hour": "07:00",
        "occupancy": 10
      },
      {
        "hour": "08:00",
        "occupancy": 20
      },
      {
        "hour": "09:00",
        "occupancy": 35
      },
      {
        "hour": "10:00",
        "occupancy": 45
      },
      {
        "hour": "11:00",
        "occupancy": 55
      },
      {
        "hour": "12:00",
        "occupancy": 70
      },
      {
        "hour": "13:00",
        "occupancy": 75
      },
      {
        "hour": "14:00",
        "occupancy": 65
      },
      {
        "hour": "15:00",
        "occupancy": 68
      },
      {
        "hour": "16:00",
        "occupancy": 78
      },
      {
        "hour": "17:00",
        "occupancy": 85
      },
      {
        "hour": "18:00",
        "occupancy": 90
      },
      {
        "hour": "19:00",
        "occupancy": 92
      },
      {
        "hour": "20:00",
        "occupancy": 88
      },
      {
        "hour": "21:00",
        "occupancy": 70
      },
      {
        "hour": "22:00",
        "occupancy": 40
      },
      {
        "hour": "23:00",
        "occupancy": 15
      }
    ]
  }
];
