// SlotSpot: Interactive 2D Parking Lot Occupancy Grid & Floorplan

const ParkingGrid = (function () {
  let containerEl = null;
  let currentHub = null;
  let currentFloorId = '1';
  let activeFilter = 'all';
  let onSlotSelectCallback = null;
  let selectedSlotId = null;

  function init(containerId, onSlotSelect) {
    containerEl = document.getElementById(containerId);
    onSlotSelectCallback = onSlotSelect;
  }

  function setHub(hub, floorId = null) {
    currentHub = hub;
    if (floorId) {
      currentFloorId = floorId;
    } else if (!currentHub.floors.some(f => f.floorId === currentFloorId)) {
      currentFloorId = currentHub.floors[0] ? currentHub.floors[0].floorId : 'G';
    }
    render();
  }

  function updateSlotStatus(slotId, newStatus, vehicleType = null) {
    if (!currentHub) return;
    for (const fl of currentHub.floors) {
      const slot = fl.slots.find(s => s.id === slotId);
      if (slot) {
        slot.status = newStatus;
        if (vehicleType) slot.vehicleType = vehicleType;
        break;
      }
    }
    renderFloorTabs();
    const slotEl = document.getElementById(`slot-card-${slotId}`);
    if (slotEl) {
      updateSlotElement(slotEl, newStatus);
    }
  }

  function setSelectedSlot(slotId) {
    selectedSlotId = slotId;
    document.querySelectorAll('.parking-bay-card').forEach(card => {
      if (card.dataset.slotId === slotId) {
        card.classList.add('is-selected-bay');
      } else {
        card.classList.remove('is-selected-bay');
      }
    });
  }

  function updateSlotElement(slotEl, status) {
    slotEl.classList.remove('status-vacant', 'status-occupied', 'status-locked', 'status-reserved', 'pulse-update');
    slotEl.classList.add(`status-${status}`, 'pulse-update');
    const badge = slotEl.querySelector('.status-pill');
    if (badge) {
      badge.textContent = status.toUpperCase();
      badge.className = `status-pill status-${status}`;
    }
    setTimeout(() => slotEl.classList.remove('pulse-update'), 1200);
  }

  function render() {
    if (!containerEl || !currentHub) return;

    const floor = currentHub.floors.find(f => f.floorId === currentFloorId) || currentHub.floors[0];

    containerEl.innerHTML = `
      <div class="grid-view-container">
        <div class="floorplan-header">
          <div class="floor-tabs-bar" id="floorTabsBar"></div>
          
          <div class="grid-filter-toolbar">
            <span class="filter-label">Filter:</span>
            <div class="filter-pill-group">
              <button class="filter-btn ${activeFilter === 'all' ? 'active' : ''}" data-filter="all">All Bays</button>
              <button class="filter-btn ${activeFilter === 'ev' ? 'active' : ''}" data-filter="ev">⚡ EV Only</button>
              <button class="filter-btn ${activeFilter === 'vacant' ? 'active' : ''}" data-filter="vacant">🟢 Vacant</button>
              <button class="filter-btn ${activeFilter === 'compact' ? 'active' : ''}" data-filter="compact">🛵 Compact</button>
              <button class="filter-btn ${activeFilter === 'disabled' ? 'active' : ''}" data-filter="disabled">♿ Accessible</button>
            </div>
          </div>
        </div>

        <div class="floorplan-schematic-wrapper">
          <div class="schematic-gate-banner entry-gate">
            <span class="gate-icon">➔</span> <strong>GATE A: MAIN INGRESS</strong> (Speed limit: 10 km/h)
          </div>

          <div class="parking-bays-grid" id="parkingBaysGrid"></div>

          <div class="schematic-aisle-divider">
            <div class="lane-marking"></div>
            <span class="aisle-text">↕ CENTRAL CIRCULATION AISLE ↕</span>
            <div class="lane-marking"></div>
          </div>

          <div class="schematic-gate-banner exit-gate">
            <strong>GATE B: EGRESS &amp; PAYMENT BARRIER</strong> <span class="gate-icon">➔</span>
          </div>
        </div>

        <div id="navGuideOverlay" class="nav-guide-overlay hidden"></div>
      </div>
    `;

    renderFloorTabs();
    renderSlots(floor);
    setupFilterEvents();
  }

  function renderFloorTabs() {
    const tabsBar = document.getElementById('floorTabsBar');
    if (!tabsBar || !currentHub) return;

    let tabsHTML = '';
    currentHub.floors.forEach(fl => {
      const isCurrent = fl.floorId === currentFloorId;
      const vacantCount = fl.slots.filter(s => s.status === 'vacant').length;
      const totalCount = fl.slots.length;
      const evCount = fl.slots.filter(s => s.type === 'EV Charging').length;

      tabsHTML += `
        <button class="floor-tab-btn ${isCurrent ? 'active' : ''}" data-floor-id="${fl.floorId}">
          <span class="floor-tab-name">Floor ${fl.floorId}</span>
          <span class="floor-summary-chip ${vacantCount > 3 ? 'chip-green' : (vacantCount > 0 ? 'chip-amber' : 'chip-red')}">
            ${vacantCount}/${totalCount} Vacant
          </span>
          ${evCount > 0 ? `<span class="floor-ev-chip" title="${evCount} EV Charging points">⚡ ${evCount} EV</span>` : ''}
        </button>
      `;
    });

    tabsBar.innerHTML = tabsHTML;

    tabsBar.querySelectorAll('.floor-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const fId = btn.getAttribute('data-floor-id');
        currentFloorId = fId;
        const fl = currentHub.floors.find(f => f.floorId === fId);
        tabsBar.querySelectorAll('.floor-tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderSlots(fl);
      });
    });
  }

  function renderSlots(floor) {
    const gridEl = document.getElementById('parkingBaysGrid');
    if (!gridEl || !floor) return;

    let slotsHTML = '';

    floor.slots.forEach((slot) => {
      if (activeFilter === 'ev' && slot.type !== 'EV Charging') return;
      if (activeFilter === 'vacant' && slot.status !== 'vacant') return;
      if (activeFilter === 'compact' && slot.type !== 'Compact') return;
      if (activeFilter === 'disabled' && slot.type !== 'Disabled') return;

      const isVacant = slot.status === 'vacant';
      const isSelected = selectedSlotId === slot.id;

      let typeIcon = '🚗';
      let typeBadge = 'Standard';
      if (slot.type === 'EV Charging') {
        typeIcon = '⚡';
        typeBadge = slot.charger || 'EV Level-2';
      } else if (slot.type === 'Compact') {
        typeIcon = '🛵';
        typeBadge = 'Compact / 2W';
      } else if (slot.type === 'Disabled') {
        typeIcon = '♿';
        typeBadge = 'Accessible';
      }

      let occupiedIcon = '🚗';
      if (slot.status === 'occupied') {
        if (slot.vehicleType === '2-Wheeler') occupiedIcon = '🛵';
        else if (slot.vehicleType === 'SUV') occupiedIcon = '🚙';
        else if (slot.vehicleType === 'EV') occupiedIcon = '⚡🚙';
        else occupiedIcon = '🚗';
      }

      slotsHTML += `
        <div class="parking-bay-card status-${slot.status} type-${slot.type.toLowerCase().replace(/\s+/g, '-')} ${isSelected ? 'is-selected-bay' : ''}"
             id="slot-card-${slot.id}"
             data-slot-id="${slot.id}"
             data-bay-number="${slot.bayNumber}"
             data-status="${slot.status}"
             data-type="${slot.type}">
          
          <div class="bay-header">
            <span class="bay-number">#${slot.bayNumber}</span>
            <span class="status-pill status-${slot.status}">${slot.status.toUpperCase()}</span>
          </div>

          <div class="bay-stall-visual">
            <div class="stall-paint-lines"></div>
            
            ${isVacant ? `
              <div class="stall-vacant-indicator">
                <span class="open-icon">🟢</span>
                <span class="open-text">AVAILABLE</span>
              </div>
            ` : `
              <div class="stall-occupied-indicator">
                <span class="car-silhouette">${occupiedIcon}</span>
                <span class="occupied-vehicle">${slot.status === 'locked' ? 'LOCK PENDING' : (slot.vehicleType || 'Occupied')}</span>
              </div>
            `}
          </div>

          <div class="bay-footer">
            <span class="bay-type-tag" title="${typeBadge}">
              <span class="type-icon">${typeIcon}</span> ${typeBadge}
            </span>
            ${isVacant ? `
              <button class="btn-reserve-bay" data-slot-id="${slot.id}">
                Reserve
              </button>
            ` : `
              <span class="bay-lock-tag">${slot.status === 'locked' ? '⏳ 15m Hold' : 'Unavailable'}</span>
            `}
          </div>
        </div>
      `;
    });

    if (slotsHTML === '') {
      slotsHTML = `<div class="empty-filter-state">No parking bays match the selected filter on Floor ${currentFloorId}.</div>`;
    }

    gridEl.innerHTML = slotsHTML;

    gridEl.querySelectorAll('.parking-bay-card').forEach(card => {
      card.addEventListener('click', () => {
        const slotId = card.getAttribute('data-slot-id');
        const status = card.getAttribute('data-status');
        
        if (status === 'vacant') {
          setSelectedSlot(slotId);
          const slot = floor.slots.find(s => s.id === slotId);
          if (onSlotSelectCallback) {
            onSlotSelectCallback(slot, currentHub, floor);
          }
        } else {
          card.classList.add('shake-anim');
          setTimeout(() => card.classList.remove('shake-anim'), 500);
        }
      });
    });
  }

  function setupFilterEvents() {
    document.querySelectorAll('.filter-pill-group .filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-pill-group .filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeFilter = btn.getAttribute('data-filter');
        const fl = currentHub.floors.find(f => f.floorId === currentFloorId);
        renderSlots(fl);
      });
    });
  }

  return {
    init,
    setHub,
    updateSlotStatus,
    setSelectedSlot,
    getCurrentHub: () => currentHub,
    getCurrentFloorId: () => currentFloorId
  };
})();
