// SlotSpot: Live Sensor Telemetry Stream, Pulse Animator & Overstay Alert Simulator

const TelemetryManager = (function () {
  let eventSource = null;
  let logListEl = null;
  let simulationRunning = true;
  let onPulseCallback = null;
  let clientSimInterval = null;

  function init(onPulse) {
    onPulseCallback = onPulse;
    logListEl = document.getElementById('telemetryLogStream');
    connectSSE();
    setupControls();
  }

  function startClientSimulation() {
    if (clientSimInterval) return;
    clientSimInterval = setInterval(() => {
      if (!simulationRunning) return;
      const hubs = window.SlotSpotApp ? window.SlotSpotApp.getHubs() : [];
      if (!hubs || hubs.length === 0) return;

      const randomHub = hubs[Math.floor(Math.random() * hubs.length)];
      if (!randomHub || !randomHub.floors) return;
      const randomFloor = randomHub.floors[Math.floor(Math.random() * randomHub.floors.length)];
      if (!randomFloor || !randomFloor.slots) return;

      const eligible = randomFloor.slots.filter(s => s.status !== 'locked' && s.status !== 'reserved' && s.id !== 'MP-1-12');
      if (eligible.length === 0) return;

      const slot = eligible[Math.floor(Math.random() * eligible.length)];
      const previousStatus = slot.status;
      const newStatus = previousStatus === 'vacant' ? 'occupied' : 'vacant';
      slot.status = newStatus;

      const eventData = {
        hubId: randomHub.id,
        hubName: randomHub.name,
        floorId: randomFloor.floorId,
        slotId: slot.id,
        bayNumber: slot.bayNumber,
        previousStatus,
        newStatus,
        timestamp: new Date().toLocaleTimeString()
      };

      addLogEntry(eventData);
      if (onPulseCallback) onPulseCallback('pulse', eventData);
    }, 12000);
  }

  function connectSSE() {
    try {
      eventSource = new EventSource('/api/telemetry/events');

      eventSource.addEventListener('telemetry_pulse', (e) => {
        const data = JSON.parse(e.data);
        addLogEntry(data);
        if (onPulseCallback) onPulseCallback('pulse', data);
      });

      eventSource.addEventListener('slot_updated', (e) => {
        const data = JSON.parse(e.data);
        if (onPulseCallback) onPulseCallback('slot_updated', data);
      });

      eventSource.addEventListener('hub_stats_updated', (e) => {
        const data = JSON.parse(e.data);
        if (onPulseCallback) onPulseCallback('stats_updated', data);
      });

      eventSource.onerror = () => {
        startClientSimulation();
      };
    } catch (err) {
      console.warn('SSE initialization failed, fallback to local simulator.', err);
      startClientSimulation();
    }
  }

  function addLogEntry(data) {
    if (!logListEl) logListEl = document.getElementById('telemetryLogStream');
    if (!logListEl) return;

    const li = document.createElement('div');
    li.className = 'telemetry-log-item';
    const isOccupied = data.newStatus === 'occupied';

    li.innerHTML = `
      <span class="log-time">${data.timestamp || new Date().toLocaleTimeString()}</span>
      <span class="log-dot ${isOccupied ? 'dot-red' : 'dot-green'}"></span>
      <span class="log-hub">${data.hubName || 'Garage'} [Floor ${data.floorId}]</span>
      <span class="log-text">Bay #${data.bayNumber} ➔ <strong>${(data.newStatus || '').toUpperCase()}</strong></span>
    `;

    logListEl.prepend(li);

    while (logListEl.children.length > 15) {
      logListEl.removeChild(logListEl.lastChild);
    }

    const livePill = document.getElementById('telemetryLivePill');
    if (livePill) {
      livePill.classList.add('flash-radar');
      setTimeout(() => livePill.classList.remove('flash-radar'), 800);
    }
  }

  function setupControls() {
    const triggerBtn = document.getElementById('btnTriggerSensorPulse');
    if (triggerBtn) {
      triggerBtn.addEventListener('click', async () => {
        triggerBtn.disabled = true;
        try {
          await fetch('/api/telemetry/trigger', { method: 'POST' });
        } catch (e) {
          // Local trigger fallback
          const hubs = window.SlotSpotApp ? window.SlotSpotApp.getHubs() : [];
          if (hubs.length > 0) {
            const h = hubs[0];
            const f = h.floors[0];
            const s = f.slots.find(x => x.status === 'vacant' && x.id !== 'MP-1-12') || f.slots[0];
            s.status = s.status === 'vacant' ? 'occupied' : 'vacant';
            addLogEntry({
              hubId: h.id,
              hubName: h.name,
              floorId: f.floorId,
              slotId: s.id,
              bayNumber: s.bayNumber,
              newStatus: s.status,
              timestamp: new Date().toLocaleTimeString()
            });
            if (onPulseCallback) onPulseCallback('pulse', { hubId: h.id, slotId: s.id, newStatus: s.status });
          }
        }
        setTimeout(() => triggerBtn.disabled = false, 600);
      });
    }

    const toggleBtn = document.getElementById('btnToggleTelemetry');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', async () => {
        simulationRunning = !simulationRunning;
        try {
          await fetch('/api/telemetry/toggle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ running: simulationRunning })
          });
        } catch (e) {}
        toggleBtn.textContent = simulationRunning ? '⏸ Pause Telemetry' : '▶ Resume Telemetry';
      });
    }

    const resetBtn = document.getElementById('btnResetDemoState');
    if (resetBtn) {
      resetBtn.addEventListener('click', async () => {
        if (confirm('Reset Hyderabad Metro Plaza to 14 vacant spots (demo baseline)?')) {
          try {
            await fetch('/api/simulate/reset', { method: 'POST' });
          } catch (e) {}
          window.location.reload();
        }
      });
    }

    const overstayBtn = document.getElementById('btnSimulateOverstay');
    if (overstayBtn) {
      overstayBtn.addEventListener('click', () => {
        triggerOverstayModal();
      });
    }
  }

  function triggerOverstayModal() {
    const modal = document.getElementById('overstayAlertModal');
    if (!modal) return;

    const activeRes = window.ReservationManager && window.ReservationManager.getActiveReservation ? window.ReservationManager.getActiveReservation() : null;
    const alertMsgEl = modal.querySelector('.overstay-alert-msg');
    if (alertMsgEl) {
      if (activeRes) {
        alertMsgEl.innerHTML = `<strong>10-Minute Alert:</strong> Your paid parking session at <strong>${activeRes.hubName} (Bay #${activeRes.bayNumber})</strong> is scheduled to end in 10 minutes.`;
      } else {
        alertMsgEl.innerHTML = `<strong>10-Minute Alert:</strong> Your paid parking session at <strong>Metro Plaza Garage, Ameerpet (Bay #12)</strong> is scheduled to end in 10 minutes.`;
      }
    }

    modal.classList.remove('hidden');

    document.getElementById('btnExtendOverstay').onclick = () => {
      alert('Session extended by 1 Hour (+₹40 billed to token). Safe travels across Hyderabad!');
      modal.classList.add('hidden');
    };

    document.getElementById('btnDismissOverstay').onclick = () => {
      modal.classList.add('hidden');
    };
  }

  return {
    init,
    triggerOverstayModal
  };
})();

window.TelemetryManager = TelemetryManager;
