// Lightweight Self-Contained QR Code Generator for SlotSpot Digital Parking Passes

(function (root, factory) {
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.SlotSpotQR = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {

  function generateMatrix(text) {
    const size = 25;
    const matrix = [];
    for (let r = 0; r < size; r++) {
      matrix.push(new Array(size).fill(0));
    }

    function drawFinder(row, col) {
      for (let r = -1; r <= 7; r++) {
        for (let c = -1; c <= 7; c++) {
          const cr = row + r;
          const cc = col + c;
          if (cr < 0 || cr >= size || cc < 0 || cc >= size) continue;
          if (
            (r >= 0 && r <= 6 && (c === 0 || c === 6)) ||
            (c >= 0 && c <= 6 && (r === 0 || r === 6)) ||
            (r >= 2 && r <= 4 && c >= 2 && c <= 4)
          ) {
            matrix[cr][cc] = 1;
          } else {
            matrix[cr][cc] = 0;
          }
        }
      }
    }

    drawFinder(0, 0);
    drawFinder(0, size - 7);
    drawFinder(size - 7, 0);

    for (let i = 8; i < size - 8; i++) {
      matrix[6][i] = (i % 2 === 0) ? 1 : 0;
      matrix[i][6] = (i % 2 === 0) ? 1 : 0;
    }

    const ar = 16, ac = 16;
    for (let r = -2; r <= 2; r++) {
      for (let c = -2; c <= 2; c++) {
        if (Math.abs(r) === 2 || Math.abs(c) === 2 || (r === 0 && c === 0)) {
          matrix[ar + r][ac + c] = 1;
        } else {
          matrix[ar + r][ac + c] = 0;
        }
      }
    }

    let hash = 0;
    for (let i = 0; i < text.length; i++) {
      hash = ((hash << 5) - hash) + text.charCodeAt(i);
      hash |= 0;
    }

    let seed = Math.abs(hash);
    function nextBit() {
      seed = (seed * 1664525 + 1013904223) % 4294967296;
      return (seed >> 16) % 2 === 0 ? 1 : 0;
    }

    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (
          (r <= 7 && c <= 7) ||
          (r <= 7 && c >= size - 8) ||
          (r >= size - 8 && c <= 7) ||
          (r === 6) || (c === 6) ||
          (Math.abs(r - 16) <= 2 && Math.abs(c - 16) <= 2)
        ) {
          continue;
        }
        matrix[r][c] = nextBit();
      }
    }

    return { size, matrix };
  }

  return {
    renderSVG: function (text, pixelSize = 6) {
      const { size, matrix } = generateMatrix(String(text));
      const quietZone = 2;
      const totalModules = size + quietZone * 2;
      const totalPx = totalModules * pixelSize;

      let rects = '';
      for (let r = 0; r < size; r++) {
        for (let c = 0; c < size; c++) {
          if (matrix[r][c] === 1) {
            const x = (c + quietZone) * pixelSize;
            const y = (r + quietZone) * pixelSize;
            rects += `<rect x="${x}" y="${y}" width="${pixelSize}" height="${pixelSize}" fill="#0f172a" />`;
          }
        }
      }

      return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${totalPx} ${totalPx}" width="${totalPx}" height="${totalPx}">
        <rect width="${totalPx}" height="${totalPx}" fill="#ffffff" rx="8"/>
        ${rects}
      </svg>`;
    },

    renderToCanvas: function (canvas, text, pixelSize = 6) {
      const { size, matrix } = generateMatrix(String(text));
      const quietZone = 2;
      const totalModules = size + quietZone * 2;
      const totalPx = totalModules * pixelSize;

      canvas.width = totalPx;
      canvas.height = totalPx;
      const ctx = canvas.getContext('2d');

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, totalPx, totalPx);

      ctx.fillStyle = '#0f172a';
      for (let r = 0; r < size; r++) {
        for (let c = 0; c < size; c++) {
          if (matrix[r][c] === 1) {
            ctx.fillRect(
              (c + quietZone) * pixelSize,
              (r + quietZone) * pixelSize,
              pixelSize,
              pixelSize
            );
          }
        }
      }
    }
  };
});
