// SlotSpot: Spot Reservation, 15-Minute Hold Timer & Digital Pass Receipt Component

const ReservationManager = (function () {
  let activeReservation = null;
  let countdownInterval = null;
  let holdRemainingSeconds = 900;
  let onStatusChangeCallback = null;

  const isDirectNode = window.location.port === '3000';
  const API_BASE = isDirectNode ? '' : (window.location.protocol.startsWith('http') ? 'http://127.0.0.1:3000' : '');

  function init(onStatusChange) {
    onStatusChangeCallback = onStatusChange;
    setupGlobalHoldBanner();
  }

  function openReservationModal(slot, hub, floor) {
    const modalEl = document.getElementById('reservationModal');
    if (!modalEl) return;

    const isEV = slot.type === 'EV Charging';
    const vehicleTypeSelect = document.getElementById('resVehicleType');
    const durationSelect = document.getElementById('resDuration');
    const plateInput = document.getElementById('resPlateNumber');
    const nameInput = document.getElementById('resDriverName');

    if (vehicleTypeSelect) {
      vehicleTypeSelect.value = isEV ? 'EV' : (slot.type === 'Compact' ? '2-Wheeler' : 'Sedan');
    }
    if (durationSelect) durationSelect.value = '2';
    if (plateInput && !plateInput.value) plateInput.value = 'TS 09 AB 7720';
    if (nameInput && !nameInput.value) nameInput.value = 'Harry (Motorist)';

    document.getElementById('modalBayNumber').textContent = `#${slot.bayNumber}`;
    document.getElementById('modalHubName').textContent = hub.name;
    document.getElementById('modalFloorName').textContent = floor.floorName;
    document.getElementById('modalSlotType').textContent = `${slot.type} ${slot.charger ? '• ' + slot.charger : ''}`;

    updateFeePreview(slot, hub);

    vehicleTypeSelect.onchange = () => updateFeePreview(slot, hub);
    durationSelect.onchange = () => updateFeePreview(slot, hub);

    const lockBtn = document.getElementById('btnConfirmLock');
    lockBtn.onclick = () => handleLockSpot(slot, hub, floor);

    modalEl.classList.remove('hidden');
  }

  function updateFeePreview(slot, hub) {
    const vehicleType = document.getElementById('resVehicleType').value;
    const duration = parseInt(document.getElementById('resDuration').value) || 2;
    const isEV = slot.type === 'EV Charging';

    const calc = TariffCalculator.calculate({
      baseTariffPerHour: hub.baseTariffPerHour,
      occupancyRate: hub.occupancyRate || 50,
      vehicleType,
      durationHours: duration,
      isEVBay: isEV,
      chargerType: slot.charger
    });

    const previewContainer = document.getElementById('modalTariffBreakdown');
    if (previewContainer) {
      previewContainer.innerHTML = TariffCalculator.renderBreakdownHTML(calc);
    }
  }

  async function handleLockSpot(slot, hub, floor) {
    const vehicleType = document.getElementById('resVehicleType').value;
    const durationHours = parseInt(document.getElementById('resDuration').value) || 2;
    const plateNumber = document.getElementById('resPlateNumber').value.trim() || 'TS 09 AB 7720';
    const driverName = document.getElementById('resDriverName').value.trim() || 'Motorist';

    const lockBtn = document.getElementById('btnConfirmLock');
    lockBtn.disabled = true;
    lockBtn.textContent = 'Securing 15-Min Hold...';

    let reservation = null;

    // 1. Try server lock
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (window.AuthManager && AuthManager.getToken()) {
        headers['Authorization'] = `Bearer ${AuthManager.getToken()}`;
      }

      const response = await fetch(`${API_BASE}/api/slots/lock`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          hubId: hub.id,
          slotId: slot.id,
          vehicleType,
          durationHours,
          chargerType: slot.charger,
          plateNumber,
          driverName
        })
      });

      const data = await response.json();
      if (response.ok && data.success && data.reservation) {
        reservation = data.reservation;
      } else if (!response.ok) {
        alert(data.error || 'Server validation error. Please check pricing and vehicle details.');
        lockBtn.disabled = false;
        lockBtn.textContent = 'Lock Bay (15-Min Hold)';
        return;
      }
    } catch (err) {
      // Local fallback
    }

    // 2. Client-side local fallback (supports Live Server 5500 perfectly!)
    if (!reservation) {
      const calc = TariffCalculator.calculate({
        baseTariffPerHour: hub.baseTariffPerHour,
        occupancyRate: hub.occupancyRate || 50,
        vehicleType,
        durationHours,
        isEVBay: slot.type === 'EV Charging',
        chargerType: slot.charger
      });

      reservation = {
        id: 'RES-' + Math.random().toString(36).substring(2, 8).toUpperCase(),
        hubId: hub.id,
        hubName: hub.name,
        address: hub.address,
        floorId: floor.floorId,
        floorName: floor.floorName,
        slotId: slot.id,
        bayNumber: slot.bayNumber,
        slotType: slot.type,
        charger: slot.charger,
        vehicleType: calc.vehicleType,
        plateNumber,
        driverName,
        durationHours: calc.durationHours,
        totalFee: calc.totalTariff,
        feeBreakdown: calc,
        createdAt: Date.now(),
        expiresAt: Date.now() + 15 * 60 * 1000,
        status: 'locked'
      };
    }

    document.getElementById('reservationModal').classList.add('hidden');
    lockBtn.disabled = false;
    lockBtn.textContent = 'Lock Bay (15-Min Hold)';

    activeReservation = reservation;
    startHoldCountdown(reservation.expiresAt);
    openHoldActiveModal(reservation);

    if (onStatusChangeCallback) {
      onStatusChangeCallback('locked', reservation);
    }
  }

  function startHoldCountdown(expiresAt) {
    if (countdownInterval) clearInterval(countdownInterval);

    function update() {
      const now = Date.now();
      const remainingMs = Math.max(0, expiresAt - now);
      holdRemainingSeconds = Math.floor(remainingMs / 1000);

      const minutes = Math.floor(holdRemainingSeconds / 60);
      const seconds = holdRemainingSeconds % 60;
      const timeStr = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

      const timerEls = document.querySelectorAll('.countdown-timer-display');
      timerEls.forEach(el => el.textContent = timeStr);

      const bannerTimer = document.getElementById('bannerHoldTimer');
      if (bannerTimer) bannerTimer.textContent = timeStr;

      const progressRing = document.getElementById('countdownProgressRing');
      if (progressRing) {
        const total = 900;
        const progress = holdRemainingSeconds / total;
        const circumference = 2 * Math.PI * 45;
        progressRing.style.strokeDashoffset = circumference * (1 - progress);
      }

      if (holdRemainingSeconds <= 0) {
        clearInterval(countdownInterval);
        handleHoldExpired();
      }
    }

    update();
    countdownInterval = setInterval(update, 1000);
    showHoldBanner(true);
  }

  function openHoldActiveModal(reservation) {
    const modal = document.getElementById('holdActiveModal');
    if (!modal) return;

    document.getElementById('holdBayNumber').textContent = `#${reservation.bayNumber}`;
    document.getElementById('holdHubName').textContent = reservation.hubName;
    document.getElementById('holdFloorName').textContent = reservation.floorName;
    document.getElementById('holdVehiclePlate').textContent = `${reservation.vehicleType} • ${reservation.plateNumber}`;
    document.getElementById('holdTotalTariff').textContent = `₹${reservation.totalFee}`;

    document.getElementById('btnConfirmBooking').onclick = () => handleConfirmBooking(reservation.id);
    document.getElementById('btnCancelHold').onclick = () => handleCancelHold(reservation.id);

    modal.classList.remove('hidden');
  }

  async function handleConfirmBooking(reservationId) {
    const btn = document.getElementById('btnConfirmBooking');
    btn.disabled = true;
    btn.textContent = 'Generating Digital Pass...';

    let confirmedRes = null;
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (window.AuthManager && AuthManager.getToken()) {
        headers['Authorization'] = `Bearer ${AuthManager.getToken()}`;
      }

      const res = await fetch(`${API_BASE}/api/slots/confirm`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ reservationId })
      });
      const data = await res.json();
      if (res.ok && data.success && data.reservation) {
        confirmedRes = data.reservation;
      } else if (!res.ok) {
        alert(data.error || 'Failed to confirm booking.');
        btn.disabled = false;
        btn.textContent = 'Confirm Booking & Pay';
        return;
      }
    } catch (err) {
      // Local fallback
    }

    if (!confirmedRes && activeReservation) {
      activeReservation.status = 'reserved';
      activeReservation.confirmedAt = Date.now();
      activeReservation.qrToken = `SLOTSPOT:${activeReservation.id}:${activeReservation.hubId}:${activeReservation.slotId}:${activeReservation.plateNumber}`;
      confirmedRes = activeReservation;
    }

    btn.disabled = false;
    btn.textContent = 'Confirm Booking & Pay';

    document.getElementById('holdActiveModal').classList.add('hidden');
    activeReservation = confirmedRes;

    if (countdownInterval) clearInterval(countdownInterval);
    showHoldBanner(false);

    openDigitalPassModal(confirmedRes);

    if (onStatusChangeCallback) {
      onStatusChangeCallback('reserved', confirmedRes);
    }
  }

  async function handleCancelHold(reservationId) {
    if (!confirm('Are you sure you want to release this parking bay?')) return;

    try {
      const headers = { 'Content-Type': 'application/json' };
      if (window.AuthManager && AuthManager.getToken()) {
        headers['Authorization'] = `Bearer ${AuthManager.getToken()}`;
      }

      await fetch(`${API_BASE}/api/slots/cancel`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ reservationId })
      });
    } catch (err) {}

    if (countdownInterval) clearInterval(countdownInterval);
    activeReservation = null;
    showHoldBanner(false);
    document.getElementById('holdActiveModal').classList.add('hidden');

    if (onStatusChangeCallback) {
      onStatusChangeCallback('vacant', null);
    }
  }

  function handleHoldExpired() {
    alert('Your 15-minute reservation hold has expired. The bay has been released to the public.');
    showHoldBanner(false);
    activeReservation = null;
    const holdModal = document.getElementById('holdActiveModal');
    if (holdModal) holdModal.classList.add('hidden');
    if (onStatusChangeCallback) {
      onStatusChangeCallback('vacant', null);
    }
  }

  function openDigitalPassModal(reservation) {
    const modal = document.getElementById('digitalPassModal');
    if (!modal) return;

    document.getElementById('passTokenId').textContent = reservation.id;
    document.getElementById('passHubName').textContent = reservation.hubName;
    document.getElementById('passAddress').textContent = reservation.address;
    document.getElementById('passBayNumber').textContent = `Bay #${reservation.bayNumber}`;
    document.getElementById('passFloorLevel').textContent = reservation.floorName;
    document.getElementById('passVehicleType').textContent = reservation.vehicleType;
    document.getElementById('passPlateNumber').textContent = reservation.plateNumber;
    document.getElementById('passDuration').textContent = `${reservation.durationHours} Hours`;
    document.getElementById('passTariffAmount').textContent = `₹${reservation.totalFee}.00`;
    
    const entryTime = new Date(reservation.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const validUntil = new Date(reservation.createdAt + reservation.durationHours * 3600 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    document.getElementById('passTimeWindow').textContent = `${entryTime} – ${validUntil}`;

    const barcodeEl = document.querySelector('.barcode-number');
    if (barcodeEl) {
      barcodeEl.textContent = `*HYD-PKP-${reservation.hubId.toUpperCase()}-${reservation.bayNumber}*`;
    }

    const qrContainer = document.getElementById('passQRCodeContainer');
    if (qrContainer && window.SlotSpotQR) {
      const qrPayload = `SLOTSPOT-PASS:${reservation.id}:${reservation.hubId}:${reservation.bayNumber}:${reservation.plateNumber}`;
      qrContainer.innerHTML = window.SlotSpotQR.renderSVG(qrPayload, 6);
    }

    const scanGateBtn = document.getElementById('btnSimulateGateScan');
    if (scanGateBtn) {
      scanGateBtn.onclick = () => simulateGateScan(reservation);
    }

    const navGuideBtn = document.getElementById('btnShowNavGuide');
    if (navGuideBtn) {
      navGuideBtn.onclick = () => {
        modal.classList.add('hidden');
        if (window.NavigationGuide) {
          window.NavigationGuide.showRoute(reservation.bayNumber, reservation.floorId, reservation.slotId);
        }
      };
    }

    const printBtn = document.getElementById('btnPrintPass');
    if (printBtn) {
      printBtn.onclick = () => window.print();
    }

    const downloadBtn = document.getElementById('btnDownloadPass');
    if (downloadBtn) {
      downloadBtn.onclick = () => downloadPassText(reservation);
    }

    modal.classList.remove('hidden');
  }

  async function simulateGateScan(reservation) {
    const scanBtn = document.getElementById('btnSimulateGateScan');
    scanBtn.disabled = true;
    scanBtn.innerHTML = `<span>Scanning QR Token...</span>`;

    try {
      await fetch(`${API_BASE}/api/slots/checkin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reservationId: reservation.id })
      });
    } catch (err) {}

    reservation.status = 'occupied';
    scanBtn.disabled = false;
    scanBtn.innerHTML = `<span>Simulate Gate Entry QR Scan</span>`;
    showGateEntryAnimation(reservation);

    if (onStatusChangeCallback) {
      onStatusChangeCallback('occupied', reservation);
    }
  }

  function showGateEntryAnimation(reservation) {
    const alertEl = document.createElement('div');
    alertEl.className = 'gate-entry-banner-toast';
    alertEl.innerHTML = `
      <div class="toast-content">
        <div class="toast-icon">🟢</div>
        <div class="toast-text">
          <strong>GATE A BARRIER OPENED!</strong>
          <p>QR Token Verified. Welcome to ${reservation.hubName}! Proceed to Floor ${reservation.floorId}, Bay #${reservation.bayNumber}.</p>
        </div>
      </div>
    `;
    document.body.appendChild(alertEl);

    setTimeout(() => {
      alertEl.classList.add('fade-out');
      setTimeout(() => alertEl.remove(), 600);
    }, 4500);

    document.getElementById('digitalPassModal').classList.add('hidden');
    if (window.NavigationGuide) {
      window.NavigationGuide.showRoute(reservation.bayNumber, reservation.floorId, reservation.slotId);
    }
  }

  function downloadPassText(res) {
    const receiptText = `
===================================================
      SLOTSPOT HYDERABAD DIGITAL PARKING PASS
   Greater Hyderabad Municipal Smart Mobility
===================================================
Booking Token ID : ${res.id}
Facility         : ${res.hubName}
City / Region    : Hyderabad, Telangana
Address          : ${res.address}
Allocated Bay    : Bay #${res.bayNumber} (${res.slotType})
Floor Level      : ${res.floorName}
Vehicle Type     : ${res.vehicleType}
License Plate    : ${res.plateNumber}
Driver Name      : ${res.driverName}
Duration         : ${res.durationHours} Hours
Tariff Total     : ₹${res.totalFee}.00
QR Gate Payload  : SLOTSPOT:${res.id}:${res.slotId}
Entry Gate       : Gate A (North Barrier)
Status           : CONFIRMED & ACTIVE
===================================================
Present this token QR at the automated gate scanner.
SlotSpot Hyderabad Smart Parking Systems © 2026
===================================================
    `.trim();

    const blob = new Blob([receiptText], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `SlotSpot_Pass_${res.id}.txt`;
    a.click();
  }

  function setupGlobalHoldBanner() {
    const banner = document.getElementById('globalHoldBanner');
    if (!banner) return;

    document.getElementById('btnBannerViewHold').onclick = () => {
      if (activeReservation) {
        openHoldActiveModal(activeReservation);
      }
    };
  }

  function showHoldBanner(show) {
    const banner = document.getElementById('globalHoldBanner');
    if (banner) {
      if (show) banner.classList.remove('hidden');
      else banner.classList.add('hidden');
    }
  }

  return {
    init,
    openReservationModal,
    getActiveReservation: () => activeReservation,
    openDigitalPassModal
  };
})();
