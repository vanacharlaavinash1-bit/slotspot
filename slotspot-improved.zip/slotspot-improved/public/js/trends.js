// SlotSpot: Occupancy Trend Forecast Chart Component (Stretch Feature)

const OccupancyForecast = (function () {
  let canvasEl = null;
  let currentHubData = null;
  let currentMode = 'weekday'; // 'weekday' or 'weekend'

  function init(canvasId) {
    canvasEl = document.getElementById(canvasId);
    setupDayPicker();
  }

  function setupDayPicker() {
    const chips = document.querySelectorAll('.forecast-day-picker .chip');
    chips.forEach((chip, idx) => {
      chip.style.cursor = 'pointer';
      chip.addEventListener('click', () => {
        chips.forEach(c => c.classList.remove('chip-active'));
        chip.classList.add('chip-active');
        currentMode = idx === 0 ? 'weekday' : 'weekend';
        if (currentHubData) {
          render(currentHubData);
        }
      });
    });
  }

  function render(hub) {
    if (!hub) return;
    currentHubData = hub;
    if (!canvasEl) canvasEl = document.getElementById('forecastCanvas');
    if (!canvasEl) return;
    setupDayPicker();

    const ctx = canvasEl.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const rect = canvasEl.getBoundingClientRect();
    const width = rect.width || 600;
    const height = 240;

    canvasEl.width = width * dpr;
    canvasEl.height = height * dpr;
    ctx.scale(dpr, dpr);

    let rawHistory = hub.historicalOccupancy || [
      { hour: '06:00', occupancy: 15 },
      { hour: '08:00', occupancy: 65 },
      { hour: '10:00', occupancy: 92 },
      { hour: '12:00', occupancy: 75 },
      { hour: '14:00', occupancy: 60 },
      { hour: '16:00', occupancy: 72 },
      { hour: '18:00', occupancy: 95 },
      { hour: '20:00', occupancy: 65 },
      { hour: '22:00', occupancy: 30 }
    ];

    let history = rawHistory;
    if (currentMode === 'weekend') {
      // Weekend occupancy curve: low in early morning, peaks in afternoon/evening for shopping/dining
      history = rawHistory.map(item => {
        const hourNum = parseInt(item.hour.split(':')[0]);
        let occ = item.occupancy;
        if (hourNum < 11) occ = Math.round(occ * 0.45);
        else if (hourNum >= 13 && hourNum <= 21) occ = Math.min(98, Math.round(occ * 1.25) + 10);
        else occ = Math.round(occ * 0.8);
        return { hour: item.hour, occupancy: occ };
      });
    }

    const padLeft = 45;
    const padRight = 20;
    const padTop = 30;
    const padBottom = 40;
    const chartW = width - padLeft - padRight;
    const chartH = height - padTop - padBottom;

    ctx.clearRect(0, 0, width, height);

    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.fillStyle = '#64748b';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'right';

    [0, 25, 50, 75, 100].forEach(pct => {
      const y = padTop + chartH - (pct / 100) * chartH;
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(width - padRight, y);
      ctx.stroke();
      ctx.fillText(`${pct}%`, padLeft - 8, y + 3);
    });

    const surgeY = padTop + chartH - (85 / 100) * chartH;
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(padLeft, surgeY);
    ctx.lineTo(width - padRight, surgeY);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = '#ef4444';
    ctx.fillText('Peak (85%)', width - padRight, surgeY - 4);

    const stepX = chartW / (history.length - 1);
    const points = history.map((item, idx) => {
      const x = padLeft + idx * stepX;
      const y = padTop + chartH - (item.occupancy / 100) * chartH;
      return { x, y, hour: item.hour, val: item.occupancy };
    });

    const areaGrad = ctx.createLinearGradient(0, padTop, 0, padTop + chartH);
    areaGrad.addColorStop(0, 'rgba(56, 189, 248, 0.45)');
    areaGrad.addColorStop(0.7, 'rgba(14, 165, 233, 0.15)');
    areaGrad.addColorStop(1, 'rgba(14, 165, 233, 0.0)');

    ctx.fillStyle = areaGrad;
    ctx.beginPath();
    ctx.moveTo(points[0].x, padTop + chartH);
    points.forEach(pt => ctx.lineTo(pt.x, pt.y));
    ctx.lineTo(points[points.length - 1].x, padTop + chartH);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 3;
    ctx.beginPath();
    points.forEach((pt, idx) => {
      if (idx === 0) ctx.moveTo(pt.x, pt.y);
      else ctx.lineTo(pt.x, pt.y);
    });
    ctx.stroke();

    ctx.textAlign = 'center';
    points.forEach((pt, idx) => {
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = pt.val >= 85 ? '#ef4444' : (pt.val >= 60 ? '#f59e0b' : '#10b981');
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      if (idx % 2 === 0 || idx === points.length - 1) {
        ctx.fillStyle = '#94a3b8';
        ctx.font = '10px sans-serif';
        ctx.fillText(pt.hour, pt.x, height - 12);
      }
    });

    const currentHourIdx = 4;
    if (points[currentHourIdx]) {
      const curPt = points[currentHourIdx];
      ctx.strokeStyle = '#a855f7';
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(curPt.x, padTop);
      ctx.lineTo(curPt.x, padTop + chartH);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = '#c084fc';
      ctx.font = 'bold 9px sans-serif';
      ctx.fillText('NOW', curPt.x, padTop - 8);
    }
  }

  return {
    init,
    render
  };
})();

window.OccupancyForecast = OccupancyForecast;
