// SlotSpot: Dynamic Tariff & Fee Calculator Engine

const TariffCalculator = (function () {

  function calculate(params) {
    const {
      baseTariffPerHour = 30,
      occupancyRate = 50,
      vehicleType = 'Sedan',
      durationHours = 2,
      isEVBay = false,
      chargerType = null
    } = params;

    let surgeMultiplier = 1.0;
    let surgeBadge = 'Normal (1.0x)';
    let surgeColor = 'green';

    if (occupancyRate > 85) {
      surgeMultiplier = 1.30;
      surgeBadge = 'Peak Surge (+30%)';
      surgeColor = 'red';
    } else if (occupancyRate >= 60) {
      surgeMultiplier = 1.15;
      surgeBadge = 'High Demand (+15%)';
      surgeColor = 'amber';
    }

    let vehicleMultiplier = 1.0;
    let vehicleLabel = 'Standard 4-Wheeler';
    if (vehicleType === '2-Wheeler') {
      vehicleMultiplier = 0.5;
      vehicleLabel = 'Two-Wheeler (0.5x)';
    } else if (vehicleType === 'SUV') {
      vehicleMultiplier = 1.3;
      vehicleLabel = 'SUV / Large Vehicle (1.3x)';
    } else if (vehicleType === 'EV') {
      vehicleMultiplier = 1.0;
      vehicleLabel = 'Electric Vehicle';
    }

    const baseRate = Math.round(baseTariffPerHour * vehicleMultiplier * surgeMultiplier);
    const baseSubtotal = baseRate * durationHours;

    let chargerRatePerHour = 0;
    let chargerName = 'None';
    if (isEVBay && chargerType) {
      if (chargerType.includes('DC Fast')) {
        chargerRatePerHour = 25;
        chargerName = 'DC Fast (60 kW)';
      } else {
        chargerRatePerHour = 10;
        chargerName = 'Level-2 AC (22 kW)';
      }
    }
    const chargerSubtotal = chargerRatePerHour * durationHours;
    const totalTariff = baseSubtotal + chargerSubtotal;

    return {
      baseTariffPerHour,
      occupancyRate,
      surgeMultiplier,
      surgeBadge,
      surgeColor,
      vehicleType,
      vehicleMultiplier,
      vehicleLabel,
      effectiveHourlyRate: baseRate,
      durationHours,
      baseSubtotal,
      chargerName,
      chargerRatePerHour,
      chargerSubtotal,
      totalTariff
    };
  }

  function renderBreakdownHTML(calc) {
    return `
      <div class="tariff-breakdown-card">
        <div class="breakdown-header">
          <span class="breakdown-title">Dynamic Tariff Estimation</span>
          <span class="surge-pill surge-${calc.surgeColor}">${calc.surgeBadge}</span>
        </div>

        <div class="breakdown-rows">
          <div class="breakdown-row">
            <span>Base Facility Rate</span>
            <span>₹${calc.baseTariffPerHour}/hr</span>
          </div>
          
          <div class="breakdown-row">
            <span>Vehicle Factor (${calc.vehicleType})</span>
            <span>${calc.vehicleMultiplier}x</span>
          </div>

          <div class="breakdown-row">
            <span>Duration</span>
            <span>${calc.durationHours} hr${calc.durationHours > 1 ? 's' : ''}</span>
          </div>

          <div class="breakdown-row">
            <span>Parking Space Subtotal</span>
            <span>₹${calc.baseSubtotal}</span>
          </div>

          ${calc.chargerRatePerHour > 0 ? `
            <div class="breakdown-row ev-row">
              <span>⚡ EV Charging Plug (${calc.chargerName})</span>
              <span>₹${calc.chargerRatePerHour}/hr × ${calc.durationHours}h = ₹${calc.chargerSubtotal}</span>
            </div>
          ` : ''}

          <div class="breakdown-divider"></div>

          <div class="breakdown-row total-row">
            <strong>Estimated Total Fee</strong>
            <strong class="total-amount">₹${calc.totalTariff}</strong>
          </div>
        </div>
      </div>
    `;
  }

  return {
    calculate,
    renderBreakdownHTML
  };
})();
