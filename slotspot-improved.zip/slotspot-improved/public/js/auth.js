// SlotSpot: Client-Side Authentication & Session Manager
// Handles User Sign In, Registration, Demo Profiles & Bearer Token Management

const AuthManager = (function () {
  const isDirectNode = window.location.port === '3000';
  const API_BASE = isDirectNode ? '' : (window.location.protocol.startsWith('http') ? 'http://127.0.0.1:3000' : '');

  const TOKEN_KEY = 'slotspot_auth_token';
  const USER_KEY = 'slotspot_auth_user';

  let currentUser = null;
  let authToken = null;

  function init() {
    loadSavedSession();
    renderAuthNavbar();
    setupAuthModalListeners();
    verifyActiveSession();
  }

  function loadSavedSession() {
    try {
      authToken = localStorage.getItem(TOKEN_KEY);
      const userRaw = localStorage.getItem(USER_KEY);
      currentUser = userRaw ? JSON.parse(userRaw) : null;
    } catch (e) {
      authToken = null;
      currentUser = null;
    }
  }

  async function verifyActiveSession() {
    if (!authToken) return;
    try {
      const res = await fetch(`${API_BASE}/api/auth/me`, {
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.user) {
          currentUser = data.user;
          localStorage.setItem(USER_KEY, JSON.stringify(currentUser));
          renderAuthNavbar();
          prefillReservationForm();
        }
      } else {
        // Token invalid or expired
        logout(false);
      }
    } catch (e) {
      // Offline or network error - keep cached user for offline demo
    }
  }

  function renderAuthNavbar() {
    const btn = document.getElementById('btnAuthOpen');
    const textEl = document.getElementById('authBtnText');
    if (!btn || !textEl) return;

    if (currentUser) {
      textEl.innerHTML = `<strong>${currentUser.name}</strong> <span class="nav-user-plate">${currentUser.vehiclePlate || 'TS 09 AB 7720'}</span>`;
      btn.title = `Signed in as ${currentUser.email} (${currentUser.role}). Click to view profile / sign out.`;
      btn.classList.add('btn-authenticated');
    } else {
      textEl.textContent = 'Sign In / Register';
      btn.title = 'Sign in or register to secure your reservations';
      btn.classList.remove('btn-authenticated');
    }
  }

  function prefillReservationForm() {
    if (!currentUser) return;
    const nameInput = document.getElementById('resDriverName');
    const plateInput = document.getElementById('resPlateNumber');
    if (nameInput) nameInput.value = currentUser.name;
    if (plateInput && currentUser.vehiclePlate) plateInput.value = currentUser.vehiclePlate;
  }

  function setupAuthModalListeners() {
    const authBtn = document.getElementById('btnAuthOpen');
    const modal = document.getElementById('authModal');
    if (!authBtn || !modal) return;

    authBtn.onclick = () => {
      if (currentUser) {
        openProfileView();
      } else {
        openAuthModal('login');
      }
    };

    // Tab buttons
    const tabLogin = document.getElementById('tabAuthLogin');
    const tabRegister = document.getElementById('tabAuthRegister');
    if (tabLogin && tabRegister) {
      tabLogin.onclick = () => switchAuthTab('login');
      tabRegister.onclick = () => switchAuthTab('register');
    }

    // Forms
    const loginForm = document.getElementById('formAuthLogin');
    const registerForm = document.getElementById('formAuthRegister');

    if (loginForm) {
      loginForm.onsubmit = async (e) => {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value.trim();
        const password = document.getElementById('loginPassword').value;
        await handleLogin(email, password);
      };
    }

    if (registerForm) {
      registerForm.onsubmit = async (e) => {
        e.preventDefault();
        const name = document.getElementById('regName').value.trim();
        const email = document.getElementById('regEmail').value.trim();
        const password = document.getElementById('regPassword').value;
        const vehiclePlate = document.getElementById('regPlate').value.trim();
        const phone = document.getElementById('regPhone').value.trim();
        await handleRegister({ name, email, password, vehiclePlate, phone });
      };
    }

    // Quick Login Demo Buttons
    const btnQuickMotorist = document.getElementById('btnQuickMotoristLogin');
    if (btnQuickMotorist) {
      btnQuickMotorist.onclick = async () => {
        document.getElementById('loginEmail').value = 'motorist@slotspot.in';
        document.getElementById('loginPassword').value = 'Motorist@123';
        await handleLogin('motorist@slotspot.in', 'Motorist@123');
      };
    }

    const btnQuickAdmin = document.getElementById('btnQuickAdminLogin');
    if (btnQuickAdmin) {
      btnQuickAdmin.onclick = async () => {
        document.getElementById('loginEmail').value = 'admin@slotspot.in';
        document.getElementById('loginPassword').value = 'Admin@123';
        await handleLogin('admin@slotspot.in', 'Admin@123');
      };
    }

    const btnLogout = document.getElementById('btnLogout');
    if (btnLogout) {
      btnLogout.onclick = () => logout(true);
    }
  }

  function openAuthModal(defaultTab = 'login') {
    const modal = document.getElementById('authModal');
    if (!modal) return;
    document.getElementById('authProfileView').classList.add('hidden');
    document.getElementById('authFormView').classList.remove('hidden');
    switchAuthTab(defaultTab);
    clearAuthErrors();
    modal.classList.remove('hidden');
  }

  function openProfileView() {
    const modal = document.getElementById('authModal');
    if (!modal || !currentUser) return;

    document.getElementById('authFormView').classList.add('hidden');
    document.getElementById('authProfileView').classList.remove('hidden');

    document.getElementById('profName').textContent = currentUser.name;
    document.getElementById('profEmail').textContent = currentUser.email;
    document.getElementById('profRole').textContent = currentUser.role.toUpperCase();
    document.getElementById('profPlate').textContent = currentUser.vehiclePlate || 'Not Registered';
    document.getElementById('profPhone').textContent = currentUser.phone || 'Not Specified';

    modal.classList.remove('hidden');
    loadUserBookingsList();
  }

  async function loadUserBookingsList() {
    const container = document.getElementById('userBookingsContainer');
    if (!container || !authToken) return;

    container.innerHTML = '<p class="text-muted">Loading your reservations from persistent database...</p>';

    try {
      const res = await fetch(`${API_BASE}/api/auth/reservations`, {
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.reservations && data.reservations.length > 0) {
          container.innerHTML = data.reservations.map(r => `
            <div class="user-booking-card">
              <div class="booking-card-header">
                <span class="booking-badge status-${r.status}">${r.status.toUpperCase()}</span>
                <span class="booking-id">#${r.id}</span>
              </div>
              <div class="booking-card-body">
                <strong>${r.hubName}</strong> • Bay #${r.bayNumber} (${r.floorName})<br>
                <small>${r.vehicleType} • ${r.plateNumber} • ₹${r.totalFee}</small>
              </div>
            </div>
          `).join('');
        } else {
          container.innerHTML = '<p class="text-muted">No reservations saved under this account yet. Reserve any stall to see it here!</p>';
        }
      }
    } catch (e) {
      container.innerHTML = '<p class="text-muted">Could not retrieve bookings list.</p>';
    }
  }

  function switchAuthTab(tab) {
    clearAuthErrors();
    const loginTab = document.getElementById('tabAuthLogin');
    const registerTab = document.getElementById('tabAuthRegister');
    const loginSection = document.getElementById('sectionLogin');
    const registerSection = document.getElementById('sectionRegister');

    if (tab === 'login') {
      loginTab.classList.add('active');
      registerTab.classList.remove('active');
      loginSection.classList.remove('hidden');
      registerSection.classList.add('hidden');
    } else {
      registerTab.classList.add('active');
      loginTab.classList.remove('active');
      registerSection.classList.remove('hidden');
      loginSection.classList.add('hidden');
    }
  }

  function showAuthError(msg) {
    const errorEl = document.getElementById('authErrorMessage');
    if (errorEl) {
      errorEl.textContent = msg;
      errorEl.classList.remove('hidden');
    }
  }

  function clearAuthErrors() {
    const errorEl = document.getElementById('authErrorMessage');
    if (errorEl) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
    }
  }

  async function handleLogin(email, password) {
    clearAuthErrors();
    const submitBtn = document.getElementById('btnSubmitLogin');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Authenticating...';
    }

    try {
      const res = await fetch(`${API_BASE}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        authToken = data.token;
        currentUser = data.user;
        localStorage.setItem(TOKEN_KEY, authToken);
        localStorage.setItem(USER_KEY, JSON.stringify(currentUser));
        renderAuthNavbar();
        prefillReservationForm();
        document.getElementById('authModal').classList.add('hidden');
      } else {
        showAuthError(data.error || 'Failed to authenticate.');
      }
    } catch (err) {
      // Local fallback for static server demo
      currentUser = {
        id: 'USR-MOTO-01',
        name: 'Harry (Motorist)',
        email: email || 'motorist@slotspot.in',
        vehiclePlate: 'TS 09 AB 7720',
        role: 'motorist'
      };
      authToken = 'SST-DEMO-LOCAL-SESSION-TOKEN';
      localStorage.setItem(TOKEN_KEY, authToken);
      localStorage.setItem(USER_KEY, JSON.stringify(currentUser));
      renderAuthNavbar();
      prefillReservationForm();
      document.getElementById('authModal').classList.add('hidden');
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Sign In to Account';
      }
    }
  }

  async function handleRegister({ name, email, password, vehiclePlate, phone }) {
    clearAuthErrors();
    const submitBtn = document.getElementById('btnSubmitRegister');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Creating Account...';
    }

    try {
      const res = await fetch(`${API_BASE}/api/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, vehiclePlate, phone })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        authToken = data.token;
        currentUser = data.user;
        localStorage.setItem(TOKEN_KEY, authToken);
        localStorage.setItem(USER_KEY, JSON.stringify(currentUser));
        renderAuthNavbar();
        prefillReservationForm();
        document.getElementById('authModal').classList.add('hidden');
      } else {
        showAuthError(data.error || 'Registration failed.');
      }
    } catch (err) {
      showAuthError('Connection error. Could not register account.');
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Register Motorist Account';
      }
    }
  }

  async function logout(callApi = true) {
    if (callApi && authToken) {
      try {
        await fetch(`${API_BASE}/api/auth/logout`, {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${authToken}` }
        });
      } catch (e) {}
    }

    authToken = null;
    currentUser = null;
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    renderAuthNavbar();

    const modal = document.getElementById('authModal');
    if (modal) modal.classList.add('hidden');
  }

  return {
    init,
    getToken: () => authToken,
    getUser: () => currentUser,
    isAuthenticated: () => Boolean(currentUser && authToken),
    prefillReservationForm,
    logout
  };
})();

document.addEventListener('DOMContentLoaded', () => {
  AuthManager.init();
});
