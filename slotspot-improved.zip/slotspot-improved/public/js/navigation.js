// SlotSpot: In-Lot Step-by-Step Navigation Guide (Hyderabad Facilities)

const NavigationGuide = (function () {
  let overlayEl = null;

  function init(overlayId) {
    overlayEl = document.getElementById(overlayId);
  }

  function showRoute(bayNumber, floorId, slotId) {
    if (window.switchView) {
      window.switchView('floorplan');
    }

    if (floorId && window.ParkingGrid) {
      const currentF = window.ParkingGrid.getCurrentFloorId();
      if (currentF !== String(floorId)) {
        const floorBtn = document.querySelector(`[data-floor-id="${floorId}"]`);
        if (floorBtn) floorBtn.click();
      }
    }

    if (!overlayEl) overlayEl = document.getElementById('navGuideOverlay');
    if (!overlayEl) return;

    let floorName = `Floor ${floorId}`;
    let aisleTurnText = 'Turn into Central Bay Wing';
    if (floorId === 'G') {
      floorName = 'Ground Level (Level G)';
      aisleTurnText = 'Proceed straight along Ground Level Ingress Lane';
    } else if (floorId === '1') {
      floorName = 'Floor 1 (Mezzanine Level)';
      aisleTurnText = 'Take Ramp up to Mezzanine Bay Wing B';
    } else if (floorId === '2') {
      floorName = 'Floor 2 (Rooftop Deck)';
      aisleTurnText = 'Take Express Ramp up to Rooftop Deck Wing C';
    }

    overlayEl.innerHTML = `
      <div class="nav-drawer-card">
        <div class="nav-drawer-header">
          <div class="nav-title-group">
            <span class="nav-badge">IN-LOT NAVIGATION</span>
            <h3>Routing to Reserved Bay #${bayNumber} (${floorName})</h3>
          </div>
          <button class="btn btn-sm btn-ghost" id="btnCloseNavGuide">✕ Close Guide</button>
        </div>

        <div class="nav-steps-timeline">
          <div class="nav-step-item done">
            <div class="step-marker">✓</div>
            <div class="step-info">
              <strong>Entry Gate A (Barrier Gate)</strong>
              <p>QR pass verified &amp; gate opened • Speed limit 10 km/h</p>
            </div>
          </div>

          <div class="nav-step-item active">
            <div class="step-marker">➔</div>
            <div class="step-info">
              <strong>Main Circulation Aisle</strong>
              <p>Proceed 15 meters along the green lane indicator</p>
            </div>
          </div>

          <div class="nav-step-item">
            <div class="step-marker">↱</div>
            <div class="step-info">
              <strong>${aisleTurnText}</strong>
              <p>${floorName} • Follow overhead LED signs for Bay #${bayNumber}</p>
            </div>
          </div>

          <div class="nav-step-item destination">
            <div class="step-marker">🅿️</div>
            <div class="step-info">
              <strong>Arrive at Bay #${bayNumber}</strong>
              <p>Look for illuminated bay sensor light • Pull into parking stall</p>
            </div>
          </div>
        </div>

        <div class="nav-path-animation-box">
          <div class="anim-car-track">
            <div class="track-gate">GATE A</div>
            <div class="track-lane">
              <span class="moving-car-icon">🚗💨</span>
            </div>
            <div class="track-destination">BAY #${bayNumber}</div>
          </div>
        </div>
      </div>
    `;

    overlayEl.classList.remove('hidden');

    const closeBtn = document.getElementById('btnCloseNavGuide');
    if (closeBtn) {
      closeBtn.onclick = () => {
        overlayEl.classList.add('hidden');
        document.querySelectorAll('.highlight-guided-bay').forEach(el => el.classList.remove('highlight-guided-bay'));
      };
    }

    setTimeout(() => {
      let bayCard = null;
      if (slotId) {
        bayCard = document.getElementById(`slot-card-${slotId}`);
      }
      if (!bayCard) {
        bayCard = document.querySelector(`[data-bay-number="${bayNumber}"]`);
      }
      if (bayCard) {
        bayCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        bayCard.classList.add('highlight-guided-bay');
      }
    }, 150);
  }

  return {
    init,
    showRoute
  };
})();

window.NavigationGuide = NavigationGuide;
