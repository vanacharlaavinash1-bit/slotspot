// SlotSpot: Main Application Controller & Dual-Mode State Manager (Node Server + Live Server Fallback)

(function () {
  let allHubs = [];
  let currentHubId = 'metro-plaza';
  let currentHubFull = null;
  let activeSearchTerm = '';
  let filterEVOnly = false;
  let featuredHubs = [];      // the 4 SlotSpot partner hubs (live sensors)
  let lotHubs = [];           // every other parking lot in Hyderabad
  let lotsStatus = '';
  let pendingOrigin = null;
  const PAGE = 40;
  let visibleCount = PAGE;

  // Determine API endpoint base
  const isDirectNode = window.location.port === '3000';
  const API_BASE = isDirectNode ? '' : (window.location.protocol.startsWith('http') ? 'http://127.0.0.1:3000' : '');

  document.addEventListener('DOMContentLoaded', initApp);

  async function initApp() {
    setupEventListeners();
    await loadHubs();
    await selectHub(currentHubId);
    window.addEventListener('slotspot:location', (e) => {
      if (lotHubs.length) { CityParking.setOrigin(e.detail.lat, e.detail.lng, 'you'); sortAll(); renderHubCards(); }
      else pendingOrigin = e.detail;
    });
    loadCityLots();

    TelemetryManager.init(handleTelemetryEvent);
    ReservationManager.init(handleReservationStatusChange);
  }

  function setupEventListeners() {
    const searchInput = document.getElementById('hubSearchInput');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        activeSearchTerm = e.target.value.trim().toLowerCase();
        visibleCount = PAGE;
        renderHubCards();
      });
    }

    const evFilterToggle = document.getElementById('filterEVToggle');
    if (evFilterToggle) {
      evFilterToggle.addEventListener('change', (e) => {
        filterEVOnly = e.target.checked;
        visibleCount = PAGE;
        renderHubCards();
      });
    }

    const zonePicker = document.getElementById('cityZoneSelect');
    if (zonePicker) {
      zonePicker.addEventListener('change', (e) => {
        const val = e.target.value;
        if (val === 'all') {
          activeSearchTerm = '';
          const searchInput = document.getElementById('hubSearchInput');
          if (searchInput) searchInput.value = '';
          renderHubCards();
          CityMap.setActiveHub('metro-plaza');
        } else {
          selectHub(val);
        }
      });
    }

    const btnTabExplorer = document.getElementById('tabBtnExplorer');
    const btnTabFloorplan = document.getElementById('tabBtnFloorplan');
    const btnTabForecast = document.getElementById('tabBtnForecast');

    if (btnTabExplorer && btnTabFloorplan) {
      btnTabExplorer.addEventListener('click', () => switchView('explorer'));
      btnTabFloorplan.addEventListener('click', () => switchView('floorplan'));
      if (btnTabForecast) {
        btnTabForecast.addEventListener('click', () => switchView('forecast'));
      }
    }

    document.querySelectorAll('.modal-close-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const modal = btn.closest('.modal-backdrop');
        if (modal) modal.classList.add('hidden');
      });
    });

    document.querySelectorAll('.modal-backdrop').forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.add('hidden');
      });
    });

    const demoBtn = document.getElementById('btnRunDemoScenario');
    if (demoBtn) {
      demoBtn.addEventListener('click', runDemoScenario);
    }
  }

  function switchView(viewName) {
    document.querySelectorAll('.nav-tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.main-view-panel').forEach(p => p.classList.add('hidden'));

    if (viewName === 'explorer') {
      document.getElementById('tabBtnExplorer').classList.add('active');
      document.getElementById('viewExplorer').classList.remove('hidden');
    } else if (viewName === 'floorplan') {
      document.getElementById('tabBtnFloorplan').classList.add('active');
      document.getElementById('viewFloorplan').classList.remove('hidden');
    } else if (viewName === 'forecast') {
      document.getElementById('tabBtnForecast').classList.add('active');
      document.getElementById('viewForecast').classList.remove('hidden');
      if (currentHubFull && window.OccupancyForecast) {
        window.OccupancyForecast.render(currentHubFull);
      }
    }
  }

  // Calculate stats on client side if offline
  function computeHubSummary(hub) {
    let total = 0, vacant = 0, occupied = 0, locked = 0;
    hub.floors.forEach(fl => {
      fl.slots.forEach(s => {
        total++;
        if (s.status === 'vacant') vacant++;
        else if (s.status === 'occupied') occupied++;
        else if (s.status === 'locked' || s.status === 'reserved') locked++;
      });
    });
    const occupancyRate = total > 0 ? Math.round(((total - vacant) / total) * 100) : 0;
    let surgeMultiplier = 1.0;
    let surgeLabel = 'Normal Tariff';
    if (occupancyRate > 85) {
      surgeMultiplier = 1.30;
      surgeLabel = 'Peak Surge (+30%)';
    } else if (occupancyRate >= 60) {
      surgeMultiplier = 1.15;
      surgeLabel = 'High Demand Surge (+15%)';
    }
    return {
      ...hub,
      totalSpots: total,
      vacantSpots: vacant,
      occupiedSpots: occupied,
      lockedSpots: locked,
      occupancyRate,
      surgeMultiplier,
      surgeLabel,
      effectiveBaseTariff: Math.round(hub.baseTariffPerHour * surgeMultiplier)
    };
  }

  async function loadHubs() {
    let loaded = false;
    // 1. Try server fetch
    try {
      const res = await fetch(API_BASE + '/api/hubs');
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.hubs && data.hubs.length > 0) {
          allHubs = data.hubs;
          loaded = true;
        }
      }
    } catch (e) {
      // Server unreachable, use fallback
    }

    // 2. Fallback to embedded dataset (ensures Live Server 5500 works out of the box!)
    if (!loaded) {
      const raw = window.INITIAL_PARKING_HUBS || [];
      allHubs = raw.map(computeHubSummary);
    }

    featuredHubs = allHubs.slice();
    CityMap.init('cityMapContainer', allHubs, (hubId) => {
      selectHub(hubId);
    });
    renderHubCards();
  }

  function sortAll() { allHubs = featuredHubs.concat(CityParking.sorted()); }

  async function loadCityLots() {
    if (!window.CityParking) return;
    lotsStatus = 'Loading Hyderabad parking lots…';
    renderHubCards();
    const onUpdate = (hubs) => {
      lotHubs = hubs;
      if (pendingOrigin) CityParking.setOrigin(pendingOrigin.lat, pendingOrigin.lng, 'you');
      sortAll();
      lotsStatus = `Loading Hyderabad parking lots… ${hubs.length.toLocaleString()} found so far`;
      CityMap.updateHubs(allHubs);
      renderHubCards();
    };
    try {
      const result = await CityParking.load(onUpdate);
      lotsStatus = result.failed
        ? `Some areas could not be loaded (${result.failed} of 9). <button id="btnRetryLots" class="btn btn-sm btn-outline">Retry</button>`
        : '';
    } catch (e) {
      lotsStatus = 'Could not load parking lots. <button id="btnRetryLots" class="btn btn-sm btn-outline">Retry</button>';
    }
    renderHubCards();
  }

  function renderHubCards() {
    const listEl = document.getElementById('hubCardsList');
    if (!listEl) return;

    let filtered = allHubs.filter(hub => {
      const matchesSearch = !activeSearchTerm ||
        hub.name.toLowerCase().includes(activeSearchTerm) ||
        hub.landmark.toLowerCase().includes(activeSearchTerm) ||
        hub.address.toLowerCase().includes(activeSearchTerm);

      const matchesEV = !filterEVOnly || (hub.evCharging && hub.evCharging.available);

      return matchesSearch && matchesEV;
    });

    if (filtered.length === 0) {
      listEl.innerHTML = `
        <div class="empty-search-state">
          <p>No parking facilities match "<strong>${activeSearchTerm}</strong>"</p>
          <button class="btn btn-sm btn-outline" onclick="document.getElementById('hubSearchInput').value=''; document.getElementById('hubSearchInput').dispatchEvent(new Event('input'))">Clear Search</button>
        </div>
      `;
      return;
    }

    let cardsHTML = '';
    if (lotsStatus) cardsHTML += `<div class="empty-search-state"><p>${lotsStatus}</p></div>`;
    else if (lotHubs.length) cardsHTML += `<div class="empty-search-state" style="padding:8px 4px"><p>${filtered.length.toLocaleString()} parking lots · nearest first. Bay availability for lots outside the 4 partner hubs is simulated.</p></div>`;
    filtered.slice(0, visibleCount).forEach(hub => {
      const isSelected = hub.id === currentHubId;
      const vacant = hub.vacantSpots ?? 0;
      const total = hub.totalSpots ?? 30;
      const pct = hub.occupancyRate ?? 50;
      const hasEV = hub.evCharging && hub.evCharging.available;

      let badgeClass = 'badge-green';
      if (vacant <= 5) badgeClass = 'badge-red';
      else if (vacant <= 10) badgeClass = 'badge-amber';

      cardsHTML += `
        <div class="hub-summary-card ${isSelected ? 'is-selected' : ''}" data-hub-id="${hub.id}">
          <div class="hub-card-header">
            <div>
              <h3 class="hub-card-title">${hub.name}</h3>
              <span class="hub-card-landmark">📍 ${hub.landmark}</span>
            </div>
            <span class="hub-vacant-badge ${badgeClass}">
              ${vacant} Spots Free
            </span>
          </div>

          <div class="hub-card-occupancy">
            <div class="occupancy-progress-bar">
              <div class="occupancy-fill" style="width: ${pct}%"></div>
            </div>
            <div class="occupancy-meta">
              <span>${pct}% Occupied (${total - vacant}/${total} bays)</span>
              <span class="surge-tag ${hub.surgeMultiplier > 1 ? 'surge-active' : ''}">${hub.surgeLabel}</span>
            </div>
          </div>

          <div class="hub-card-features">
            <span class="feature-chip">💰 ₹${hub.effectiveBaseTariff}/hr base</span>
            ${hasEV ? `<span class="feature-chip chip-ev">⚡ ${hub.evCharging.types.join(', ')}</span>` : ''}
            <span class="feature-chip">🚶 ${hub.distance}</span>
          </div>

          <div class="hub-card-actions">
            <button class="btn btn-sm btn-primary btn-explore-grid" data-hub-id="${hub.id}">
              View Floorplan &amp; Book
            </button>
          </div>
        </div>
      `;
    });

    if (filtered.length > visibleCount) {
      cardsHTML += `<button class="btn btn-sm btn-outline" id="btnMoreHubs" style="width:100%;margin:8px 0">Show more (${(filtered.length - visibleCount).toLocaleString()} left)</button>`;
    }
    listEl.innerHTML = cardsHTML;
    const moreBtn = document.getElementById('btnMoreHubs');
    if (moreBtn) moreBtn.addEventListener('click', () => { visibleCount += PAGE; renderHubCards(); });
    const retryBtn = document.getElementById('btnRetryLots');
    if (retryBtn) retryBtn.addEventListener('click', loadCityLots);

    listEl.querySelectorAll('.hub-summary-card').forEach(card => {
      card.addEventListener('click', (e) => {
        if (!e.target.classList.contains('btn-explore-grid')) {
          const hubId = card.getAttribute('data-hub-id');
          selectHub(hubId);
        }
      });
    });

    listEl.querySelectorAll('.btn-explore-grid').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const hubId = btn.getAttribute('data-hub-id');
        selectHub(hubId, true);
      });
    });
  }

  async function selectHub(hubId, switchTab = false) {
    currentHubId = hubId;
    CityMap.setActiveHub(hubId);

    const zonePicker = document.getElementById('cityZoneSelect');
    if (zonePicker && zonePicker.querySelector(`option[value="${hubId}"]`)) {
      zonePicker.value = hubId;
    }

    document.querySelectorAll('.hub-summary-card').forEach(c => {
      if (c.getAttribute('data-hub-id') === hubId) c.classList.add('is-selected');
      else c.classList.remove('is-selected');
    });

    let hubFound = (window.CityParking && CityParking.get(hubId)) || null;
    // 1. Try server fetch (partner hubs only)
    if (!hubFound) try {
      const res = await fetch(`${API_BASE}/api/hubs/${hubId}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.hub) {
          hubFound = data.hub;
        }
      }
    } catch (e) {
      // fallback
    }

    // 2. Fallback to client-side data
    if (!hubFound) {
      const raw = (window.INITIAL_PARKING_HUBS || []).find(h => h.id === hubId);
      if (raw) hubFound = computeHubSummary(raw);
    }

    if (hubFound) {
      currentHubFull = hubFound;
      updateFloorplanHeader(currentHubFull);

      ParkingGrid.init('parkingGridContainer', (slot, hub, floor) => {
        ReservationManager.openReservationModal(slot, hub, floor);
      });
      ParkingGrid.setHub(currentHubFull);

      if (window.OccupancyForecast) {
        window.OccupancyForecast.render(currentHubFull);
      }

      if (switchTab) {
        switchView('floorplan');
      }
    }
  }

  function updateFloorplanHeader(hub) {
    const titleEl = document.getElementById('gridHubName');
    const subtitleEl = document.getElementById('gridHubSubtitle');
    const badgeEl = document.getElementById('gridHubSurgeBadge');
    const spotsCountEl = document.getElementById('gridHubVacantCount');

    if (titleEl) titleEl.textContent = hub.name;
    if (subtitleEl) subtitleEl.textContent = `📍 ${hub.address} • Base: ₹${hub.baseTariffPerHour}/hr`;
    if (badgeEl) {
      badgeEl.textContent = hub.surgeLabel;
      badgeEl.className = `surge-badge ${hub.surgeMultiplier > 1 ? 'surge-warn' : 'surge-normal'}`;
    }
    if (spotsCountEl) {
      spotsCountEl.textContent = `${hub.vacantSpots} Spots Remaining`;
    }
  }

  function handleTelemetryEvent(type, data) {
    if (type === 'pulse' || type === 'slot_updated') {
      if (currentHubFull && currentHubFull.id === data.hubId) {
        ParkingGrid.updateSlotStatus(data.slotId, data.status || data.newStatus);
      }
    } else if (type === 'stats_updated') {
      featuredHubs = data;
      allHubs = lotHubs.length ? featuredHubs.concat(CityParking.sorted()) : data;
      CityMap.updateHubs(allHubs);
      renderHubCards();
      const current = allHubs.find(h => h.id === currentHubId);
      if (current) {
        updateFloorplanHeader(current);
      }
    }
  }

  function handleReservationStatusChange(status, reservation) {
    if (status === 'locked' || status === 'reserved' || status === 'occupied') {
      if (reservation) {
        ParkingGrid.updateSlotStatus(reservation.slotId, status, reservation.vehicleType);
      }
    } else if (status === 'vacant') {
      selectHub(currentHubId);
    }
  }

  async function runDemoScenario() {
    const searchInput = document.getElementById('hubSearchInput');
    if (searchInput) {
      searchInput.value = 'Central Metro';
      searchInput.dispatchEvent(new Event('input'));
    }

    await selectHub('metro-plaza', true);

    const floor1Btn = document.querySelector('[data-floor-id="1"]');
    if (floor1Btn) floor1Btn.click();

    setTimeout(() => {
      const bay12 = document.getElementById('slot-card-MP-1-12');
      if (bay12) {
        bay12.scrollIntoView({ behavior: 'smooth', block: 'center' });
        bay12.classList.add('pulse-radar');
        setTimeout(() => {
          bay12.classList.remove('pulse-radar');
          bay12.click();
        }, 800);
      }
    }, 500);
  }

  window.switchView = switchView;
  window.SlotSpotApp = {
    selectHub,
    switchView,
    runDemoScenario,
    getHubs: () => featuredHubs
  };
})();
