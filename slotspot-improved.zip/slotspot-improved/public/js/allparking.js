// SlotSpot: every parking lot in Hyderabad (OpenStreetMap locations) as selectable hubs.
// Locations are real. Bay counts and free/occupied status are SIMULATED until sensors are connected.

const CityParking = (function () {
  const BBOX = '17.20,78.20,17.65,78.70';
  const CACHE_KEY = 'slotspot_osm_lots_v2';
  const TTL = 24 * 3600 * 1000;
  const AREAS = [
    ['Ameerpet', 17.4375, 78.4482], ['Begumpet', 17.4440, 78.4676], ['Secunderabad', 17.4399, 78.4983],
    ['Banjara Hills', 17.4126, 78.4482], ['Jubilee Hills', 17.4326, 78.4071], ['HITEC City', 17.4504, 78.3808],
    ['Madhapur', 17.4486, 78.3908], ['Gachibowli', 17.4401, 78.3489], ['Kondapur', 17.4600, 78.3664],
    ['Kukatpally', 17.4948, 78.3996], ['Miyapur', 17.4968, 78.3614], ['Mehdipatnam', 17.3957, 78.4399],
    ['Charminar', 17.3616, 78.4747], ['Abids', 17.3920, 78.4740], ['Dilsukhnagar', 17.3688, 78.5247],
    ['LB Nagar', 17.3457, 78.5522], ['Uppal', 17.4058, 78.5591], ['Tarnaka', 17.4278, 78.5300],
    ['Shamshabad', 17.2543, 78.3880], ['Attapur', 17.3680, 78.4280], ['Manikonda', 17.4040, 78.3860],
    ['Kompally', 17.5400, 78.4860], ['Bowenpally', 17.4700, 78.4700], ['Malkajgiri', 17.4500, 78.5260]
  ];
  let hubs = [], byId = new Map();
  let origin = { lat: 17.4375, lng: 78.4482, label: 'Ameerpet city centre' };

  function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) { let a = seed; return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function km(a, b, c, d) {
    const r = Math.PI / 180, dl = (c - a) * r, dg = (d - b) * r;
    const x = Math.sin(dl / 2) ** 2 + Math.cos(a * r) * Math.cos(c * r) * Math.sin(dg / 2) ** 2;
    return 12742 * Math.asin(Math.sqrt(x));
  }
  function areaFor(lat, lng) {
    let best = null;
    AREAS.forEach(a => { const d = km(lat, lng, a[1], a[2]); if (!best || d < best.d) best = { name: a[0], d }; });
    return best;
  }

  const SERVERS = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter', 'https://overpass.private.coffee/api/interpreter'];

  function tiles() {
    const out = [], lat0 = 17.20, lng0 = 78.20, dLat = 0.45 / 3, dLng = 0.50 / 3;
    for (let a = 0; a < 3; a++) for (let b = 0; b < 3; b++) {
      const s0 = lat0 + a * dLat, w0 = lng0 + b * dLng;
      out.push(`${s0.toFixed(4)},${w0.toFixed(4)},${(s0 + dLat).toFixed(4)},${(w0 + dLng).toFixed(4)}`);
    }
    return out;
  }

  async function fetchTile(bbox, k) {
    const q = `[out:json][timeout:60];nwr["amenity"="parking"](${bbox});out center tags;`;
    for (let n = 0; n < SERVERS.length; n++) {
      const url = SERVERS[(k + n) % SERVERS.length];
      const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 40000);
      try {
        const res = await fetch(url, { method: 'POST', body: 'data=' + encodeURIComponent(q), signal: ctl.signal });
        clearTimeout(to);
        if (res.ok) return (await res.json()).elements || [];
      } catch (e) { clearTimeout(to); }
    }
    return null;
  }

  function toRows(elements) {
    const rows = [];
    elements.forEach(el => {
      const t = el.tags || {};
      if (t.access === 'private' || t.access === 'no') return;
      const lat = el.lat ?? (el.center && el.center.lat), lng = el.lon ?? (el.center && el.center.lon);
      if (lat == null) return;
      rows.push([el.type[0], el.id, +lat.toFixed(5), +lng.toFixed(5), t.name || '', t['addr:street'] || '', t.parking || '', t.fee || '', parseInt(t.capacity) || 0]);
    });
    return rows;
  }

  // Loads the city in 9 pieces so lots appear as each piece arrives. onUpdate(hubs) is called after each piece.
  async function load(onUpdate) {
    try {
      const c = JSON.parse(localStorage.getItem(CACHE_KEY) || 'null');
      if (c && c.rows && c.rows.length && Date.now() - c.t < TTL) {
        addRows(c.rows); if (onUpdate) onUpdate(hubs); return { hubs, failed: 0 };
      }
    } catch (e) { /* ignore */ }
    const list = tiles(); let next = 0, failed = 0; const all = [];
    async function worker() {
      while (next < list.length) {
        const k = next++;
        const els = await fetchTile(list[k], k);
        if (!els) { failed++; continue; }
        const rows = toRows(els); all.push(...rows);
        addRows(rows); if (onUpdate) onUpdate(hubs);
      }
    }
    await Promise.all([worker(), worker()]);
    if (!failed) { try { localStorage.setItem(CACHE_KEY, JSON.stringify({ t: Date.now(), rows: all })); } catch (e) { /* skip cache */ } }
    return { hubs, failed };
  }

  function makeFloors(h) {
    const rand = rng(hashStr(h.id + 'floors'));
    const multi = h.kind === 'multi-storey' || h.kind === 'underground';
    const n = multi ? Math.min(3, Math.ceil(h.totalSpots / 15)) : 1;
    const status = Array(h.totalSpots).fill('occupied');
    for (let i = 0; i < h.vacantSpots; i++) status[i] = 'vacant';
    for (let i = status.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [status[i], status[j]] = [status[j], status[i]]; }
    let k = 0;
    return ['G', '1', '2'].slice(0, n).map((fid, fi) => {
      const per = Math.floor(h.totalSpots / n);
      const count = fi < n - 1 ? per : h.totalSpots - per * (n - 1);
      const slots = [];
      for (let i = 0; i < count; i++) {
        let type = 'Standard', charger = null;
        if (i === 0 && count >= 8) type = 'Disabled';
        else if (h.evCharging.available && i >= count - 2) { type = 'EV Charging'; charger = 'Level-2 (22 kW)'; }
        else if (i % 5 === 3) type = 'Compact';
        const st = status[k++];
        const veh = type === 'Compact' ? '2-Wheeler' : (rand() < 0.3 ? 'SUV' : 'Sedan');
        slots.push({
          id: `${h.id}-${fid}-${String(i + 1).padStart(2, '0')}`, bayNumber: String(i + 1).padStart(2, '0'),
          floor: fid, type, status: st, vehicleType: st === 'vacant' ? null : veh, charger
        });
      }
      return { floorId: fid, floorName: fid === 'G' ? 'Ground Floor (Level G)' : `Floor ${fid}`, slots };
    });
  }

  const counters = {};
  function addRows(rows) {
    const fresh = rows.filter(r => !byId.has(`osm-${r[0]}${r[1]}`));
    const made = fresh.map(r => {
      const [ty, id, lat, lng, name, street, kind, fee, cap] = r;
      const hid = `osm-${ty}${id}`, rand = rng(hashStr(hid)), area = areaFor(lat, lng);
      counters[area.name] = (counters[area.name] || 0) + 1;
      const total = cap ? Math.max(6, Math.min(60, cap)) : Math.round(12 + rand() * 28);
      const vacant = Math.max(0, Math.min(total, Math.round(total * (0.05 + rand() * 0.7))));
      const occ = Math.round(((total - vacant) / total) * 100);
      const mult = occ > 85 ? 1.3 : (occ >= 60 ? 1.15 : 1);
      const base = Math.round(((kind === 'underground' ? 30 : kind === 'multi-storey' ? 25 : 15) + rand() * 10) / 5) * 5;
      const nm = name || (street ? `${street} Parking` : `${area.name} Parking #${counters[area.name]}`);
      const hub = {
        id: hid, isLot: true, source: 'osm', kind, name: nm, city: 'Hyderabad',
        category: 'Public parking', lat, lng,
        landmark: area.d <= 8 ? `Near ${area.name}` : 'Greater Hyderabad',
        address: `${street ? street + ', ' : ''}${area.d <= 8 ? 'Near ' + area.name + ', ' : ''}Hyderabad, Telangana`,
        distance: '', baseTariffPerHour: base,
        evCharging: rand() < 0.12 ? { available: true, types: ['Level-2 (22 kW)'], ratePerHour: 10, fastRatePerHour: 25 } : { available: false, types: [] },
        totalSpots: total, vacantSpots: vacant, occupiedSpots: total - vacant, lockedSpots: 0, occupancyRate: occ,
        surgeMultiplier: mult, surgeLabel: mult > 1.2 ? 'Peak Surge (+30%)' : (mult > 1 ? 'High Demand Surge (+15%)' : 'Normal Tariff'),
        effectiveBaseTariff: Math.round(base * mult), _d: 0
      };
      let cached = null;
      Object.defineProperty(hub, 'floors', { enumerable: true, configurable: true, get() { return cached || (cached = makeFloors(hub)); } });
      return hub;
    });
    made.forEach(h => { byId.set(h.id, h); hubs.push(h); });
    setOrigin(origin.lat, origin.lng, origin.label);
  }

  function setOrigin(lat, lng, label) {
    origin = { lat, lng, label: label || origin.label };
    hubs.forEach(h => {
      h._d = km(lat, lng, h.lat, h.lng);
      h.distance = `${h._d < 1 ? Math.round(h._d * 1000) + ' m' : h._d.toFixed(1) + ' km'} from ${origin.label}`;
    });
  }

  return {
    load,
    get: id => byId.get(id),
    all: () => hubs,
    setOrigin,
    sorted: () => hubs.slice().sort((a, b) => a._d - b._d)
  };
})();

window.CityParking = CityParking;
