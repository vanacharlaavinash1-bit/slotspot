// SlotSpot: User Authentication & Authorization Module
// Secure password hashing with scrypt, cryptographically secure session tokens, and RBAC

const crypto = require('crypto');
const {
  ValidationError,
  validateEmail,
  validatePassword,
  validateDriverName,
  validateLicensePlate
} = require('./validation');

const SESSION_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours session expiry

/**
 * Derives secure password hash using scrypt and a unique salt
 */
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64);
  return {
    hash: derivedKey.toString('hex'),
    salt
  };
}

/**
 * Verifies plaintext password against stored scrypt hash and salt
 */
function verifyPassword(password, storedHash, salt) {
  try {
    const derivedKey = crypto.scryptSync(password, salt, 64);
    const keyBuffer = Buffer.from(derivedKey.toString('hex'), 'hex');
    const storedBuffer = Buffer.from(storedHash, 'hex');
    if (keyBuffer.length !== storedBuffer.length) return false;
    return crypto.timingSafeEqual(keyBuffer, storedBuffer);
  } catch (err) {
    return false;
  }
}

/**
 * Generates cryptographically secure random session token
 */
function generateSessionToken() {
  return 'SST-' + crypto.randomBytes(32).toString('hex');
}

/**
 * Strips sensitive security credentials before returning user object
 */
function sanitizeUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    vehiclePlate: user.vehicle_plate || user.vehiclePlate || null,
    phone: user.phone || null,
    role: user.role || 'motorist',
    createdAt: user.created_at || user.createdAt
  };
}

/**
 * Registers a new user account in database
 */
function registerUser(db, { name, email, password, vehiclePlate = null, phone = null, role = 'motorist' }) {
  const validName = validateDriverName(name);
  const validEmail = validateEmail(email);
  const validPass = validatePassword(password);
  const validPlate = vehiclePlate ? validateLicensePlate(vehiclePlate) : null;

  // Check unique email
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(validEmail);
  if (existing) {
    throw new ValidationError(`An account with email '${validEmail}' already exists. Please sign in instead.`, 409);
  }

  const { hash, salt } = hashPassword(validPass);
  const userId = 'USR-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  const now = Date.now();

  db.prepare(`
    INSERT INTO users (id, name, email, password_hash, salt, vehicle_plate, phone, role, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(userId, validName, validEmail, hash, salt, validPlate, phone, role, now);

  // Create session
  const token = generateSessionToken();
  const expiresAt = now + SESSION_TTL_MS;
  db.prepare(`
    INSERT INTO sessions (token, user_id, expires_at, created_at)
    VALUES (?, ?, ?, ?)
  `).run(token, userId, expiresAt, now);

  const newUser = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  return {
    user: sanitizeUser(newUser),
    token,
    expiresAt
  };
}

/**
 * Authenticates user credentials and issues session token
 */
function loginUser(db, { email, password }) {
  if (!email || !password) {
    throw new ValidationError('Email and password are required for authentication.', 400);
  }

  const validEmail = validateEmail(email);
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(validEmail);
  if (!user) {
    throw new ValidationError('Invalid email or password. Please verify your credentials.', 401);
  }

  const isMatch = verifyPassword(password, user.password_hash, user.salt);
  if (!isMatch) {
    throw new ValidationError('Invalid email or password. Please verify your credentials.', 401);
  }

  const token = generateSessionToken();
  const now = Date.now();
  const expiresAt = now + SESSION_TTL_MS;

  db.prepare(`
    INSERT INTO sessions (token, user_id, expires_at, created_at)
    VALUES (?, ?, ?, ?)
  `).run(token, user.id, expiresAt, now);

  return {
    user: sanitizeUser(user),
    token,
    expiresAt
  };
}

/**
 * Validates request Bearer token and returns active user profile
 */
function authenticateToken(db, token) {
  if (!token) return null;

  const cleanToken = token.startsWith('Bearer ') ? token.slice(7).trim() : token.trim();
  if (!cleanToken) return null;

  const now = Date.now();
  const session = db.prepare(`
    SELECT s.token, s.expires_at, u.*
    FROM sessions s
    JOIN users u ON s.user_id = u.id
    WHERE s.token = ? AND s.expires_at > ?
  `).get(cleanToken, now);

  if (!session) return null;

  return sanitizeUser(session);
}

/**
 * Invalidates user session (Logout)
 */
function logoutUser(db, token) {
  if (!token) return false;
  const cleanToken = token.startsWith('Bearer ') ? token.slice(7).trim() : token.trim();
  db.prepare('DELETE FROM sessions WHERE token = ?').run(cleanToken);
  return true;
}

/**
 * Checks authorization for reservation access and mutations
 * Enforces ownership: Motorist can only modify their own reservations; Admins can manage any reservation.
 */
function authorizeReservationAction(user, reservation) {
  if (!reservation) {
    throw new ValidationError('Reservation not found.', 404);
  }

  // If reservation is bound to a registered user account
  if (reservation.user_id || reservation.userId) {
    const ownerId = reservation.user_id || reservation.userId;
    if (!user) {
      throw new ValidationError('Authentication required to access or modify this reservation.', 401);
    }
    if (user.role !== 'admin' && user.id !== ownerId) {
      throw new ValidationError('Access denied: You are not authorized to modify another motorist’s reservation.', 403);
    }
  }

  return true;
}

module.exports = {
  hashPassword,
  verifyPassword,
  generateSessionToken,
  sanitizeUser,
  registerUser,
  loginUser,
  authenticateToken,
  logoutUser,
  authorizeReservationAction
};
