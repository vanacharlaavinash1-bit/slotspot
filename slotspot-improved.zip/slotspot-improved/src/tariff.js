// SlotSpot: Server-Side Authoritative Tariff & Surge Pricing Calculation Engine
// Enforces mathematical invariants, certified hub rates, and dynamic occupancy pricing

const {
  validateDuration,
  validateVehicleType,
  validateSlotCompatibility,
  validateEVChargingRequest
} = require('./validation');

/**
 * Calculates live occupancy statistics and surge heuristics for a parking facility
 */
function calculateHubOccupancy(hub) {
  let total = 0;
  let vacant = 0;
  let occupied = 0;
  let locked = 0;

  if (hub.floors && Array.isArray(hub.floors)) {
    hub.floors.forEach(fl => {
      if (fl.slots && Array.isArray(fl.slots)) {
        fl.slots.forEach(s => {
          total++;
          if (s.status === 'vacant') vacant++;
          else if (s.status === 'occupied') occupied++;
          else if (s.status === 'locked' || s.status === 'reserved') locked++;
        });
      }
    });
  }

  const occupancyRate = total > 0 ? Math.round(((total - vacant) / total) * 100) : 0;

  let surgeMultiplier = 1.0;
  let surgeLabel = 'Normal Tariff';
  if (occupancyRate > 85) {
    surgeMultiplier = 1.30;
    surgeLabel = 'Peak Surge (+30%)';
  } else if (occupancyRate >= 60) {
    surgeMultiplier = 1.15;
    surgeLabel = 'High Demand Surge (+15%)';
  }

  return {
    totalSpots: total,
    vacantSpots: vacant,
    occupiedSpots: occupied,
    lockedSpots: locked,
    occupancyRate,
    surgeMultiplier,
    surgeLabel,
    effectiveBaseTariff: Math.round((hub.baseTariffPerHour || 30) * surgeMultiplier)
  };
}

/**
 * Maps vehicle type to standard rate multiplier
 */
function getVehicleMultiplier(vehicleType) {
  const v = vehicleType.toLowerCase();
  if (v === '2-wheeler') return 0.5;
  if (v === 'compact') return 0.8;
  if (v === 'suv') return 1.3;
  if (v === 'ev') return 1.0;
  return 1.0; // Sedan and standard
}

/**
 * Server-Side Authoritative Tariff Computation
 * Recalculates all pricing server-side, never trusting client-submitted fees.
 */
function calculateAuthoritativeTariff({
  hub,
  slot = null,
  vehicleType = 'Sedan',
  durationHours = 2,
  useCharger = false,
  chargerType = null
}) {
  if (!hub || !hub.id) {
    throw new Error('Valid parking hub object is required for tariff calculation.');
  }

  // 1. Strict validation of duration & vehicle type
  const validDuration = validateDuration(durationHours);
  const validVehicle = validateVehicleType(vehicleType);

  // 2. Validate slot compatibility if a specific slot is targeted
  if (slot) {
    validateSlotCompatibility(validVehicle, slot);
  }

  // 3. Occupancy & Surge Multiplier
  const occupancyStats = calculateHubOccupancy(hub);
  const surgeMultiplier = occupancyStats.surgeMultiplier;
  const surgeLabel = occupancyStats.surgeLabel;

  // 4. Vehicle Type Multiplier
  const vehicleMultiplier = getVehicleMultiplier(validVehicle);

  // 5. Effective Base Hourly Rate & Base Total
  const baseRatePerHour = hub.baseTariffPerHour || 30;
  const effectiveHourlyRate = Math.round(baseRatePerHour * vehicleMultiplier * surgeMultiplier);
  const baseTotal = effectiveHourlyRate * validDuration;

  // 6. EV Charging Add-on Verification
  let chargerFeePerHour = 0;
  let resolvedChargerType = null;
  const isEVBay = slot ? slot.type === 'EV Charging' : validVehicle === 'EV';

  if (slot) {
    const evCheck = validateEVChargingRequest(slot, useCharger, chargerType, hub);
    if (evCheck.useCharger) {
      resolvedChargerType = chargerType || slot.charger || (hub.evCharging && hub.evCharging.types && hub.evCharging.types[0]) || 'Level-2 AC (22 kW)';
      if (resolvedChargerType.includes('DC Fast')) {
        chargerFeePerHour = (hub.evCharging && hub.evCharging.fastRatePerHour) || 25;
      } else {
        chargerFeePerHour = (hub.evCharging && hub.evCharging.ratePerHour) || 10;
      }
    }
  } else if (isEVBay && useCharger) {
    resolvedChargerType = chargerType || 'Level-2 AC (22 kW)';
    if (resolvedChargerType.includes('DC Fast')) {
      chargerFeePerHour = (hub.evCharging && hub.evCharging.fastRatePerHour) || 25;
    } else {
      chargerFeePerHour = (hub.evCharging && hub.evCharging.ratePerHour) || 10;
    }
  }

  const chargerTotal = chargerFeePerHour * validDuration;
  const totalFee = baseTotal + chargerTotal;

  // Mathematical Invariant Assertion: totalFee must equal baseTotal + chargerTotal
  if (totalFee !== baseTotal + chargerTotal || totalFee <= 0) {
    throw new Error('Pricing invariant failure: computed total fee does not match component breakdown.');
  }

  return {
    hubId: hub.id,
    hubName: hub.name,
    vehicleType: validVehicle,
    durationHours: validDuration,
    baseRatePerHour,
    occupancyRate: occupancyStats.occupancyRate,
    surgeMultiplier,
    surgeLabel,
    vehicleMultiplier,
    effectiveHourlyRate,
    baseTotal,
    isEVBay,
    useCharger: chargerFeePerHour > 0,
    chargerType: resolvedChargerType,
    chargerFeePerHour,
    chargerTotal,
    totalFee
  };
}

module.exports = {
  calculateHubOccupancy,
  getVehicleMultiplier,
  calculateAuthoritativeTariff
};
