// SlotSpot: Persistent SQLite Database Engine
// Utilizes Node.js v22+ built-in node:sqlite (DatabaseSync) for robust, zero-dependency persistence

const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULT_DB_PATH = path.join(__dirname, '..', 'data', 'slotspot.db');
const SEED_DATA_PATH = path.join(__dirname, '..', 'data', 'lots.json');

class DatabaseEngine {
  constructor(dbPath = DEFAULT_DB_PATH) {
    this.dbPath = dbPath;
    this.db = null;
    this.init();
  }

  init() {
    if (this.dbPath !== ':memory:') {
      const dir = path.dirname(this.dbPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    }

    this.db = new DatabaseSync(this.dbPath);
    this.createSchema();
    this.seedInitialDataIfEmpty();
  }

  createSchema() {
    this.db.exec(`
      PRAGMA foreign_keys = ON;

      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        salt TEXT NOT NULL,
        vehicle_plate TEXT,
        phone TEXT,
        role TEXT DEFAULT 'motorist',
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS sessions (
        token TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        expires_at INTEGER NOT NULL,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS hubs (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        city TEXT DEFAULT 'Hyderabad',
        category TEXT,
        address TEXT NOT NULL,
        landmark TEXT,
        distance TEXT,
        lat REAL,
        lng REAL,
        map_x REAL,
        map_y REAL,
        base_tariff_per_hour INTEGER NOT NULL,
        ev_charging_json TEXT
      );

      CREATE TABLE IF NOT EXISTS floors (
        id TEXT PRIMARY KEY,
        hub_id TEXT NOT NULL REFERENCES hubs(id) ON DELETE CASCADE,
        floor_id TEXT NOT NULL,
        floor_name TEXT NOT NULL,
        level_number INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS slots (
        id TEXT PRIMARY KEY,
        hub_id TEXT NOT NULL REFERENCES hubs(id) ON DELETE CASCADE,
        floor_id TEXT NOT NULL,
        bay_number INTEGER NOT NULL,
        type TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'vacant',
        charger TEXT,
        reservation_id TEXT,
        vehicle_type TEXT,
        updated_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS reservations (
        id TEXT PRIMARY KEY,
        user_id TEXT REFERENCES users(id),
        driver_name TEXT NOT NULL,
        driver_email TEXT,
        plate_number TEXT NOT NULL,
        hub_id TEXT NOT NULL REFERENCES hubs(id),
        hub_name TEXT NOT NULL,
        address TEXT,
        floor_id TEXT NOT NULL,
        floor_name TEXT NOT NULL,
        slot_id TEXT NOT NULL REFERENCES slots(id),
        bay_number INTEGER NOT NULL,
        slot_type TEXT NOT NULL,
        charger TEXT,
        vehicle_type TEXT NOT NULL,
        duration_hours INTEGER NOT NULL,
        base_rate_per_hour REAL NOT NULL,
        surge_multiplier REAL NOT NULL,
        surge_label TEXT NOT NULL,
        effective_hourly_rate REAL NOT NULL,
        base_total REAL NOT NULL,
        charger_fee_per_hour REAL NOT NULL,
        charger_total REAL NOT NULL,
        total_fee REAL NOT NULL,
        status TEXT NOT NULL,
        qr_token TEXT,
        created_at INTEGER NOT NULL,
        expires_at INTEGER NOT NULL,
        confirmed_at INTEGER,
        check_in_time INTEGER
      );

      CREATE INDEX IF NOT EXISTS idx_slots_hub_status ON slots(hub_id, status);
      CREATE INDEX IF NOT EXISTS idx_res_status ON reservations(status);
      CREATE INDEX IF NOT EXISTS idx_res_user ON reservations(user_id);
    `);
  }

  seedInitialDataIfEmpty() {
    const hubCount = this.db.prepare('SELECT COUNT(*) as count FROM hubs').get().count;
    if (hubCount === 0 && fs.existsSync(SEED_DATA_PATH)) {
      try {
        const raw = fs.readFileSync(SEED_DATA_PATH, 'utf8');
        const parsed = JSON.parse(raw);
        const now = Date.now();

        const insertHub = this.db.prepare(`
          INSERT INTO hubs (id, name, city, category, address, landmark, distance, lat, lng, map_x, map_y, base_tariff_per_hour, ev_charging_json)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        const insertFloor = this.db.prepare(`
          INSERT INTO floors (id, hub_id, floor_id, floor_name, level_number)
          VALUES (?, ?, ?, ?, ?)
        `);

        const insertSlot = this.db.prepare(`
          INSERT INTO slots (id, hub_id, floor_id, bay_number, type, status, charger, reservation_id, vehicle_type, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        for (const hub of parsed.hubs) {
          insertHub.run(
            hub.id,
            hub.name,
            hub.city || 'Hyderabad',
            hub.category,
            hub.address,
            hub.landmark,
            hub.distance,
            hub.lat,
            hub.lng,
            hub.mapX,
            hub.mapY,
            hub.baseTariffPerHour || 30,
            JSON.stringify(hub.evCharging || null)
          );

          if (hub.floors && Array.isArray(hub.floors)) {
            for (let fIdx = 0; fIdx < hub.floors.length; fIdx++) {
              const fl = hub.floors[fIdx];
              const floorPk = `${hub.id}_${fl.floorId}`;
              insertFloor.run(floorPk, hub.id, fl.floorId, fl.floorName, fIdx);

              if (fl.slots && Array.isArray(fl.slots)) {
                for (const s of fl.slots) {
                  insertSlot.run(
                    s.id,
                    hub.id,
                    fl.floorId,
                    s.bayNumber,
                    s.type,
                    s.status || 'vacant',
                    s.charger || null,
                    s.reservationId || null,
                    s.vehicleType || null,
                    now
                  );
                }
              }
            }
          }
        }
      } catch (err) {
        console.error('Failed to seed SQLite database from lots.json:', err);
      }
    }

    // Seed default demo users if users table is empty
    const userCount = this.db.prepare('SELECT COUNT(*) as count FROM users').get().count;
    if (userCount === 0) {
      const { hashPassword } = require('./auth');
      const now = Date.now();

      // Demo Motorist (Harry)
      const motoristCreds = hashPassword('Motorist@123');
      this.db.prepare(`
        INSERT INTO users (id, name, email, password_hash, salt, vehicle_plate, phone, role, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run('USR-MOTO-01', 'Harry (Motorist)', 'motorist@slotspot.in', motoristCreds.hash, motoristCreds.salt, 'TS 09 AB 7720', '+91 98765 43210', 'motorist', now);

      // Demo Administrator
      const adminCreds = hashPassword('Admin@123');
      this.db.prepare(`
        INSERT INTO users (id, name, email, password_hash, salt, vehicle_plate, phone, role, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run('USR-ADMIN-01', 'Facility Dispatcher', 'admin@slotspot.in', adminCreds.hash, adminCreds.salt, 'TS 09 Z 0001', '+91 98765 00000', 'admin', now);
    }
  }

  /**
   * Retrieves all parking hubs structured identically to lots.json for complete backward compatibility
   */
  getAllHubs() {
    const hubsRows = this.db.prepare('SELECT * FROM hubs ORDER BY id ASC').all();
    const floorsRows = this.db.prepare('SELECT * FROM floors ORDER BY level_number ASC').all();
    const slotsRows = this.db.prepare('SELECT * FROM slots ORDER BY bay_number ASC').all();

    return hubsRows.map(h => {
      const hubFloors = floorsRows
        .filter(f => f.hub_id === h.id)
        .map(f => {
          const floorSlots = slotsRows
            .filter(s => s.hub_id === h.id && s.floor_id === f.floor_id)
            .map(s => ({
              id: s.id,
              bayNumber: s.bay_number,
              type: s.type,
              status: s.status,
              charger: s.charger,
              reservationId: s.reservation_id,
              vehicleType: s.vehicle_type
            }));

          return {
            floorId: f.floor_id,
            floorName: f.floor_name,
            slots: floorSlots
          };
        });

      let evCharging = null;
      try {
        evCharging = h.ev_charging_json ? JSON.parse(h.ev_charging_json) : null;
      } catch (e) {}

      return {
        id: h.id,
        name: h.name,
        city: h.city,
        category: h.category,
        address: h.address,
        landmark: h.landmark,
        distance: h.distance,
        lat: h.lat,
        lng: h.lng,
        mapX: h.map_x,
        mapY: h.map_y,
        baseTariffPerHour: h.base_tariff_per_hour,
        evCharging,
        floors: hubFloors
      };
    });
  }

  getHubById(hubId) {
    const all = this.getAllHubs();
    return all.find(h => h.id === hubId) || null;
  }

  getSlot(hubId, slotId) {
    const s = this.db.prepare('SELECT * FROM slots WHERE hub_id = ? AND id = ?').get(hubId, slotId);
    if (!s) return null;
    return {
      id: s.id,
      hubId: s.hub_id,
      floorId: s.floor_id,
      bayNumber: s.bay_number,
      type: s.type,
      status: s.status,
      charger: s.charger,
      reservationId: s.reservation_id,
      vehicleType: s.vehicle_type
    };
  }

  updateSlotStatus(slotId, status, reservationId = null, vehicleType = null) {
    const now = Date.now();
    this.db.prepare(`
      UPDATE slots
      SET status = ?, reservation_id = ?, vehicle_type = ?, updated_at = ?
      WHERE id = ?
    `).run(status, reservationId, vehicleType, now, slotId);
  }

  createReservation(reservation) {
    const insertRes = this.db.prepare(`
      INSERT INTO reservations (
        id, user_id, driver_name, driver_email, plate_number, hub_id, hub_name, address,
        floor_id, floor_name, slot_id, bay_number, slot_type, charger, vehicle_type,
        duration_hours, base_rate_per_hour, surge_multiplier, surge_label,
        effective_hourly_rate, base_total, charger_fee_per_hour, charger_total, total_fee,
        status, qr_token, created_at, expires_at
      ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?, ?, ?, ?,
        ?, ?, ?, ?
      )
    `);

    insertRes.run(
      reservation.id,
      reservation.userId || null,
      reservation.driverName,
      reservation.driverEmail || null,
      reservation.plateNumber,
      reservation.hubId,
      reservation.hubName,
      reservation.address,
      reservation.floorId,
      reservation.floorName,
      reservation.slotId,
      reservation.bayNumber,
      reservation.slotType,
      reservation.charger || null,
      reservation.vehicleType,
      reservation.durationHours,
      reservation.baseRatePerHour,
      reservation.surgeMultiplier,
      reservation.surgeLabel,
      reservation.effectiveHourlyRate,
      reservation.baseTotal,
      reservation.chargerFeePerHour || 0,
      reservation.chargerTotal || 0,
      reservation.totalFee,
      reservation.status,
      reservation.qrToken || null,
      reservation.createdAt,
      reservation.expiresAt
    );

    // Also update slot status to locked
    this.updateSlotStatus(reservation.slotId, 'locked', reservation.id, reservation.vehicleType);
    return this.getReservationById(reservation.id);
  }

  getReservationById(resId) {
    const r = this.db.prepare('SELECT * FROM reservations WHERE id = ?').get(resId);
    if (!r) return null;
    return {
      id: r.id,
      userId: r.user_id,
      driverName: r.driver_name,
      driverEmail: r.driver_email,
      plateNumber: r.plate_number,
      hubId: r.hub_id,
      hubName: r.hub_name,
      address: r.address,
      floorId: r.floor_id,
      floorName: r.floor_name,
      slotId: r.slot_id,
      bayNumber: r.bay_number,
      slotType: r.slot_type,
      charger: r.charger,
      vehicleType: r.vehicle_type,
      durationHours: r.duration_hours,
      baseRatePerHour: r.base_rate_per_hour,
      surgeMultiplier: r.surge_multiplier,
      surgeLabel: r.surge_label,
      effectiveHourlyRate: r.effective_hourly_rate,
      baseTotal: r.base_total,
      chargerFeePerHour: r.charger_fee_per_hour,
      chargerTotal: r.charger_total,
      totalFee: r.total_fee,
      status: r.status,
      qrToken: r.qr_token,
      createdAt: r.created_at,
      expiresAt: r.expires_at,
      confirmedAt: r.confirmed_at,
      checkInTime: r.check_in_time
    };
  }

  getUserReservations(userId) {
    const rows = this.db.prepare('SELECT * FROM reservations WHERE user_id = ? ORDER BY created_at DESC').all(userId);
    return rows.map(r => this.getReservationById(r.id));
  }

  updateReservationStatus(resId, status, additionalFields = {}) {
    const updates = ['status = ?'];
    const params = [status];

    if (additionalFields.confirmedAt !== undefined) {
      updates.push('confirmed_at = ?');
      params.push(additionalFields.confirmedAt);
    }
    if (additionalFields.qrToken !== undefined) {
      updates.push('qr_token = ?');
      params.push(additionalFields.qrToken);
    }
    if (additionalFields.checkInTime !== undefined) {
      updates.push('check_in_time = ?');
      params.push(additionalFields.checkInTime);
    }

    params.push(resId);
    this.db.prepare(`UPDATE reservations SET ${updates.join(', ')} WHERE id = ?`).run(...params);
    return this.getReservationById(resId);
  }

  getExpiredReservations(now = Date.now()) {
    const rows = this.db.prepare("SELECT * FROM reservations WHERE status = 'locked' AND expires_at <= ?").all(now);
    return rows.map(r => this.getReservationById(r.id));
  }

  getAllActiveReservationsMap() {
    const rows = this.db.prepare("SELECT * FROM reservations WHERE status IN ('locked', 'reserved', 'checked_in')").all();
    const map = {};
    rows.forEach(r => {
      map[r.id] = this.getReservationById(r.id);
    });
    return map;
  }

  resetFacilityState() {
    if (!fs.existsSync(SEED_DATA_PATH)) return;
    const raw = fs.readFileSync(SEED_DATA_PATH, 'utf8');
    const parsed = JSON.parse(raw);
    const now = Date.now();

    this.db.exec("UPDATE reservations SET status = 'cancelled' WHERE status IN ('locked', 'reserved')");

    const updateSlot = this.db.prepare(`
      UPDATE slots
      SET status = ?, reservation_id = ?, vehicle_type = ?, updated_at = ?
      WHERE id = ?
    `);

    for (const hub of parsed.hubs) {
      for (const fl of hub.floors) {
        for (const s of fl.slots) {
          updateSlot.run(s.status || 'vacant', null, null, now, s.id);
        }
      }
    }
  }

  close() {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

let defaultEngineInstance = null;
function getDatabase(dbPath = DEFAULT_DB_PATH) {
  if (dbPath === ':memory:') {
    return new DatabaseEngine(':memory:');
  }
  if (!defaultEngineInstance) {
    defaultEngineInstance = new DatabaseEngine(dbPath);
  }
  return defaultEngineInstance;
}

module.exports = {
  DatabaseEngine,
  getDatabase
};
