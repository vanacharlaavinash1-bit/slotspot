// SlotSpot: Server-Side Defensive Validation Module
// Validates Duration, Pricing Invariants, Vehicle Compatibility, License Plates, and User Inputs

const VALID_VEHICLE_TYPES = ['2-Wheeler', 'Compact', 'Sedan', 'SUV', 'EV'];
const VALID_SLOT_TYPES = ['Standard', 'Compact', 'EV Charging', 'Accessible'];
const MIN_DURATION_HOURS = 1;
const MAX_DURATION_HOURS = 24;

// Standard Indian/Telangana License Plate Regex (e.g. TS 09 AB 7720, AP 28 BC 5678, DL 01 A 1234)
const LICENSE_PLATE_REGEX = /^[A-Z]{2}\s?[0-9]{1,2}\s?[A-Z]{1,3}\s?[0-9]{4}$/i;
const EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

class ValidationError extends Error {
  constructor(message, statusCode = 400, details = null) {
    super(message);
    this.name = 'ValidationError';
    this.statusCode = statusCode;
    this.details = details;
  }
}

/**
 * Validates requested reservation duration in hours
 * Must be a positive integer between 1 and 24 hours
 */
function validateDuration(durationHours) {
  if (durationHours === undefined || durationHours === null || durationHours === '') {
    throw new ValidationError('Parking duration is required (minimum 1 hour, maximum 24 hours).');
  }

  const num = Number(durationHours);
  if (!Number.isFinite(num) || !Number.isInteger(num)) {
    throw new ValidationError('Parking duration must be a whole integer number of hours (e.g., 1, 2, 3).');
  }

  if (num < MIN_DURATION_HOURS) {
    throw new ValidationError(`Parking duration cannot be less than ${MIN_DURATION_HOURS} hour.`);
  }

  if (num > MAX_DURATION_HOURS) {
    throw new ValidationError(`Maximum allowable reservation duration is ${MAX_DURATION_HOURS} hours per single booking.`);
  }

  return num;
}

/**
 * Validates and normalizes vehicle type
 */
function validateVehicleType(vehicleType) {
  if (!vehicleType || typeof vehicleType !== 'string') {
    throw new ValidationError(`Vehicle type is required. Allowed types: ${VALID_VEHICLE_TYPES.join(', ')}`);
  }

  const cleaned = vehicleType.trim();
  const matched = VALID_VEHICLE_TYPES.find(v => v.toLowerCase() === cleaned.toLowerCase());
  if (!matched) {
    throw new ValidationError(`Invalid vehicle type '${vehicleType}'. Allowed types: ${VALID_VEHICLE_TYPES.join(', ')}`);
  }

  return matched;
}

/**
 * Validates vehicle size against slot dimensions/specifications
 */
function validateSlotCompatibility(vehicleType, slot) {
  if (!slot) {
    throw new ValidationError('Target parking slot is required.');
  }

  const normalizedVehicle = validateVehicleType(vehicleType);

  // An SUV cannot fit into a Compact bay
  if (normalizedVehicle === 'SUV' && slot.type === 'Compact') {
    throw new ValidationError(`Vehicle size mismatch: SUV cannot fit into Compact Bay #${slot.bayNumber}. Please select a Standard or EV bay.`);
  }

  return true;
}

/**
 * Validates and formats vehicle registration plate number
 */
function validateLicensePlate(plateNumber) {
  if (!plateNumber || typeof plateNumber !== 'string') {
    throw new ValidationError('Vehicle registration number is required (e.g. TS 09 AB 7720).');
  }

  const cleaned = plateNumber.trim().toUpperCase().replace(/\s+/g, ' ');
  if (cleaned.length < 5 || cleaned.length > 15) {
    throw new ValidationError('License plate length must be between 5 and 15 characters.');
  }

  if (!LICENSE_PLATE_REGEX.test(cleaned)) {
    throw new ValidationError(`Invalid vehicle registration format '${plateNumber}'. Example valid format: TS 09 AB 7720 or AP 28 BC 1234.`);
  }

  return cleaned;
}

/**
 * Sanitizes and validates driver name
 */
function validateDriverName(name) {
  if (!name || typeof name !== 'string') {
    throw new ValidationError('Driver / motorist name is required.');
  }

  const sanitized = name.replace(/[<>'"/\\&]/g, '').trim();
  if (sanitized.length < 2) {
    throw new ValidationError('Driver name must be at least 2 characters.');
  }
  if (sanitized.length > 60) {
    throw new ValidationError('Driver name cannot exceed 60 characters.');
  }

  return sanitized;
}

/**
 * Validates email address
 */
function validateEmail(email) {
  if (!email || typeof email !== 'string') {
    throw new ValidationError('A valid email address is required.');
  }

  const cleaned = email.trim().toLowerCase();
  if (!EMAIL_REGEX.test(cleaned)) {
    throw new ValidationError(`Invalid email address format '${email}'.`);
  }

  return cleaned;
}

/**
 * Validates user password on registration
 */
function validatePassword(password) {
  if (!password || typeof password !== 'string') {
    throw new ValidationError('Password is required.');
  }

  if (password.length < 6) {
    throw new ValidationError('Password must be at least 6 characters long.');
  }

  if (!/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
    throw new ValidationError('Password must contain at least one letter and one number.');
  }

  return password;
}

/**
 * Validates EV charging request integrity
 * Prevents non-EV bays from billing or claiming charger add-ons
 */
function validateEVChargingRequest(slot, useCharger, chargerType, hub) {
  const isEVBay = slot.type === 'EV Charging';

  if (!isEVBay && useCharger) {
    throw new ValidationError(`Bay #${slot.bayNumber} is a standard ${slot.type} bay without an EV charging plug. Charging add-on cannot be selected.`);
  }

  if (isEVBay && useCharger) {
    if (!slot.charger && !hub.evCharging) {
      throw new ValidationError(`EV charging equipment is currently unavailable at Bay #${slot.bayNumber}.`);
    }
  }

  return {
    isEVBay,
    useCharger: Boolean(isEVBay && useCharger)
  };
}

module.exports = {
  VALID_VEHICLE_TYPES,
  VALID_SLOT_TYPES,
  MIN_DURATION_HOURS,
  MAX_DURATION_HOURS,
  ValidationError,
  validateDuration,
  validateVehicleType,
  validateSlotCompatibility,
  validateLicensePlate,
  validateDriverName,
  validateEmail,
  validatePassword,
  validateEVChargingRequest
};
