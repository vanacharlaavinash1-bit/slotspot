// SlotSpot: Hyderabad Smart City Parking & Reservation Platform
// Production Backend with Persistent SQLite Database, User Auth/RBAC, Strict Server-Side Validation & SSE Telemetry

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const { getDatabase } = require('./src/db');
const { calculateAuthoritativeTariff, calculateHubOccupancy } = require('./src/tariff');
const {
  ValidationError,
  validateDuration,
  validateVehicleType,
  validateLicensePlate,
  validateDriverName,
  validateSlotCompatibility
} = require('./src/validation');
const {
  registerUser,
  loginUser,
  authenticateToken,
  logoutUser,
  authorizeReservationAction
} = require('./src/auth');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

// Initialize persistent SQLite database engine
const dbEngine = getDatabase();

let sseClients = []; // Connected SSE clients for live telemetry updates
let simulationRunning = true;
let simulationInterval = null;

// Compute dynamic summary for hub
function getHubSummary(hub) {
  const occ = calculateHubOccupancy(hub);
  return {
    id: hub.id,
    name: hub.name,
    city: hub.city || 'Hyderabad',
    category: hub.category,
    address: hub.address,
    landmark: hub.landmark,
    distance: hub.distance,
    lat: hub.lat,
    lng: hub.lng,
    mapX: hub.mapX,
    mapY: hub.mapY,
    baseTariffPerHour: hub.baseTariffPerHour,
    evCharging: hub.evCharging,
    totalSpots: occ.totalSpots,
    vacantSpots: occ.vacantSpots,
    occupiedSpots: occ.occupiedSpots,
    lockedSpots: occ.lockedSpots,
    occupancyRate: occ.occupancyRate,
    surgeMultiplier: occ.surgeMultiplier,
    surgeLabel: occ.surgeLabel,
    effectiveBaseTariff: occ.effectiveBaseTariff
  };
}

// Broadcast SSE event to all connected clients
function broadcastEvent(type, payload) {
  const message = `event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`;
  sseClients.forEach(client => {
    try {
      client.res.write(message);
    } catch (e) {
      // client dropped
    }
  });
}

// Periodic check for expired 15-minute reservation holds (persists release to SQLite)
function checkExpiredReservations() {
  const now = Date.now();
  const expiredList = dbEngine.getExpiredReservations(now);

  if (expiredList.length > 0) {
    for (const res of expiredList) {
      console.log(`[Hold Expired] Reservation ${res.id} for Slot ${res.slotId} released back to vacant.`);
      dbEngine.updateReservationStatus(res.id, 'expired');
      dbEngine.updateSlotStatus(res.slotId, 'vacant', null, null);

      broadcastEvent('slot_updated', {
        hubId: res.hubId,
        slotId: res.slotId,
        bayNumber: res.bayNumber,
        status: 'vacant',
        reason: '15-minute hold expired'
      });
    }

    const hubs = dbEngine.getAllHubs();
    broadcastEvent('hub_stats_updated', hubs.map(getHubSummary));
  }
}

// Simulation loop for realistic IoT sensor pulses (persists to SQLite)
function toggleRandomSlot() {
  if (!simulationRunning) return;

  const hubs = dbEngine.getAllHubs();
  if (!hubs || hubs.length === 0) return;

  const hub = hubs[Math.floor(Math.random() * hubs.length)];
  const floor = hub.floors[Math.floor(Math.random() * hub.floors.length)];

  // Do not flip locked or reserved bays or official demo bay MP-1-12
  const eligibleSlots = floor.slots.filter(s => s.status !== 'locked' && s.status !== 'reserved' && s.id !== 'MP-1-12');
  if (eligibleSlots.length === 0) return;

  const slot = eligibleSlots[Math.floor(Math.random() * eligibleSlots.length)];
  const previousStatus = slot.status;
  const newStatus = previousStatus === 'vacant' ? 'occupied' : 'vacant';
  const vehicleType = newStatus === 'occupied' ? (slot.type === 'EV Charging' ? 'EV' : (slot.type === 'Compact' ? '2-Wheeler' : 'Sedan')) : null;

  dbEngine.updateSlotStatus(slot.id, newStatus, null, vehicleType);

  broadcastEvent('telemetry_pulse', {
    hubId: hub.id,
    hubName: hub.name,
    floorId: floor.floorId,
    slotId: slot.id,
    bayNumber: slot.bayNumber,
    previousStatus,
    newStatus,
    timestamp: new Date().toLocaleTimeString(),
    message: `IoT Sensor [${slot.id}] status changed: ${previousStatus.toUpperCase()} ➔ ${newStatus.toUpperCase()}`
  });

  const updatedHubs = dbEngine.getAllHubs();
  broadcastEvent('hub_stats_updated', updatedHubs.map(getHubSummary));
}

function startSimulationLoop() {
  if (simulationInterval) clearInterval(simulationInterval);
  simulationInterval = setInterval(() => {
    toggleRandomSlot();
  }, 12000);
}

// MIME types dictionary for static file serving
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function sendJSON(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(data));
}

function parseRequestBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
      if (body.length > 1e6) {
        req.destroy();
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        resolve({});
      }
    });
    req.on('error', reject);
  });
}

// Helper to extract authenticated user from Authorization header
function getAuthUser(req) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return null;
  return authenticateToken(dbEngine.db, authHeader);
}

// HTTP Server
const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    return res.end();
  }

  // ==========================================
  // REST API Endpoints
  // ==========================================
  if (pathname.startsWith('/api/')) {
    try {
      // ----------------------------------------
      // AUTHENTICATION & USER MANAGEMENT APIS
      // ----------------------------------------
      if (pathname === '/api/auth/register' && method === 'POST') {
        const body = await parseRequestBody(req);
        const result = registerUser(dbEngine.db, body);
        return sendJSON(res, 201, {
          success: true,
          message: 'Account successfully registered.',
          user: result.user,
          token: result.token,
          expiresAt: result.expiresAt
        });
      }

      if (pathname === '/api/auth/login' && method === 'POST') {
        const body = await parseRequestBody(req);
        const result = loginUser(dbEngine.db, body);
        return sendJSON(res, 200, {
          success: true,
          message: 'Authentication successful.',
          user: result.user,
          token: result.token,
          expiresAt: result.expiresAt
        });
      }

      if (pathname === '/api/auth/me' && method === 'GET') {
        const authUser = getAuthUser(req);
        if (!authUser) {
          return sendJSON(res, 401, { success: false, error: 'Unauthorized: Valid Bearer token required.' });
        }
        return sendJSON(res, 200, { success: true, user: authUser });
      }

      if (pathname === '/api/auth/logout' && method === 'POST') {
        const authHeader = req.headers['authorization'];
        if (authHeader) {
          logoutUser(dbEngine.db, authHeader);
        }
        return sendJSON(res, 200, { success: true, message: 'Logged out successfully.' });
      }

      if (pathname === '/api/auth/reservations' && method === 'GET') {
        const authUser = getAuthUser(req);
        if (!authUser) {
          return sendJSON(res, 401, { success: false, error: 'Unauthorized: Sign in to view your bookings.' });
        }
        const userRes = dbEngine.getUserReservations(authUser.id);
        return sendJSON(res, 200, { success: true, reservations: userRes });
      }

      // ----------------------------------------
      // PARKING HUBS & INVENTORY APIS
      // ----------------------------------------
      if (pathname === '/api/hubs' && method === 'GET') {
        const hubs = dbEngine.getAllHubs();
        const hubsSummary = hubs.map(getHubSummary);
        return sendJSON(res, 200, { success: true, hubs: hubsSummary });
      }

      const hubMatch = pathname.match(/^\/api\/hubs\/([a-zA-Z0-9_-]+)$/);
      if (hubMatch && method === 'GET') {
        const hubId = hubMatch[1];
        const hub = dbEngine.getHubById(hubId);
        if (!hub) {
          return sendJSON(res, 404, { success: false, error: 'Parking hub not found.' });
        }
        const summary = getHubSummary(hub);
        return sendJSON(res, 200, {
          success: true,
          hub: {
            ...hub,
            ...summary
          }
        });
      }

      // ----------------------------------------
      // SERVER-SIDE TARIFF CALCULATION (STRICT VALIDATION)
      // ----------------------------------------
      if (pathname === '/api/tariff/calculate' && method === 'POST') {
        const body = await parseRequestBody(req);
        const { hubId, slotId, vehicleType, durationHours, useCharger, chargerType } = body;

        const hub = dbEngine.getHubById(hubId);
        if (!hub) {
          return sendJSON(res, 404, { success: false, error: 'Parking hub not found.' });
        }

        let slot = null;
        if (slotId) {
          slot = dbEngine.getSlot(hubId, slotId);
        }

        const calc = calculateAuthoritativeTariff({
          hub,
          slot,
          vehicleType: vehicleType || 'Sedan',
          durationHours,
          useCharger: Boolean(useCharger),
          chargerType
        });

        return sendJSON(res, 200, { success: true, calculation: calc });
      }

      // ----------------------------------------
      // ATOMIC 15-MINUTE HOLD / LOCK SPOT (STRICT VALIDATION & DB PERSISTENCE)
      // ----------------------------------------
      if (pathname === '/api/slots/lock' && method === 'POST') {
        const body = await parseRequestBody(req);
        const { hubId, slotId, vehicleType, durationHours, chargerType, driverName, plateNumber } = body;

        const hub = dbEngine.getHubById(hubId);
        if (!hub) return sendJSON(res, 404, { success: false, error: 'Parking hub not found.' });

        const targetSlot = dbEngine.getSlot(hubId, slotId);
        if (!targetSlot) return sendJSON(res, 404, { success: false, error: 'Target parking slot not found.' });

        if (targetSlot.status !== 'vacant') {
          return sendJSON(res, 409, {
            success: false,
            error: `Bay #${targetSlot.bayNumber} is no longer vacant (current status: ${targetSlot.status.toUpperCase()}). Please select another bay.`
          });
        }

        // Locate target floor details
        let targetFloor = null;
        for (const fl of hub.floors) {
          if (fl.floorId === targetSlot.floorId) {
            targetFloor = fl;
            break;
          }
        }

        // Strict Server-Side Validation of duration, vehicle type & slot compatibility
        const validDuration = validateDuration(durationHours);
        const validVehicle = validateVehicleType(vehicleType || (targetSlot.type === 'EV Charging' ? 'EV' : 'Sedan'));
        validateSlotCompatibility(validVehicle, targetSlot);

        // Check authentication (bind to user if token present)
        const authUser = getAuthUser(req);
        const resolvedDriverName = authUser ? authUser.name : validateDriverName(driverName || 'Guest Motorist');
        const resolvedPlate = authUser && authUser.vehiclePlate ? authUser.vehiclePlate : validateLicensePlate(plateNumber || 'TS 09 AB 7720');

        // Authoritative Tariff Recalculation
        const calc = calculateAuthoritativeTariff({
          hub,
          slot: targetSlot,
          vehicleType: validVehicle,
          durationHours: validDuration,
          useCharger: targetSlot.type === 'EV Charging',
          chargerType: chargerType || targetSlot.charger
        });

        const reservationId = 'RES-' + Math.random().toString(36).substring(2, 8).toUpperCase();
        const now = Date.now();
        const holdDurationMs = 15 * 60 * 1000;
        const expiresAt = now + holdDurationMs;

        const reservationData = {
          id: reservationId,
          userId: authUser ? authUser.id : null,
          driverName: resolvedDriverName,
          driverEmail: authUser ? authUser.email : null,
          plateNumber: resolvedPlate,
          hubId: hub.id,
          hubName: hub.name,
          address: hub.address,
          floorId: targetFloor ? targetFloor.floorId : targetSlot.floorId,
          floorName: targetFloor ? targetFloor.floorName : 'Level 1',
          slotId: targetSlot.id,
          bayNumber: targetSlot.bayNumber,
          slotType: targetSlot.type,
          charger: targetSlot.charger,
          vehicleType: calc.vehicleType,
          durationHours: calc.durationHours,
          baseRatePerHour: calc.baseRatePerHour,
          surgeMultiplier: calc.surgeMultiplier,
          surgeLabel: calc.surgeLabel,
          effectiveHourlyRate: calc.effectiveHourlyRate,
          baseTotal: calc.baseTotal,
          chargerFeePerHour: calc.chargerFeePerHour,
          chargerTotal: calc.chargerTotal,
          totalFee: calc.totalFee,
          status: 'locked',
          qrToken: null,
          createdAt: now,
          expiresAt: expiresAt
        };

        // Persist to SQLite atomically
        const savedRes = dbEngine.createReservation(reservationData);

        broadcastEvent('slot_updated', {
          hubId: hub.id,
          slotId: targetSlot.id,
          bayNumber: targetSlot.bayNumber,
          status: 'locked',
          expiresAt
        });

        const updatedHubs = dbEngine.getAllHubs();
        broadcastEvent('hub_stats_updated', updatedHubs.map(getHubSummary));

        return sendJSON(res, 200, {
          success: true,
          message: `Bay #${targetSlot.bayNumber} locked for 15 minutes.`,
          reservation: savedRes
        });
      }

      // ----------------------------------------
      // CONFIRM BOOKING & GENERATE DIGITAL PASS
      // ----------------------------------------
      if (pathname === '/api/slots/confirm' && method === 'POST') {
        const body = await parseRequestBody(req);
        const { reservationId } = body;
        const resv = dbEngine.getReservationById(reservationId);

        if (!resv) return sendJSON(res, 404, { success: false, error: 'Reservation not found.' });

        // Authorization check
        const authUser = getAuthUser(req);
        authorizeReservationAction(authUser, resv);

        if (resv.status !== 'locked') {
          return sendJSON(res, 400, { success: false, error: `Reservation is currently in status: ${resv.status.toUpperCase()}` });
        }

        const now = Date.now();
        const qrToken = `SLOTSPOT:${resv.id}:${resv.hubId}:${resv.slotId}:${resv.plateNumber}`;

        const updated = dbEngine.updateReservationStatus(resv.id, 'reserved', {
          confirmedAt: now,
          qrToken
        });
        dbEngine.updateSlotStatus(resv.slotId, 'reserved', resv.id, resv.vehicleType);

        broadcastEvent('slot_updated', {
          hubId: resv.hubId,
          slotId: resv.slotId,
          status: 'reserved'
        });

        return sendJSON(res, 200, {
          success: true,
          message: 'Reservation confirmed! Digital parking pass issued.',
          reservation: updated
        });
      }

      // ----------------------------------------
      // CANCEL HOLD OR BOOKING
      // ----------------------------------------
      if (pathname === '/api/slots/cancel' && method === 'POST') {
        const body = await parseRequestBody(req);
        const { reservationId } = body;
        const resv = dbEngine.getReservationById(reservationId);

        if (!resv) return sendJSON(res, 404, { success: false, error: 'Reservation not found.' });

        // Authorization check
        const authUser = getAuthUser(req);
        authorizeReservationAction(authUser, resv);

        dbEngine.updateReservationStatus(resv.id, 'cancelled');
        dbEngine.updateSlotStatus(resv.slotId, 'vacant', null, null);

        broadcastEvent('slot_updated', {
          hubId: resv.hubId,
          slotId: resv.slotId,
          status: 'vacant'
        });

        const updatedHubs = dbEngine.getAllHubs();
        broadcastEvent('hub_stats_updated', updatedHubs.map(getHubSummary));

        return sendJSON(res, 200, { success: true, message: 'Reservation cancelled. Bay released.' });
      }

      // ----------------------------------------
      // GATE ACCESS CHECK-IN
      // ----------------------------------------
      if (pathname === '/api/slots/checkin' && method === 'POST') {
        const body = await parseRequestBody(req);
        const { reservationId } = body;
        const resv = dbEngine.getReservationById(reservationId);

        if (!resv) return sendJSON(res, 404, { success: false, error: 'Reservation not found.' });

        // Authorization check
        const authUser = getAuthUser(req);
        authorizeReservationAction(authUser, resv);

        const now = Date.now();
        const updated = dbEngine.updateReservationStatus(resv.id, 'checked_in', {
          checkInTime: now
        });
        dbEngine.updateSlotStatus(resv.slotId, 'occupied', resv.id, resv.vehicleType);

        broadcastEvent('slot_updated', {
          hubId: resv.hubId,
          slotId: resv.slotId,
          status: 'occupied'
        });

        const updatedHubs = dbEngine.getAllHubs();
        broadcastEvent('hub_stats_updated', updatedHubs.map(getHubSummary));

        return sendJSON(res, 200, {
          success: true,
          message: 'Gate barrier opened! Slot transitioned to Occupied.',
          reservation: updated
        });
      }

      // ----------------------------------------
      // SSE TELEMETRY STREAM
      // ----------------------------------------
      if (pathname === '/api/telemetry/events') {
        res.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
          'Access-Control-Allow-Origin': '*'
        });
        res.write(': connected\n\n');

        const client = { id: Date.now(), res };
        sseClients.push(client);

        req.on('close', () => {
          sseClients = sseClients.filter(c => c.id !== client.id);
        });
        return;
      }

      // ----------------------------------------
      // TELEMETRY SIMULATION CONTROLS
      // ----------------------------------------
      if (pathname === '/api/telemetry/toggle' && method === 'POST') {
        const body = await parseRequestBody(req);
        if (typeof body.running === 'boolean') {
          simulationRunning = body.running;
        } else {
          simulationRunning = !simulationRunning;
        }
        return sendJSON(res, 200, {
          success: true,
          simulationRunning,
          message: `Telemetry simulation ${simulationRunning ? 'Resumed' : 'Paused'}`
        });
      }

      if (pathname === '/api/telemetry/trigger' && method === 'POST') {
        toggleRandomSlot();
        return sendJSON(res, 200, { success: true, message: 'IoT sensor pulse triggered.' });
      }

      if (pathname === '/api/simulate/reset' && method === 'POST') {
        dbEngine.resetFacilityState();
        const updatedHubs = dbEngine.getAllHubs();
        broadcastEvent('hub_stats_updated', updatedHubs.map(getHubSummary));
        return sendJSON(res, 200, { success: true, message: 'Facility state reset to demo default.' });
      }

      return sendJSON(res, 404, { success: false, error: 'API endpoint not found.' });

    } catch (err) {
      if (err instanceof ValidationError) {
        return sendJSON(res, err.statusCode, { success: false, error: err.message, details: err.details });
      }
      console.error('[Internal Server Error]', err);
      return sendJSON(res, 500, { success: false, error: 'Internal Server Error', message: err.message });
    }
  }

  // ==========================================
  // Static File Serving
  // ==========================================
  let safePath = path.normalize(pathname).replace(/^(\.\.[\/\\])+/, '');
  if (safePath === '/' || safePath === '\\') safePath = '/index.html';

  const filePath = path.join(PUBLIC_DIR, safePath);

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      const indexPath = path.join(PUBLIC_DIR, 'index.html');
      fs.readFile(indexPath, (readErr, content) => {
        if (readErr) {
          res.writeHead(404, { 'Content-Type': 'text/plain' });
          return res.end('404 Not Found');
        }
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(content);
      });
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    fs.readFile(filePath, (readErr, content) => {
      if (readErr) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        return res.end('500 Internal Server Error');
      }
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    });
  });
});

let expiredCheckInterval = null;

function startBackgroundTasks() {
  if (!expiredCheckInterval) {
    expiredCheckInterval = setInterval(checkExpiredReservations, 3000);
  }
  startSimulationLoop();
}

function stopBackgroundTasks() {
  if (expiredCheckInterval) {
    clearInterval(expiredCheckInterval);
    expiredCheckInterval = null;
  }
  if (simulationInterval) {
    clearInterval(simulationInterval);
    simulationInterval = null;
  }
}

if (require.main === module) {
  startBackgroundTasks();
  server.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(` SlotSpot: Hyderabad Smart Parking System is LIVE!`);
    console.log(` Database: Persistent SQLite (data/slotspot.db)`);
    console.log(` Security: scrypt Auth, RBAC & Server-Side Validation`);
    console.log(` URL: http://localhost:${PORT}`);
    console.log(`====================================================`);
  });
}

module.exports = {
  server,
  dbEngine,
  getHubSummary,
  startBackgroundTasks,
  stopBackgroundTasks
};

