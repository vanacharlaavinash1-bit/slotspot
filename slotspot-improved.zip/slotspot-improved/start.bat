@echo off
title SlotSpot - Hyderabad Smart City Parking System
cd /d "%~dp0"
echo ====================================================
echo  Starting SlotSpot Smart Parking Server...
echo ====================================================
node server.js
pause
